declare const css: string;
export default css;
