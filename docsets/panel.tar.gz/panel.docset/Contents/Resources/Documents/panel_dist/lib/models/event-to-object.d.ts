export declare function serializeEvent(event: any): any;
export default serializeEvent;
