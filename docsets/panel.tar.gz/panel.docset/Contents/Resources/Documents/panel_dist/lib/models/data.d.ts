import { ColumnDataSource } from "@bokehjs/models/sources/column_data_source";
export declare function transform_cds_to_records(cds: ColumnDataSource, addId?: boolean): any;
export declare function dict_to_records(data: any, index?: boolean): any[];
