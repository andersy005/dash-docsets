export declare const get: (obj: any, path: string, defaultValue?: any) => any;
export declare function throttle(func: any, timeFrame: number): () => void;
export declare function deepCopy(obj: any): any;
export declare function isPlainObject(obj: any): boolean;
