export declare function getTooltipDefault(pickedInfo: any): any;
export declare function tabularize(json: any): string;
export declare function toText(jsonValue: any): string;
export declare function substituteIn(template: any, json: any): any;
export declare function makeTooltip(tooltips: any, layers: any[]): ((pickedInfo: any) => any) | null;
