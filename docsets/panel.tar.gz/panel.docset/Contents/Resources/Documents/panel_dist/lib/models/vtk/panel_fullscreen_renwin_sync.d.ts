export declare let FullScreenRenderWindowSynchronized: any;
