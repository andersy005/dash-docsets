.. rst-class:: proplot-rctable

==============================  =========================================================================================================================================================================================================================================================================================================================================
Key                             Description
==============================  =========================================================================================================================================================================================================================================================================================================================================
``style``                       The default matplotlib `stylesheet <https://matplotlib.org/3.2.1/gallery/style_sheets/style_sheets_reference.html>`__ name. If ``None``, a custom proplot style is used. If ``'default'``, the default matplotlib style is used.
``abc``                         Boolean, whether to draw a-b-c labels by default.
``abc.border``                  Boolean, indicates whether to draw a white border around a-b-c labels when :rcraw:`abc.loc` is inside the axes.
``abc.borderwidth``             Width of the white border around a-b-c labels.
``abc.bbox``                    Boolean, whether to draw semi-transparent bounding boxes around a-b-c labels when :rcraw:`abc.loc` is inside the axes.
``abc.bboxcolor``               a-b-c label bounding box color.
``abc.bboxstyle``               a-b-c label bounding box style.
``abc.bboxalpha``               a-b-c label bounding box opacity.
``abc.bboxpad``                 Padding for the a-b-c label bounding box. By default this is scaled to make the box flush against the subplot edge.  Interpreted by `~proplot.utils.units`.
``abc.color``                   a-b-c label color.
``abc.loc``                     a-b-c label position. For options, see the :ref:`title location table <title_table>`.
``abc.size``                    a-b-c label font size.
``abc.style``                   a-b-c label style. Must be string containing the character ``a`` or ``A``, for example ``'a.'`` or ``'(A)'``.
``abc.weight``                  a-b-c label font weight.
``autoformat``                  Whether to automatically apply labels from `pandas.Series`, `pandas.DataFrame`, and `xarray.DataArray` objects passed to plotting functions.
``alpha``                       The opacity of the background axes patch.
``axes.alpha``                  The opacity of the background axes patch.
``axes.titleabove``             Boolean, indicates whether to move the title and a-b-c labels above any "top" panels above axes.
``formatter.timerotation``      Float, indicates the default *x* axis tick label rotation for datetime tick labels.
``formatter.zerotrim``          Boolean, indicates whether trailing decimal zeros are trimmed on tick labels.
``formatter.limits``            Alias for :rcraw:`axes.formatter.limits`.
``formatter.use_locale``        Alias for :rcraw:`axes.formatter.use_locale`.
``formatter.use_mathtext``      Alias for :rcraw:`axes.formatter.use_mathtext`.
``formatter.min_exponent``      Alias for :rcraw:`axes.formatter.min_exponent`.
``formatter.use_offset``        Alias for :rcraw:`axes.formatter.useOffset`.
``formatter.offset_threshold``  Alias for :rcraw:`axes.formatter.offset_threshold`.
``basemap``                     Boolean, toggles whether basemap is the default backend.
``borders``                     Boolean, toggles country border lines on and off.
``borders.color``               Line color for country borders.
``borders.linewidth``           Line width for country borders.
``borders.zorder``              Z-order for country border lines.
``bottomlabel.color``           Font color for column labels on the bottom of the figure.
``bottomlabel.size``            Font size for column labels on the bottom of the figure.
``bottomlabel.weight``          Font weight for column labels on the bottom of the figure.
``cartopy.autoextent``          If ``False`` (the default), cartopy projection extents are global by default and no longer automatically adjusted based on plotted content.
``cartopy.circular``            If ``True`` (the default), polar cartopy projections like ``'npstere'`` and ``'spstere'`` are bounded with circles rather than squares.
``coast``                       Boolean, toggles coastline lines on and off.
``coast.color``                 Line color for coast lines.
``coast.linewidth``             Line width for coast lines.
``colorbar.extend``             Length of rectangular or triangular "extensions" for panel colorbars.  Interpreted by `~proplot.utils.units`.
``colorbar.framealpha``         Opacity for inset colorbar frames.
``colorbar.frameon``            Boolean, indicates whether to draw a frame behind inset colorbars.
``colorbar.grid``               Boolean, indicates whether to draw borders between each level of the colorbar.
``colorbar.insetextend``        Length of rectangular or triangular "extensions" for inset colorbars.  Interpreted by `~proplot.utils.units`.
``colorbar.insetlength``        Length of inset colorbars.  Interpreted by `~proplot.utils.units`.
``colorbar.insetpad``           Padding between axes edge and inset colorbars.  Interpreted by `~proplot.utils.units`.
``colorbar.insetwidth``         Width of inset colorbars.  Interpreted by `~proplot.utils.units`.
``colorbar.length``             Length of outer colorbars.
``colorbar.loc``                Inset colorbar location. For options, see the :ref:`location table <colorbar_table>`.
``colorbar.width``              Width of outer colorbars.  Interpreted by `~proplot.utils.units`.
``cmap``                        The default sequential colormap.
``color``                       The color of axis spines, tick marks, tick labels, and labels.
``cycle``                       The name of the color cycle used for plot elements like lines.
``facecolor``                   The color of the background axes patch.
``font.name``                   Alias for :rcraw:`font.family`. The default is ``'sans-serif'``.
``grid``                        Boolean, toggles major grid lines on and off.
``grid.below``                  Alias for :rcraw:`axes.axisbelow`. If ``False``, draw gridlines on top of everything. If ``True``, underneath everything. If ``'line'``, underneath patches only.
``grid.dmslabels``              Boolean, indicates whether to use degrees-minutes-seconds rather than decimals for gridline labels on `~proplot.axes.CartopyAxes`.
``grid.pad``                    Padding between map boundary edge and longitude and latitude labels for `~proplot.axes.GeoAxes`.  Interpreted by `~proplot.utils.units`.
``grid.labels``                 Boolean, indicates whether to label the longitude and latitude gridlines in `~proplot.axes.GeoAxes`.
``grid.labelsize``              Font size for longitude and latitude gridline labels in `~proplot.axes.GeoAxes`.
``grid.labelweight``            Font weight for longitude and latitude gridline labels in `~proplot.axes.GeoAxes`.
``grid.labelcolor``             Font color for longitude and latitude gridline labels in `~proplot.axes.GeoAxes`.
``grid.latinline``              Whether to use inline labels for `~proplot.axes.CartopyAxes` latitude gridlines.
``grid.loninline``              Whether to use inline labels for `~proplot.axes.CartopyAxes` longitude gridlines.
``grid.nsteps``                 Number of interpolation steps used to draw cartopy gridlines.
``grid.ratio``                  Ratio of minor gridline width to major gridline width.
``grid.rotatelabels``           Boolean, indicates whether to rotate longitude and latitude `~proplot.axes.CartopyAxes` gridline labels.
``gridminor``                   Boolean, toggles minor grid lines on and off.
``gridminor.alpha``             Minor gridline transparency.
``gridminor.color``             Minor gridline color.
``gridminor.latstep``           Latitude gridline interval for `~proplot.axes.GeoAxes` with global extent.
``gridminor.linestyle``         Minor gridline style.
``gridminor.linewidth``         Minor gridline width.
``gridminor.lonstep``           Interval for `~proplot.axes.GeoAxes` longitude gridlines in degrees.
``image.edgefix``               Whether to fix the `white-lines-between-filled-contours <https://stackoverflow.com/q/8263769/4970632>`__ and `white-lines-between-pcolor-rectangles <https://stackoverflow.com/q/27092991/4970632>`__ issues.
``image.levels``                Default number of levels for ``pcolormesh`` and ``contourf`` plots.
``inlinefmt``                   The inline backend figure format or list thereof. Valid formats include ``'svg'``, ``'pdf'``, ``'retina'``, ``'png'``, and ``jpeg``.
``innerborders``                Boolean, toggles internal political border lines (e.g. states and provinces) on and off.
``innerborders.color``          Line color for internal political borders.
``innerborders.linewidth``      Line width for internal political borders.
``innerborders.zorder``         Z-order for internal border lines.
``lakes``                       Boolean, toggles lake patches on and off.
``lakes.color``                 Face color for lake patches.
``lakes.zorder``                Z-order for lake patches.
``land``                        Boolean, toggles land patches on and off.
``land.color``                  Face color for land patches.
``land.zorder``                 Z-order for land patches.
``leftlabel.color``             Font color for row labels on the left-hand side.
``leftlabel.size``              Font size for row labels on the left-hand side.
``leftlabel.weight``            Font weight for row labels on the left-hand side.
``linewidth``                   Thickness of axes spines and major tick lines.
``lut``                         The number of colors to put in the colormap lookup table.
``margin``                      The margin of space between axes edges and objects plotted inside the axes if ``xlim`` and ``ylim`` are unset.
``negcolor``                    The color for negative bars and shaded areas when using ``negpos=True``. See also :rcraw:`poscolor`.
``poscolor``                    The color for positive bars and shaded areas when using ``negpos=True``. See also :rcraw:`negcolor`.
``ocean``                       Boolean, toggles ocean patches on and off.
``ocean.color``                 Face color for ocean patches.
``ocean.zorder``                Z-order for ocean patches.
``reso``                        Resolution for `~proplot.axes.GeoAxes` geographic features. Must be one of ``'lo'``, ``'med'``, ``'hi'``, ``'x-hi'``, or ``'xx-hi'``.
``rightlabel.color``            Font color for row labels on the right-hand side.
``rightlabel.size``             Font size for row labels on the right-hand side.
``rightlabel.weight``           Font weight for row labels on the right-hand side.
``rivers``                      Boolean, toggles river lines on and off.
``rivers.color``                Line color for river lines.
``rivers.linewidth``            Line width for river lines.
``rivers.zorder``               Z-order for river lines.
``subplots.align``              Whether to align axis labels during draw. See `aligning labels <https://matplotlib.org/3.1.1/gallery/subplots_axes_and_figures/align_labels_demo.html>`__.
``subplots.axpad``              Padding between adjacent subplots.  Interpreted by `~proplot.utils.units`.
``subplots.axwidth``            Default width of each axes.  Interpreted by `~proplot.utils.units`.
``subplots.pad``                Padding around figure edge.  Interpreted by `~proplot.utils.units`.
``subplots.panelpad``           Padding between subplots and panels, and between stacked panels.  Interpreted by `~proplot.utils.units`.
``subplots.panelwidth``         Width of side panels.  Interpreted by `~proplot.utils.units`.
``subplots.share``              The axis sharing level, one of ``0``, ``1``, ``2``, or ``3``. See :ref:`the user guide <ug_share>` for details.
``subplots.span``               Boolean, toggles spanning axis labels. See `~proplot.ui.subplots` for details.
``subplots.tight``              Boolean, indicates whether to auto-adjust figure bounds and subplot spacings.
``suptitle.color``              Figure title color.
``suptitle.size``               Figure title font size.
``suptitle.weight``             Figure title font weight.
``text.labelsize``              Meta setting that changes the label-like sizes ``tick.labelsize``, ``axes.labelsize``, ``legend.fontsize``, and ``grid.labelsize``. Default is ``'medium'``, i.e. the value of :rcraw:`font.size` (see `this list of valid font sizes <https://matplotlib.org/3.1.1/tutorials/text/text_props.html#default-font>`__).
``text.titlesize``              Meta setting that changes the title-like sizes ``abc.size``, ``title.size``, ``suptitle.size``, and row and column label sizes like ``leftlabel.size``. Default is ``'med-large'``, i.e. 1.1 times :rcraw:`font.size` (see `this list of valid font sizes <https://matplotlib.org/3.1.1/tutorials/text/text_props.html#default-font>`__).
``tick.color``                  Major and minor tick color.
``tick.dir``                    Major and minor tick direction. Must be one of ``'out'``, ``'in'``, or ``'inout'``.
``tick.labelcolor``             Axis tick label color. Mirrors the *axis* label :rcraw:`axes.labelcolor` setting.
``tick.labelsize``              Axis tick label font size. Mirrors the *axis* label :rcraw:`axes.labelsize` setting.
``tick.labelweight``            Axis tick label font weight. Mirrors the *axis* label :rcraw:`axes.labelweight` setting.
``tick.len``                    Length of major ticks in points.
``tick.lenratio``               Ratio of minor tickline length to major tickline length.
``tick.minor``                  Boolean, toggles minor ticks on and off.
``tick.pad``                    Padding between ticks and tick labels.  Interpreted by `~proplot.utils.units`.
``tick.ratio``                  Ratio of minor tickline width to major tickline width.
``title.above``                 Boolean, indicates whether to move outer titles and a-b-c labels above panels, colorbars, or legends that are above the axes.
``title.pad``                   Padding between the axes edge and the inner and outer titles and a-b-c labels. Alias for :rcraw:`axes.titlepad`.  Interpreted by `~proplot.utils.units`.
``title.border``                Boolean, indicates whether to draw a white border around titles when :rcraw:`title.loc` is inside the axes.
``title.borderwidth``           Width of the border around titles.
``title.bbox``                  Boolean, whether to draw semi-transparent bounding boxes around titles when :rcraw:`title.loc` is inside the axes.
``title.bboxcolor``             Axes title bounding box color.
``title.bboxstyle``             Axes title bounding box style.
``title.bboxalpha``             Axes title bounding box opacity.
``title.bboxpad``               Padding for the title bounding box. By default this is scaled to make the box flush against the axes edge.  Interpreted by `~proplot.utils.units`.
``title.color``                 Axes title color.
``title.loc``                   Title position. For options, see the :ref:`title location table <title_table>`.
``title.size``                  Axes title font size.
``title.weight``                Axes title font weight.
``toplabel.color``              Font color for column labels on the top of the figure.
``toplabel.size``               Font size for column labels on the top of the figure.
``toplabel.weight``             Font weight for column labels on the top of the figure.
==============================  =========================================================================================================================================================================================================================================================================================================================================