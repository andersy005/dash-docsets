.. rst-class:: proplot-rctable

==============================  ==============================================================================================================================================================================================================================================================================================================================================
Key                             Description
==============================  ==============================================================================================================================================================================================================================================================================================================================================
``style``                       The default matplotlib `stylesheet <https://matplotlib.org/stable/gallery/style_sheets/style_sheets_reference.html>`__ name. If ``None``, a custom proplot style is used. If ``'default'``, the default matplotlib style is used.
``abc``                         Boolean or string. If ``False`` then a-b-c labels are disabled. If ``True`` the default label style ``a`` is used. If string this indicates the style and must contain the character ``a`` or ``A``, for example ``'a.'`` or ``'(A)'``.
``abc.border``                  Boolean, indicates whether to draw a white border around a-b-c labels when :rcraw:`abc.loc` is inside the axes.
``abc.borderwidth``             Width of the white border around a-b-c labels.
``abc.bbox``                    Boolean, whether to draw semi-transparent bounding boxes around a-b-c labels when :rcraw:`abc.loc` is inside the axes.
``abc.bboxcolor``               a-b-c label bounding box color.
``abc.bboxstyle``               a-b-c label bounding box style.
``abc.bboxalpha``               a-b-c label bounding box opacity.
``abc.bboxpad``                 Padding for the a-b-c label bounding box. By default this is scaled to make the box flush against the subplot edge. Interpreted by `~proplot.utils.units`. Numeric units are points.
``abc.color``                   a-b-c label color.
``abc.loc``                     a-b-c label position. For options see the :ref:`location table <title_table>`.
``abc.size``                    a-b-c label font size. Must be a :ref:`relative font size <font_table>` or unit string interpreted by `~proplot.utils.units`. Numeric units are points.
``abc.titlepad``                Padding separating the title and a-b-c label when in the same location. Interpreted by `~proplot.utils.units`. Numeric units are points.
``abc.weight``                  a-b-c label font weight.
``autoformat``                  Whether to automatically apply labels from `pandas.Series`, `pandas.DataFrame`, and `xarray.DataArray` objects passed to plotting functions. See also :rcraw:`unitformat`.
``axes.alpha``                  Opacity of the background axes patch.
``axes.inbounds``               Whether to exclude out-of-bounds data when determining the default *y* (*x*) axis limits and the *x* (*y*) axis limits have been locked.
``axes.margin``                 The fractional *x* and *y* axis margins when limits are unset.
``axes.titleabove``             Boolean, indicates whether to move the title and a-b-c labels above any "top" panels above axes.
``basemap``                     Boolean, toggles whether basemap is the default backend.
``borders``                     Boolean, toggles country border lines on and off.
``borders.color``               Line color for country borders.
``borders.linewidth``           Line width for country borders.
``borders.zorder``              Z-order for country border lines.
``bottomlabel.color``           Font color for column labels on the bottom of the figure.
``bottomlabel.pad``             Padding between axes content and column labels on the bottom of the figure. Interpreted by `~proplot.utils.units`. Numeric units are points.
``bottomlabel.rotation``        Rotation for column labels at the bottom of the figure. Must be 'vertical', 'horizontal', or a float indicating degrees.
``bottomlabel.size``            Font size for column labels on the bottom of the figure. Must be a :ref:`relative font size <font_table>` or unit string interpreted by `~proplot.utils.units`. Numeric units are points.
``bottomlabel.weight``          Font weight for column labels on the bottom of the figure.
``cartopy.autoextent``          If ``False`` (the default), cartopy projection extents are global by default and no longer automatically adjusted based on plotted content.
``cartopy.circular``            If ``True`` (the default), polar cartopy projections like ``'npstere'`` and ``'spstere'`` are bounded with circles rather than squares.
``coast``                       Boolean, toggles coastline lines on and off.
``coast.color``                 Line color for coast lines.
``coast.linewidth``             Line width for coast lines.
``colorbar.edgecolor``          Color for colorbar dividers, outline, and inset frame edge.
``colorbar.extend``             Length of rectangular or triangular "extensions" for panel colorbars. Interpreted by `~proplot.utils.units`. Numeric units are em-widths.
``colorbar.framealpha``         Opacity for inset colorbar frames.
``colorbar.facecolor``          Color for the inset colorbar frame.
``colorbar.frameon``            Boolean, indicates whether to draw a frame behind inset colorbars.
``colorbar.grid``               Boolean, indicates whether to draw borders between each level of the colorbar.
``colorbar.insetextend``        Length of rectangular or triangular "extensions" for inset colorbars. Interpreted by `~proplot.utils.units`. Numeric units are em-widths.
``colorbar.insetlength``        Length of inset colorbars. Interpreted by `~proplot.utils.units`. Numeric units are em-widths.
``colorbar.insetpad``           Padding between axes edge and inset colorbars. Interpreted by `~proplot.utils.units`. Numeric units are em-widths.
``colorbar.insetwidth``         Width of inset colorbars. Interpreted by `~proplot.utils.units`. Numeric units are em-widths.
``colorbar.length``             Length of outer colorbars.
``colorbar.loc``                Inset colorbar location. For options see the :ref:`location table <colorbar_table>`.
``colorbar.width``              Width of outer colorbars. Interpreted by `~proplot.utils.units`. Numeric units are inches.
``colorbar.rasterize``          Whether to rasterize colorbar solids.
``cycle``                       Name of the color cycle assigned to :rcraw:`axes.prop_cycle`.
``cmap``                        Alias for :rcraw:`cmap.sequential` and :rcraw:`image.cmap`.
``cmap.autodiverging``          Boolean, whether to automatically apply a diverging colormap and normalizer based on the data.
``cmap.qualitative``            Default colormap for qualitative datasets.
``cmap.cyclic``                 Default colormap for cyclic datasets.
``cmap.discrete``               If ``True``, `~proplot.colors.DiscreteNorm` is used for every colormap plot. If ``False``, it is never used. If ``None``, it is used for all plot types except `imshow`, `matshow`, `spy`, `hexbin`, and `hist2d`.
``cmap.diverging``              Default colormap for diverging datasets.
``cmap.edgefix``                Whether to fix the `white-lines-between-filled-contours <https://stackoverflow.com/q/8263769/4970632>`__ and `white-lines-between-pcolor-rectangles <https://stackoverflow.com/q/27092991/4970632>`__ issues. If float, this linewidth is used to fix the issue.
``cmap.inbounds``               If ``True`` and the *x* and *y* axis limits are fixed, only in-bounds data is considered when determining the default colormap `vmin` and `vmax`.
``cmap.levels``                 Default number of `~proplot.colors.DiscreteNorm` levels for plotting commands that use colormaps.
``cmap.listedthresh``           Native `~matplotlib.colors.ListedColormap`\ s with more colors than this are converted to `~proplot.colors.ContinuousColormap` rather than `~proplot.colors.DiscreteColormap`. This helps translate perceptually uniform colormaps from other projects registered as ListedColormap.
``cmap.lut``                    Number of colors in the colormap lookup table. Alias for :rcraw:`image.lut`.
``cmap.robust``                 If ``True``, the default colormap `vmin` and `vmax` are chosen using the 2nd to 98th percentiles rather than the minimum and maximum.
``cmap.sequential``             Default colormap for sequential datasets. Alias for :rcraw:`image.cmap`.
``font.name``                   Alias for :rcraw:`font.family`.
``font.small``                  Alias for :rcraw:`font.smallsize`.
``font.smallsize``              Meta setting that changes the label-like sizes ``axes.labelsize``, ``legend.fontsize``, ``tick.labelsize``, and ``grid.labelsize``. Default is ``'medium'`` (equivalent to :rcraw:`font.size`). Must be a :ref:`relative font size <font_table>` or unit string interpreted by `~proplot.utils.units`. Numeric units are points.
``font.large``                  Alias for :rcraw:`font.largesize`.
``font.largesize``              Meta setting that changes the title-like sizes ``abc.size``, ``title.size``, ``suptitle.size``, ``leftlabel.size``, ``rightlabel.size``, etc. Default is ``'med-large'`` (i.e. 1.1 times :rcraw:`font.size`). Must be a :ref:`relative font size <font_table>` or unit string interpreted by `~proplot.utils.units`. Numeric units are points.
``formatter.timerotation``      Rotation for *x* axis datetime tick labels. Must be 'vertical', 'horizontal', or a float indicating degrees.
``formatter.zerotrim``          Boolean, indicates whether trailing decimal zeros are trimmed on tick labels.
``formatter.limits``            Alias for :rcraw:`axes.formatter.limits`.
``formatter.min_exponent``      Alias for :rcraw:`axes.formatter.min_exponent`.
``formatter.offset_threshold``  Alias for :rcraw:`axes.formatter.offset_threshold`.
``formatter.use_locale``        Alias for :rcraw:`axes.formatter.use_locale`.
``formatter.use_mathtext``      Alias for :rcraw:`axes.formatter.use_mathtext`.
``formatter.use_offset``        Alias for :rcraw:`axes.formatter.useOffset`.
``grid``                        Toggle major gridlines on and off.
``grid.below``                  Alias for :rcraw:`axes.axisbelow`. If ``True``, draw gridlines below everything. If ``True``, draw them above everything. If ``'line'``, draw them above patches but below lines and markers.
``grid.dmslabels``              Boolean, indicates whether to use degrees-minutes-seconds rather than decimals for gridline labels on cartopy `~proplot.axes.GeoAxes`.
``grid.inlinelabels``           Whether to use inline labels for cartopy `~proplot.axes.GeoAxes` longitude and latitude gridlines.
``grid.labels``                 Boolean, indicates whether to label the longitude and latitude gridlines in `~proplot.axes.GeoAxes`.
``grid.labelcolor``             Font color for longitude and latitude gridline labels in `~proplot.axes.GeoAxes`.
``grid.labelpad``               Padding between map boundary edge and longitude and latitude labels for `~proplot.axes.GeoAxes`. Interpreted by `~proplot.utils.units`. Numeric units are points.
``grid.labelsize``              Font size for longitude and latitude gridline labels in `~proplot.axes.GeoAxes`. Must be a :ref:`relative font size <font_table>` or unit string interpreted by `~proplot.utils.units`. Numeric units are points.
``grid.labelweight``            Font weight for longitude and latitude gridline labels in `~proplot.axes.GeoAxes`.
``grid.nsteps``                 Number of interpolation steps used to draw cartopy gridlines.
``grid.pad``                    Alias for :rcraw:`grid.labelpad`.
``grid.rotatelabels``           Boolean, indicates whether to rotate longitude and latitude gridline labels for cartopy `~proplot.axes.GeoAxes`.
``grid.style``                  Major gridline style. Alias for :rcraw:`grid.linestyle`.
``grid.width``                  Major gridline width. Alias for :rcraw:`grid.linewidth`.
``grid.widthratio``             Ratio of minor gridline width to major gridline width.
``gridminor``                   Toggle minor gridlines on and off.
``gridminor.alpha``             Minor gridline transparency.
``gridminor.color``             Minor gridline color.
``gridminor.linestyle``         Minor gridline style.
``gridminor.linewidth``         Minor gridline width.
``gridminor.style``             Minor gridline style. Alias for :rcraw:`gridminor.linestyle`.
``gridminor.width``             Minor gridline width. Alias for :rcraw:`gridminor.linewidth`.
``inlinefmt``                   The inline backend figure format. Valid formats include ``'svg'``, ``'pdf'``, ``'retina'``, ``'png'``, and ``jpeg``.
``innerborders``                Boolean, toggles internal political border lines (e.g. states and provinces) on and off.
``innerborders.color``          Line color for internal political borders.
``innerborders.linewidth``      Line width for internal political borders.
``innerborders.zorder``         Z-order for internal border lines.
``label.color``                 Alias for :rcraw:`axes.labelcolor`.
``label.pad``                   Alias for :rcraw:`axes.labelpad`. Interpreted by `~proplot.utils.units`. Numeric units are points.
``label.size``                  Alias for :rcraw:`axes.labelsize`. Must be a :ref:`relative font size <font_table>` or unit string interpreted by `~proplot.utils.units`. Numeric units are points.
``label.weight``                Alias for :rcraw:`axes.labelweight`.
``lakes``                       Boolean, toggles lake patches on and off.
``lakes.color``                 Face color for lake patches.
``lakes.zorder``                Z-order for lake patches.
``land``                        Boolean, toggles land patches on and off.
``land.color``                  Face color for land patches.
``land.zorder``                 Z-order for land patches.
``leftlabel.color``             Font color for row labels on the left-hand side.
``leftlabel.pad``               Padding between axes content and row labels on the left-hand side. Interpreted by `~proplot.utils.units`. Numeric units are points.
``leftlabel.rotation``          Rotation for row labels on the left-hand side. Must be 'vertical', 'horizontal', or a float indicating degrees.
``leftlabel.size``              Font size for row labels on the left-hand side. Must be a :ref:`relative font size <font_table>` or unit string interpreted by `~proplot.utils.units`. Numeric units are points.
``leftlabel.weight``            Font weight for row labels on the left-hand side.
``margin``                      The fractional *x* and *y* axis data margins when limits are unset. Alias for :rcraw:`axes.margin`.
``meta.edgecolor``              Color of axis spines, tick marks, tick labels, and labels.
``meta.color``                  Color of axis spines, tick marks, tick labels, and labels. Alias for :rcraw:`meta.edgecolor`.
``meta.linewidth``              Thickness of axis spines and major tick lines.
``meta.width``                  Thickness of axis spines and major tick lines. Alias for :rcraw:`meta.linewidth`.
``negcolor``                    Color for negative bars and shaded areas when using ``negpos=True``. See also :rcraw:`poscolor`.
``poscolor``                    Color for positive bars and shaded areas when using ``negpos=True``. See also :rcraw:`negcolor`.
``ocean``                       Boolean, toggles ocean patches on and off.
``ocean.color``                 Face color for ocean patches.
``ocean.zorder``                Z-order for ocean patches.
``reso``                        Resolution for `~proplot.axes.GeoAxes` geographic features. Must be one of ``'lo'``, ``'med'``, ``'hi'``, ``'x-hi'``, or ``'xx-hi'``.
``rightlabel.color``            Font color for row labels on the right-hand side.
``rightlabel.pad``              Padding between axes content and row labels on the right-hand side. Interpreted by `~proplot.utils.units`. Numeric units are points.
``rightlabel.rotation``         Rotation for row labels on the right-hand side. Must be 'vertical', 'horizontal', or a float indicating degrees.
``rightlabel.size``             Font size for row labels on the right-hand side. Must be a :ref:`relative font size <font_table>` or unit string interpreted by `~proplot.utils.units`. Numeric units are points.
``rightlabel.weight``           Font weight for row labels on the right-hand side.
``rivers``                      Boolean, toggles river lines on and off.
``rivers.color``                Line color for river lines.
``rivers.linewidth``            Line width for river lines.
``rivers.zorder``               Z-order for river lines.
``subplots.align``              Whether to align axis labels during draw. See `aligning labels <https://matplotlib.org/stable/gallery/subplots_axes_and_figures/align_labels_demo.html>`__.
``subplots.innerpad``           Padding between adjacent subplots. Interpreted by `~proplot.utils.units`. Numeric units are em-widths.
``subplots.outerpad``           Padding around figure edge. Interpreted by `~proplot.utils.units`. Numeric units are em-widths.
``subplots.panelpad``           Padding between subplots and panels, and between stacked panels. Interpreted by `~proplot.utils.units`. Numeric units are em-widths.
``subplots.panelwidth``         Width of side panels. Interpreted by `~proplot.utils.units`. Numeric units are inches.
``subplots.refwidth``           Default width of the reference subplot. Interpreted by `~proplot.utils.units`. Numeric units are inches.
``subplots.share``              The axis sharing level, one of ``0``, ``1``, ``2``, or ``3``, or the more intuitive aliases ``False``, ``'labels'``, ``'limits'``, or ``True``. See `~proplot.figure.Figure` for details.
``subplots.span``               Boolean, toggles spanning axis labels. See `~proplot.ui.subplots` for details.
``subplots.tight``              Boolean, indicates whether to auto-adjust figure bounds and subplot spacings.
``suptitle.color``              Figure title color.
``suptitle.size``               Figure title font size. Must be a :ref:`relative font size <font_table>` or unit string interpreted by `~proplot.utils.units`. Numeric units are points.
``suptitle.weight``             Figure title font weight.
``suptitle.pad``                Padding between axes content and the figure super title. Interpreted by `~proplot.utils.units`. Numeric units are points.
``tick.color``                  Major and minor tick color.
``tick.dir``                    Major and minor tick direction. Must be one of ``'out'``, ``'in'``, or ``'inout'``.
``tick.labelcolor``             Axis tick label color.
``tick.labelpad``               Padding between ticks and tick labels. Interpreted by `~proplot.utils.units`. Numeric units are points.
``tick.labelsize``              Axis tick label font size. Must be a :ref:`relative font size <font_table>` or unit string interpreted by `~proplot.utils.units`. Numeric units are points.
``tick.labelweight``            Axis tick label font weight.
``tick.len``                    Length of major ticks in points.
``tick.lenratio``               Ratio of minor tickline length to major tickline length.
``tick.linewidth``              Major tickline width.
``tick.minor``                  Boolean, toggles minor ticks on and off.
``tick.pad``                    Alias for :rcraw:`tick.labelpad`.
``tick.width``                  Major tickline width. Alias for :rcraw:`tick.linewidth`.
``tick.widthratio``             Ratio of minor tickline width to major tickline width.
``title.above``                 Boolean or string, indicates whether to move outer titles and a-b-c labels above panels, colorbars, or legends that are above the axes. If the string 'panels' then text is only redirected above axes panels.
``title.border``                Boolean, indicates whether to draw a white border around titles when :rcraw:`title.loc` is inside the axes.
``title.borderwidth``           Width of the border around titles.
``title.bbox``                  Boolean, whether to draw semi-transparent bounding boxes around titles when :rcraw:`title.loc` is inside the axes.
``title.bboxcolor``             Axes title bounding box color.
``title.bboxstyle``             Axes title bounding box style.
``title.bboxalpha``             Axes title bounding box opacity.
``title.bboxpad``               Padding for the title bounding box. By default this is scaled to make the box flush against the axes edge. Interpreted by `~proplot.utils.units`. Numeric units are points.
``title.color``                 Axes title color. Alias for :rcraw:`axes.titlecolor`.
``title.loc``                   Title position. For options see the :ref:`location table <title_table>`.
``title.pad``                   Padding between the axes edge and the inner and outer titles and a-b-c labels. Alias for :rcraw:`axes.titlepad`. Interpreted by `~proplot.utils.units`. Numeric units are points.
``title.size``                  Axes title font size. Alias for :rcraw:`axes.titlesize`. Must be a :ref:`relative font size <font_table>` or unit string interpreted by `~proplot.utils.units`. Numeric units are points.
``title.weight``                Axes title font weight. Alias for :rcraw:`axes.titleweight`.
``toplabel.color``              Font color for column labels on the top of the figure.
``toplabel.pad``                Padding between axes content and column labels on the top of the figure. Interpreted by `~proplot.utils.units`. Numeric units are points.
``toplabel.rotation``           Rotation for column labels at the top of the figure. Must be 'vertical', 'horizontal', or a float indicating degrees.
``toplabel.size``               Font size for column labels on the top of the figure. Must be a :ref:`relative font size <font_table>` or unit string interpreted by `~proplot.utils.units`. Numeric units are points.
``toplabel.weight``             Font weight for column labels on the top of the figure.
``unitformat``                  The format string used to format `pint.Quantity` default unit labels using ``format(units, unitformat)``. See also :rcraw:`autoformat`.
==============================  ==============================================================================================================================================================================================================================================================================================================================================