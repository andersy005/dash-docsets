az.plot_kde(mu_posterior, bw=0.4)
