lines = (('theta_t',{'school': "Choate"}, [-1]),)
az.plot_trace(data, var_names=('theta_t', 'theta'), coords=coords, lines=lines)
