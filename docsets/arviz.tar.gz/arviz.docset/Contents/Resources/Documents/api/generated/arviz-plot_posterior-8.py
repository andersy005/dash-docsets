az.plot_posterior(data, ref_val= {"theta": [{"school": "Deerfield", "ref_val": 4},
                                            {"school": "Choate", "ref_val": 3}]})
