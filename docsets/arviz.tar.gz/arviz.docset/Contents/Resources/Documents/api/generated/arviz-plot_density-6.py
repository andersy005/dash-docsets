az.plot_density([centered, non_centered], var_names=["mu"], outline=False, shade=.8)
