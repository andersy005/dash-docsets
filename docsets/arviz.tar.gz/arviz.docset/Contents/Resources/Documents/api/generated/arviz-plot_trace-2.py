az.plot_trace(data, compact=True)
