az.plot_trace(data, var_names=["mu", "tau"], kind="rank_bars")
