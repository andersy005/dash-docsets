az.plot_posterior(data, var_names=['mu', 'theta'], ref_val=0)
