az.plot_density([centered, non_centered], grid=(4, 5))
