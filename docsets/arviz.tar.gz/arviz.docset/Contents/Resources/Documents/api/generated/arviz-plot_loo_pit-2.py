az.plot_loo_pit(idata=idata, y="y", ecdf=True)
