az.plot_ppc(data, var_names=["y"], alpha=0.3, num_pp_samples=50)
