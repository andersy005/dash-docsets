az.plot_dist(b, rug=True)
