az.plot_kde(mu_posterior, values2=tau_posterior)
