az.plot_posterior(emcee_data, var_names=var_names[:3])
