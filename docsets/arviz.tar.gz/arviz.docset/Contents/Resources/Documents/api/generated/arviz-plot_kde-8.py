az.plot_kde(mu_posterior, rotated=True)
