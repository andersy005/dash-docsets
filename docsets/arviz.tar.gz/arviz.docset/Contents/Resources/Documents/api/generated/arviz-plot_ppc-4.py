az.plot_ppc(data, kind='scatter', flatten=[],
            coords={'obs_id': ['AITKIN', 'BELTRAMI']})
