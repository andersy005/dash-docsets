az.plot_rank(noncentered_data, var_names="mu", kind="vlines",
             vlines_kwargs={'lw':0}, marker_vlines_kwargs={'lw':3});
