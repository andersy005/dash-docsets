az.plot_violin(data, var_names="tau", transform=np.log)
