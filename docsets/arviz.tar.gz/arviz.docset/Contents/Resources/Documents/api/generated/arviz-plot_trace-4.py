az.plot_trace(
    data, var_names=('^theta'), filter_vars="regex", coords=coords, combined=True
)
