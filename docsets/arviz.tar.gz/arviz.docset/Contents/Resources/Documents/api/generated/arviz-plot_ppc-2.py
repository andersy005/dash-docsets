az.plot_ppc(data, kind='cumulative')
