az.plot_density([centered, non_centered], var_names=["mu"], group="prior")
