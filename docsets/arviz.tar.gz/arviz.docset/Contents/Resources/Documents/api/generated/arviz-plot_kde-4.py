az.plot_kde(mu_posterior, bw="scott")
