az.plot_pair(centered,
            var_names=['theta', 'mu'],
            coords=coords,
            textsize=18,
            kind='hexbin')
