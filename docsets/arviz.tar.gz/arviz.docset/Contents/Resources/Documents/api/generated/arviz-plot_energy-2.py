az.plot_energy(data, kind='hist')
