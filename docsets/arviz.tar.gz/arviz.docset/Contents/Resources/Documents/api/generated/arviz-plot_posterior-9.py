az.plot_posterior(data, ref_val=[1] + [5] * 8 + [1])
