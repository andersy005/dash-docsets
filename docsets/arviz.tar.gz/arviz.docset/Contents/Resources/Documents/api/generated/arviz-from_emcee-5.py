az.plot_trace(emcee_data, var_names=["var_2"], coords={"var_2_dim_0": 4})
