az.plot_kde(mu_posterior, adaptive=True)
