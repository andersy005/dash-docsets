az.plot_parallel(data, var_names=["mu", "tau"], norm_method='normal')
