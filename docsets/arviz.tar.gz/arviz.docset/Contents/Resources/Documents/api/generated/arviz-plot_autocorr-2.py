az.plot_autocorr(data, var_names=['mu', 'tau'] )
