rope = {'mu': [{'rope': (-2, 2)}], 'theta': [{'school': 'Choate', 'rope': (2, 4)}]}
az.plot_posterior(data, var_names=['mu', 'theta'], rope=rope)
