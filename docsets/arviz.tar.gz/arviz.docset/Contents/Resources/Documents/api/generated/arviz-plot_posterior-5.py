coords = {"school": ["Choate","Phillips Exeter"]}
az.plot_posterior(data, var_names=["mu", "theta"], coords=coords)
