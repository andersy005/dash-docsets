az.plot_compare(model_compare, insample_dev=False)
