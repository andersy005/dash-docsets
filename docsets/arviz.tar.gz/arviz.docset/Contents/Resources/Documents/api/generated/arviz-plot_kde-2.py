az.plot_kde(mu_posterior, rug=True)
