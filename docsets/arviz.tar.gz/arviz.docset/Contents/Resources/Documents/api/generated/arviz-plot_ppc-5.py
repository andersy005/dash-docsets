az.plot_ppc(data, num_pp_samples=30, random_seed=7)
