az.plot_autocorr(data, var_names=['mu', 'tau'], max_lag=200, combined=True)
