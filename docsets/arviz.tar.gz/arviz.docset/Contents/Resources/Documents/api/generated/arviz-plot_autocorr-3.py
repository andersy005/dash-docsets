az.plot_autocorr(data, var_names=['~thet'], filter_vars="like", combined=True)
