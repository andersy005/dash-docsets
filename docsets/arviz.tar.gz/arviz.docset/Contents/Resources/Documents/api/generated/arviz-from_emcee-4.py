emcee_data = az.from_emcee(sampler, slices=[0, 1, slice(2, None)])
