az.plot_posterior(data, var_names=['mu', '^the'], filter_vars="regex", rope=(-1, 1))
