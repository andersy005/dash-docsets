az.plot_posterior(data, var_names=['mu'], hdi_prob=.75)
