az.plot_ess(
    idata, kind="evolution", var_names=["mu", "theta"], coords=coords
)
