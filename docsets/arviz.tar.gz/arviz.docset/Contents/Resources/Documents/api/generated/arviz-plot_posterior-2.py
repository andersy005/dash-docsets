az.plot_posterior(data, var_names=['mu'])
