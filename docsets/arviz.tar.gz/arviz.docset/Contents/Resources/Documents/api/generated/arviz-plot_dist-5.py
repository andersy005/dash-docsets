az.plot_dist(b, rug=True, quantiles=[.25, .5, .75], cumulative=True)
