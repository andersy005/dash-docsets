b = np.random.normal(0, 1, 1000)
az.plot_dist(b)
