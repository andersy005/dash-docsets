az.plot_pair(centered,
            var_names=['^t', 'mu'],
            filter_vars="regex",
            coords=coords,
            divergences=True,
            textsize=18)
