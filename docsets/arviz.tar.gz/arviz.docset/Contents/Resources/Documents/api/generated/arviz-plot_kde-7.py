az.plot_kde(mu_posterior, cumulative=True)
