(function() {
  var fn = function() {
    
    (function(root) {
      function now() {
        return new Date();
      }
    
      var force = false;
    
      if (typeof root._bokeh_onload_callbacks === "undefined" || force === true) {
        root._bokeh_onload_callbacks = [];
        root._bokeh_is_loading = undefined;
      }
    
      
      
    
      var element = document.getElementById("b7b30741-9432-4576-8332-7b925b377d09");
        if (element == null) {
          console.warn("Bokeh: autoload.js configured with elementid 'b7b30741-9432-4576-8332-7b925b377d09' but no matching script tag was found.")
        }
      
    
      function run_callbacks() {
        try {
          root._bokeh_onload_callbacks.forEach(function(callback) {
            if (callback != null)
              callback();
          });
        } finally {
          delete root._bokeh_onload_callbacks
        }
        console.debug("Bokeh: all callbacks have finished");
      }
    
      function load_libs(css_urls, js_urls, callback) {
        if (css_urls == null) css_urls = [];
        if (js_urls == null) js_urls = [];
    
        root._bokeh_onload_callbacks.push(callback);
        if (root._bokeh_is_loading > 0) {
          console.debug("Bokeh: BokehJS is being loaded, scheduling callback at", now());
          return null;
        }
        if (js_urls == null || js_urls.length === 0) {
          run_callbacks();
          return null;
        }
        console.debug("Bokeh: BokehJS not loaded, scheduling load and callback at", now());
        root._bokeh_is_loading = css_urls.length + js_urls.length;
    
        function on_load() {
          root._bokeh_is_loading--;
          if (root._bokeh_is_loading === 0) {
            console.debug("Bokeh: all BokehJS libraries/stylesheets loaded");
            run_callbacks()
          }
        }
    
        function on_error(url) {
          console.error("failed to load " + url);
        }
    
        for (let i = 0; i < css_urls.length; i++) {
          const url = css_urls[i];
          const element = document.createElement("link");
          element.onload = on_load;
          element.onerror = on_error.bind(null, url);
          element.rel = "stylesheet";
          element.type = "text/css";
          element.href = url;
          console.debug("Bokeh: injecting link tag for BokehJS stylesheet: ", url);
          document.body.appendChild(element);
        }
    
        const hashes = {"https://cdn.bokeh.org/bokeh/release/bokeh-2.3.2.min.js": "XypntL49z55iwGVUW4qsEu83zKL3XEcz0MjuGOQ9SlaaQ68X/g+k1FcioZi7oQAc", "https://cdn.bokeh.org/bokeh/release/bokeh-tables-2.3.2.min.js": "bEsM86IHGDTLCS0Zod8a8WM6Y4+lafAL/eSiyQcuPzinmWNgNO2/olUF0Z2Dkn5i", "https://cdn.bokeh.org/bokeh/release/bokeh-widgets-2.3.2.min.js": "TX0gSQTdXTTeScqxj6PVQxTiRW8DOoGVwinyi1D3kxv7wuxQ02XkOxv0xwiypcAH"};
    
        for (let i = 0; i < js_urls.length; i++) {
          const url = js_urls[i];
          const element = document.createElement('script');
          element.onload = on_load;
          element.onerror = on_error.bind(null, url);
          element.async = false;
          element.src = url;
          if (url in hashes) {
            element.crossOrigin = "anonymous";
            element.integrity = "sha384-" + hashes[url];
          }
          console.debug("Bokeh: injecting script tag for BokehJS library: ", url);
          document.head.appendChild(element);
        }
      };
    
      function inject_raw_css(css) {
        const element = document.createElement("style");
        element.appendChild(document.createTextNode(css));
        document.body.appendChild(element);
      }
    
      
      var js_urls = ["https://cdn.bokeh.org/bokeh/release/bokeh-2.3.2.min.js", "https://cdn.bokeh.org/bokeh/release/bokeh-widgets-2.3.2.min.js", "https://cdn.bokeh.org/bokeh/release/bokeh-tables-2.3.2.min.js"];
      var css_urls = [];
      
    
      var inline_js = [
        function(Bokeh) {
          Bokeh.set_log_level("info");
        },
        
        function(Bokeh) {
          (function() {
            var fn = function() {
              Bokeh.safely(function() {
                (function(root) {
                  function embed_document(root) {
                    
                  var docs_json = '{"e35c7f5d-24fa-4d74-95ac-3c10db4d8242":{"defs":[],"roots":{"references":[{"attributes":{},"id":"37259","type":"BasicTickFormatter"},{"attributes":{},"id":"37214","type":"WheelZoomTool"},{"attributes":{},"id":"37261","type":"AllLabels"},{"attributes":{"overlay":{"id":"37220"}},"id":"37215","type":"LassoSelectTool"},{"attributes":{"line_alpha":0.7,"line_width":1.5,"location":0},"id":"37237","type":"Span"},{"attributes":{"callback":null},"id":"37218","type":"HoverTool"},{"attributes":{},"id":"37217","type":"SaveTool"},{"attributes":{},"id":"37180","type":"UndoTool"},{"attributes":{},"id":"37216","type":"UndoTool"},{"attributes":{"callback":null},"id":"37182","type":"HoverTool"},{"attributes":{"overlay":{"id":"37184"}},"id":"37179","type":"LassoSelectTool"},{"attributes":{"line_alpha":0.7,"line_width":1.5,"location":0},"id":"37251","type":"Span"},{"attributes":{"text":"tau"},"id":"37242","type":"Title"},{"attributes":{},"id":"37195","type":"DataRange1d"},{"attributes":{"line_alpha":0.5,"line_width":1.5,"location":0.2515582690238702},"id":"37235","type":"Span"},{"attributes":{"children":[[{"id":"37158"},0,0],[{"id":"37194"},0,1]]},"id":"37286","type":"GridBox"},{"attributes":{"text":"mu"},"id":"37256","type":"Title"},{"attributes":{"overlay":{"id":"37183"}},"id":"37177","type":"BoxZoomTool"},{"attributes":{"angle":{"value":1.5707963267948966},"line_alpha":{"value":0.35},"marker":{"value":"dash"},"size":{"value":8},"x":{"field":"rug_x"},"y":{"field":"rug_y"}},"id":"37252","type":"Scatter"},{"attributes":{},"id":"37281","type":"UnionRenderers"},{"attributes":{},"id":"37176","type":"PanTool"},{"attributes":{"fill_color":{"value":"#1f77b4"},"line_color":{"value":"#1f77b4"},"x":{"field":"x"},"y":{"field":"y"}},"id":"37231","type":"Circle"},{"attributes":{},"id":"37175","type":"ResetTool"},{"attributes":{"toolbars":[{"id":"37185"},{"id":"37221"}],"tools":[{"id":"37175"},{"id":"37176"},{"id":"37177"},{"id":"37178"},{"id":"37179"},{"id":"37180"},{"id":"37181"},{"id":"37182"},{"id":"37211"},{"id":"37212"},{"id":"37213"},{"id":"37214"},{"id":"37215"},{"id":"37216"},{"id":"37217"},{"id":"37218"}]},"id":"37287","type":"ProxyToolbar"},{"attributes":{},"id":"37181","type":"SaveTool"},{"attributes":{"data":{"rug_x":{"__ndarray__":"fV36E1z/6j89DycBWWfXP73VlTJ7YsE/w8E5M5BGxz/DwTkzkEbHP8PBOTOQRsc/w8E5M5BGxz/DwTkzkEbHP8PBOTOQRsc/w8E5M5BGxz/DwTkzkEbHP8PBOTOQRsc/w8E5M5BGxz/DwTkzkEbHP8PBOTOQRsc/w8E5M5BGxz9P6PYIJnnCP0/o9ggmecI/T+j2CCZ5wj9P6PYIJnnCP0/o9ggmecI/T+j2CCZ5wj9P6PYIJnnCP0/o9ggmecI/txiR/XzQvD+3GJH9fNC8P7cYkf180Lw/txiR/XzQvD+3GJH9fNC8P7cYkf180Lw/Oqay45Jr6D86SHRMZcflP7HThSU1z+I/VdSaCTtd6D9Hvab2ZmSwP8UA5kQ6d4M/0GULqag1oz+aI/Yi4T7rP55DEK8H/NA/qgGd6qjX1D+VqnS/h2ThP/UnuP7VN+Q/TGXHJdeQ2z8=","dtype":"float64","order":"little","shape":[43]},"rug_y":{"__ndarray__":"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=","dtype":"float64","order":"little","shape":[43]}},"selected":{"id":"37284"},"selection_policy":{"id":"37283"}},"id":"37253","type":"ColumnDataSource"},{"attributes":{},"id":"37282","type":"Selection"},{"attributes":{},"id":"37178","type":"WheelZoomTool"},{"attributes":{"axis":{"id":"37171"},"dimension":1,"ticker":null},"id":"37174","type":"Grid"},{"attributes":{},"id":"37262","type":"BasicTickFormatter"},{"attributes":{"below":[{"id":"37167"}],"center":[{"id":"37170"},{"id":"37174"}],"height":500,"left":[{"id":"37171"}],"output_backend":"webgl","renderers":[{"id":"37233"},{"id":"37235"},{"id":"37236"},{"id":"37237"},{"id":"37240"}],"title":{"id":"37242"},"toolbar":{"id":"37185"},"toolbar_location":null,"width":500,"x_range":{"id":"37159"},"x_scale":{"id":"37163"},"y_range":{"id":"37161"},"y_scale":{"id":"37165"}},"id":"37158","subtype":"Figure","type":"Plot"},{"attributes":{"source":{"id":"37253"}},"id":"37255","type":"CDSView"},{"attributes":{},"id":"37264","type":"AllLabels"},{"attributes":{"line_alpha":0.5,"line_width":0.75,"location":0.15209716424958658},"id":"37250","type":"Span"},{"attributes":{"below":[{"id":"37203"}],"center":[{"id":"37206"},{"id":"37210"}],"height":500,"left":[{"id":"37207"}],"output_backend":"webgl","renderers":[{"id":"37247"},{"id":"37249"},{"id":"37250"},{"id":"37251"},{"id":"37254"}],"title":{"id":"37256"},"toolbar":{"id":"37221"},"toolbar_location":null,"width":500,"x_range":{"id":"37195"},"x_scale":{"id":"37199"},"y_range":{"id":"37197"},"y_scale":{"id":"37201"}},"id":"37194","subtype":"Figure","type":"Plot"},{"attributes":{"data_source":{"id":"37244"},"glyph":{"id":"37245"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"37246"},"view":{"id":"37248"}},"id":"37247","type":"GlyphRenderer"},{"attributes":{"line_alpha":0.5,"line_width":0.75,"location":0.1782444431478369},"id":"37236","type":"Span"},{"attributes":{},"id":"37159","type":"DataRange1d"},{"attributes":{"fill_color":{"value":"#1f77b4"},"line_color":{"value":"#1f77b4"},"x":{"field":"x"},"y":{"field":"y"}},"id":"37245","type":"Circle"},{"attributes":{"data":{"rug_x":{"__ndarray__":"jQwCEA1Gsz9bBMLb9PjIP1Qd9Zram7E/yuyJRU9bmT/K7IlFT1uZP8rsiUVPW5k/yuyJRU9bmT/K7IlFT1uZP8rsiUVPW5k/yuyJRU9bmT/K7IlFT1uZP8rsiUVPW5k/yuyJRU9bmT/K7IlFT1uZP8rsiUVPW5k/yuyJRU9bmT/zis1V/mKlP/OKzVX+YqU/84rNVf5ipT/zis1V/mKlP/OKzVX+YqU/84rNVf5ipT/zis1V/mKlP/OKzVX+YqU/aF85wG2piz9oXznAbamLP2hfOcBtqYs/aF85wG2piz9oXznAbamLP2hfOcBtqYs/pI3yRkqEyT9c/+ob+nG6P4OiBeyjALU/mx4fY+a33D9wF2c1cbTRPy51Aws2htg/P07TEgOYwz9FOncTGHy5P/BQ+ANPucc/uRO6PYJJzj9CRCWTDYpmP+UvVnGFsrI/8JR71fNwcj8=","dtype":"float64","order":"little","shape":[43]},"rug_y":{"__ndarray__":"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=","dtype":"float64","order":"little","shape":[43]}},"selected":{"id":"37270"},"selection_policy":{"id":"37269"}},"id":"37239","type":"ColumnDataSource"},{"attributes":{"bottom_units":"screen","fill_alpha":0.5,"fill_color":"lightgrey","left_units":"screen","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"right_units":"screen","syncable":false,"top_units":"screen"},"id":"37219","type":"BoxAnnotation"},{"attributes":{"data":{"x":{"__ndarray__":"mpmZmZmZqT/SjhUII+24P2wor6G8hsI/bolTv+eWyD9w6vfcEqfOP7klTv2eW9I/O1YgjLRj1T+8hvIaymvYPz23xKnfc9s/vueWOPV73j8gjLRjBcLgP2GkHSsQRuI/oryG8hrK4z/i1O+5JU7lPyPtWIEw0uY/YwXCSDtW6D+kHSsQRtrpP+U1lNdQXus/JU79nlvi7D9mZmZmZmbuPw==","dtype":"float64","order":"little","shape":[20]},"y":{"__ndarray__":"bcJe+Pxh3D88Eu5SUq3NPyL+eQAns8s/mzeOVbYJ1z+YvNPsmzTWP87j+UyletE/sIr1s8Bnzz8YN/msnr7PP8gPs0h4ec8/RNGUEkZ90z8g12riYrDUP+AlTxYjYc4/UBTOvdhAzD+AFwpyJ0DOPxDSzcUXbc4/kDNyJsikyj9AY0p3Si3PP8AWdsF70MQ/4I8dAXxLyD+grhW5nZrSPw==","dtype":"float64","order":"little","shape":[20]}},"selected":{"id":"37282"},"selection_policy":{"id":"37281"}},"id":"37244","type":"ColumnDataSource"},{"attributes":{"source":{"id":"37239"}},"id":"37241","type":"CDSView"},{"attributes":{"angle":{"value":1.5707963267948966},"line_alpha":{"value":0.35},"marker":{"value":"dash"},"size":{"value":8},"x":{"field":"rug_x"},"y":{"field":"rug_y"}},"id":"37238","type":"Scatter"},{"attributes":{},"id":"37283","type":"UnionRenderers"},{"attributes":{"data_source":{"id":"37239"},"glyph":{"id":"37238"},"hover_glyph":null,"muted_glyph":null,"view":{"id":"37241"}},"id":"37240","type":"GlyphRenderer"},{"attributes":{},"id":"37284","type":"Selection"},{"attributes":{"bottom_units":"screen","fill_alpha":0.5,"fill_color":"lightgrey","left_units":"screen","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"right_units":"screen","syncable":false,"top_units":"screen"},"id":"37183","type":"BoxAnnotation"},{"attributes":{},"id":"37212","type":"PanTool"},{"attributes":{"fill_alpha":0.5,"fill_color":"lightgrey","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"syncable":false,"xs_units":"screen","ys_units":"screen"},"id":"37220","type":"PolyAnnotation"},{"attributes":{"data":{"x":{"__ndarray__":"mpmZmZmZqT/SjhUII+24P2wor6G8hsI/bolTv+eWyD9w6vfcEqfOP7klTv2eW9I/O1YgjLRj1T+8hvIaymvYPz23xKnfc9s/vueWOPV73j8gjLRjBcLgP2GkHSsQRuI/oryG8hrK4z/i1O+5JU7lPyPtWIEw0uY/YwXCSDtW6D+kHSsQRtrpP+U1lNdQXus/JU79nlvi7D9mZmZmZmbuPw==","dtype":"float64","order":"little","shape":[20]},"y":{"__ndarray__":"TOY7mm62yD/upazjteTNP/DqXfy8Lcs/HHCIRHVOzT9orzckCyTOP6y8CkfbP8w/iNx/9NF5yz+IfM+LFJ/NPygi8KloJ8w/oK0q3zNVzD/YcLH58jHPP6hWLqhoMNQ/IGaMl5nu0j8AebTCVJLRP+D0hUiIM80/uNpKBpu90z/A00Fq0J3TP2iCFjW8ldY/kLBgWUSo1j8QCPgZgPnXPw==","dtype":"float64","order":"little","shape":[20]}},"selected":{"id":"37268"},"selection_policy":{"id":"37267"}},"id":"37230","type":"ColumnDataSource"},{"attributes":{},"id":"37273","type":"BasicTickFormatter"},{"attributes":{},"id":"37168","type":"BasicTicker"},{"attributes":{},"id":"37275","type":"AllLabels"},{"attributes":{"fill_alpha":0.5,"fill_color":"lightgrey","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"syncable":false,"xs_units":"screen","ys_units":"screen"},"id":"37184","type":"PolyAnnotation"},{"attributes":{"end":1,"start":-0.05},"id":"37161","type":"DataRange1d"},{"attributes":{"axis_label":"Quantile","formatter":{"id":"37259"},"major_label_policy":{"id":"37261"},"ticker":{"id":"37168"}},"id":"37167","type":"LinearAxis"},{"attributes":{},"id":"37172","type":"BasicTicker"},{"attributes":{},"id":"37267","type":"UnionRenderers"},{"attributes":{"active_multi":null,"tools":[{"id":"37211"},{"id":"37212"},{"id":"37213"},{"id":"37214"},{"id":"37215"},{"id":"37216"},{"id":"37217"},{"id":"37218"}]},"id":"37221","type":"Toolbar"},{"attributes":{},"id":"37276","type":"BasicTickFormatter"},{"attributes":{},"id":"37268","type":"Selection"},{"attributes":{},"id":"37278","type":"AllLabels"},{"attributes":{},"id":"37163","type":"LinearScale"},{"attributes":{"toolbar":{"id":"37287"},"toolbar_location":"above"},"id":"37288","type":"ToolbarBox"},{"attributes":{"source":{"id":"37230"}},"id":"37234","type":"CDSView"},{"attributes":{"fill_alpha":{"value":0.1},"fill_color":{"value":"#1f77b4"},"line_alpha":{"value":0.1},"line_color":{"value":"#1f77b4"},"x":{"field":"x"},"y":{"field":"y"}},"id":"37246","type":"Circle"},{"attributes":{"line_alpha":0.5,"line_width":1.5,"location":0.2148430013731262},"id":"37249","type":"Span"},{"attributes":{"active_multi":null,"tools":[{"id":"37175"},{"id":"37176"},{"id":"37177"},{"id":"37178"},{"id":"37179"},{"id":"37180"},{"id":"37181"},{"id":"37182"}]},"id":"37185","type":"Toolbar"},{"attributes":{"axis_label":"MCSE for quantiles","formatter":{"id":"37262"},"major_label_policy":{"id":"37264"},"ticker":{"id":"37172"}},"id":"37171","type":"LinearAxis"},{"attributes":{"children":[{"id":"37288"},{"id":"37286"}]},"id":"37289","type":"Column"},{"attributes":{"data_source":{"id":"37253"},"glyph":{"id":"37252"},"hover_glyph":null,"muted_glyph":null,"view":{"id":"37255"}},"id":"37254","type":"GlyphRenderer"},{"attributes":{"source":{"id":"37244"}},"id":"37248","type":"CDSView"},{"attributes":{"fill_alpha":{"value":0.1},"fill_color":{"value":"#1f77b4"},"line_alpha":{"value":0.1},"line_color":{"value":"#1f77b4"},"x":{"field":"x"},"y":{"field":"y"}},"id":"37232","type":"Circle"},{"attributes":{},"id":"37165","type":"LinearScale"},{"attributes":{"axis_label":"Quantile","formatter":{"id":"37273"},"major_label_policy":{"id":"37275"},"ticker":{"id":"37204"}},"id":"37203","type":"LinearAxis"},{"attributes":{},"id":"37269","type":"UnionRenderers"},{"attributes":{"end":1,"start":-0.05},"id":"37197","type":"DataRange1d"},{"attributes":{"axis_label":"MCSE for quantiles","formatter":{"id":"37276"},"major_label_policy":{"id":"37278"},"ticker":{"id":"37208"}},"id":"37207","type":"LinearAxis"},{"attributes":{},"id":"37199","type":"LinearScale"},{"attributes":{},"id":"37270","type":"Selection"},{"attributes":{},"id":"37201","type":"LinearScale"},{"attributes":{},"id":"37211","type":"ResetTool"},{"attributes":{},"id":"37204","type":"BasicTicker"},{"attributes":{"axis":{"id":"37203"},"ticker":null},"id":"37206","type":"Grid"},{"attributes":{"axis":{"id":"37167"},"ticker":null},"id":"37170","type":"Grid"},{"attributes":{"axis":{"id":"37207"},"dimension":1,"ticker":null},"id":"37210","type":"Grid"},{"attributes":{},"id":"37208","type":"BasicTicker"},{"attributes":{"overlay":{"id":"37219"}},"id":"37213","type":"BoxZoomTool"},{"attributes":{"data_source":{"id":"37230"},"glyph":{"id":"37231"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"37232"},"view":{"id":"37234"}},"id":"37233","type":"GlyphRenderer"}],"root_ids":["37289"]},"title":"Bokeh Application","version":"2.3.2"}}';
                  var render_items = [{"docid":"e35c7f5d-24fa-4d74-95ac-3c10db4d8242","root_ids":["37289"],"roots":{"37289":"b7b30741-9432-4576-8332-7b925b377d09"}}];
                  root.Bokeh.embed.embed_items(docs_json, render_items);
                
                  }
                  if (root.Bokeh !== undefined) {
                    embed_document(root);
                  } else {
                    var attempts = 0;
                    var timer = setInterval(function(root) {
                      if (root.Bokeh !== undefined) {
                        clearInterval(timer);
                        embed_document(root);
                      } else {
                        attempts++;
                        if (attempts > 100) {
                          clearInterval(timer);
                          console.log("Bokeh: ERROR: Unable to run BokehJS code because BokehJS library is missing");
                        }
                      }
                    }, 10, root)
                  }
                })(window);
              });
            };
            if (document.readyState != "loading") fn();
            else document.addEventListener("DOMContentLoaded", fn);
          })();
        },
        function(Bokeh) {
        
        
        }
      ];
    
      function run_inline_js() {
        
        for (var i = 0; i < inline_js.length; i++) {
          inline_js[i].call(root, root.Bokeh);
        }
        
      }
    
      if (root._bokeh_is_loading === 0) {
        console.debug("Bokeh: BokehJS loaded, going straight to plotting");
        run_inline_js();
      } else {
        load_libs(css_urls, js_urls, function() {
          console.debug("Bokeh: BokehJS plotting callback run at", now());
          run_inline_js();
        });
      }
    }(window));
  };
  if (document.readyState != "loading") fn();
  else document.addEventListener("DOMContentLoaded", fn);
})();