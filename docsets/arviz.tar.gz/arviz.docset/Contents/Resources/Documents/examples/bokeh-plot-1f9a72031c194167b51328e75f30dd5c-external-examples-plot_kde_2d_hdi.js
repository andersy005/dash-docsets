(function() {
  var fn = function() {
    
    (function(root) {
      function now() {
        return new Date();
      }
    
      var force = false;
    
      if (typeof root._bokeh_onload_callbacks === "undefined" || force === true) {
        root._bokeh_onload_callbacks = [];
        root._bokeh_is_loading = undefined;
      }
    
      
      
    
      var element = document.getElementById("8e5f0f0a-f198-4c8f-aff3-10786c88ad98");
        if (element == null) {
          console.warn("Bokeh: autoload.js configured with elementid '8e5f0f0a-f198-4c8f-aff3-10786c88ad98' but no matching script tag was found.")
        }
      
    
      function run_callbacks() {
        try {
          root._bokeh_onload_callbacks.forEach(function(callback) {
            if (callback != null)
              callback();
          });
        } finally {
          delete root._bokeh_onload_callbacks
        }
        console.debug("Bokeh: all callbacks have finished");
      }
    
      function load_libs(css_urls, js_urls, callback) {
        if (css_urls == null) css_urls = [];
        if (js_urls == null) js_urls = [];
    
        root._bokeh_onload_callbacks.push(callback);
        if (root._bokeh_is_loading > 0) {
          console.debug("Bokeh: BokehJS is being loaded, scheduling callback at", now());
          return null;
        }
        if (js_urls == null || js_urls.length === 0) {
          run_callbacks();
          return null;
        }
        console.debug("Bokeh: BokehJS not loaded, scheduling load and callback at", now());
        root._bokeh_is_loading = css_urls.length + js_urls.length;
    
        function on_load() {
          root._bokeh_is_loading--;
          if (root._bokeh_is_loading === 0) {
            console.debug("Bokeh: all BokehJS libraries/stylesheets loaded");
            run_callbacks()
          }
        }
    
        function on_error(url) {
          console.error("failed to load " + url);
        }
    
        for (let i = 0; i < css_urls.length; i++) {
          const url = css_urls[i];
          const element = document.createElement("link");
          element.onload = on_load;
          element.onerror = on_error.bind(null, url);
          element.rel = "stylesheet";
          element.type = "text/css";
          element.href = url;
          console.debug("Bokeh: injecting link tag for BokehJS stylesheet: ", url);
          document.body.appendChild(element);
        }
    
        const hashes = {"https://cdn.bokeh.org/bokeh/release/bokeh-2.3.2.min.js": "XypntL49z55iwGVUW4qsEu83zKL3XEcz0MjuGOQ9SlaaQ68X/g+k1FcioZi7oQAc", "https://cdn.bokeh.org/bokeh/release/bokeh-tables-2.3.2.min.js": "bEsM86IHGDTLCS0Zod8a8WM6Y4+lafAL/eSiyQcuPzinmWNgNO2/olUF0Z2Dkn5i", "https://cdn.bokeh.org/bokeh/release/bokeh-widgets-2.3.2.min.js": "TX0gSQTdXTTeScqxj6PVQxTiRW8DOoGVwinyi1D3kxv7wuxQ02XkOxv0xwiypcAH"};
    
        for (let i = 0; i < js_urls.length; i++) {
          const url = js_urls[i];
          const element = document.createElement('script');
          element.onload = on_load;
          element.onerror = on_error.bind(null, url);
          element.async = false;
          element.src = url;
          if (url in hashes) {
            element.crossOrigin = "anonymous";
            element.integrity = "sha384-" + hashes[url];
          }
          console.debug("Bokeh: injecting script tag for BokehJS library: ", url);
          document.head.appendChild(element);
        }
      };
    
      function inject_raw_css(css) {
        const element = document.createElement("style");
        element.appendChild(document.createTextNode(css));
        document.body.appendChild(element);
      }
    
      
      var js_urls = ["https://cdn.bokeh.org/bokeh/release/bokeh-2.3.2.min.js", "https://cdn.bokeh.org/bokeh/release/bokeh-widgets-2.3.2.min.js", "https://cdn.bokeh.org/bokeh/release/bokeh-tables-2.3.2.min.js"];
      var css_urls = [];
      
    
      var inline_js = [
        function(Bokeh) {
          Bokeh.set_log_level("info");
        },
        
        function(Bokeh) {
          (function() {
            var fn = function() {
              Bokeh.safely(function() {
                (function(root) {
                  function embed_document(root) {
                    
                  var docs_json = '{"f9ad5ea0-f4ff-46c9-b897-8ecb71bd9a8e":{"defs":[],"roots":{"references":[{"attributes":{"children":[{"id":"21183"},{"id":"21181"}]},"id":"21184","type":"Column"},{"attributes":{"fill_color":"#4a98c9","line_alpha":0.25,"line_color":"#4a98c9","x":{"field":"x"},"y":{"field":"y"}},"id":"21153","type":"Patch"},{"attributes":{"fill_color":"#1764ab","line_alpha":0.25,"line_color":"#1764ab","x":{"field":"x"},"y":{"field":"y"}},"id":"21158","type":"Patch"},{"attributes":{"source":{"id":"21157"}},"id":"21161","type":"CDSView"},{"attributes":{},"id":"21116","type":"LinearScale"},{"attributes":{},"id":"21177","type":"Selection"},{"attributes":{},"id":"21128","type":"ResetTool"},{"attributes":{"data":{"x":{"__ndarray__":"pMHr6WsXoD8xPxeUyp+gP0CgS0dbvqI/CZCRSqCQpD+7GsB/P36pPysCTnDl3K8/xVXf8r2dsj/nGAnp8YC1P/lckQ6vb7o/QNmQo2D6vD8m4S5XjlrAP2bM2Eb8uMM/zaK6kudtxz8w8b3RyUrIP964dbwX3so/YgNEEBTwzj/gutmoMQzRP27yzPhB2tE/XawdjZNt1D8ofdRo/vLVP7ZC58oYdNc/cD/PKMvZ2j+Fsoi/s/7aP0cmHIPkjd4/sAHK6JfA3z/4LPe6rPngP/xhYlSyU+I/FvexB9Gf4j9Q3Vwl81TkPyDDX7QYx+Q/7HOWCBcp5j9EJF0UfzrnP3Slna8dKeg/aIVadOWt6T+mwfPLgX3qP4zmV9RLIew/P0MYVjTQ7D+wR1U0spTuPwh7Iy984u4/alQpSgyE8D8Re2rwZ7LwP/wEKHq/vfE/HliUP8tZ8j+MtSaqcvfyPx14WAYFE/Q/IGYl2iUx9D+wFiQK2Wr1P/8pNe900fU/QMciOoyk9j9009ZdUW/3P9R3IWo/3vc/UmR4YUsQ+T9kKCCa8hf5P/jYHsqlUfo/kiN9obMR+z+IiR36WIv7Pxw6HCoMxfw/NJSQkX0u/T+s6hpav/79P0CbGYpyOP8/mwFVBrGS/z/oJQzdEjkAQDB+C3Xs1QBAcLCiTUNbAUB61goNxnIBQMIuCqWfDwJADIcJPXmsAkBU3wjVUkkDQHZPZphXXgNAnjcIbSzmA0DmjwcFBoMEQDDoBp3fHwVAeEAGNbm8BUDAmAXNklkGQArxBGVs9gZAUkkE/UWTB0CcoQOVHzAIQOT5Ai35zAhALlICxdJpCUB2qgFdrAYKQL8CAfWFowpACFsAjV9AC0A0qxv8R1QLQFCz/yQ53QtAae+0uup2DECaC/+8EnoMQOJj/lTsFg1AxQy+tKNeDUAsvP3sxbMNQLjhZvtAHg5AdBT9hJ9QDkDm+fbVEZYOQLts/Bx57Q5A73HpsW0PD0DBsKQf4oUPQAbF+7RSig9AJD18vgXaD0CruxgfAgUQQGK2GrRlEhBAp459JpYTEEDAUhiOKR4QQL2htcu8IhBAnmTzFAchEECxS77XRSIQQB5p0kscJxBA8fOhBEcoEEBIh/a+biQQQMRbGDP0GxBAp459JpYTEEDhGgSdTAwQQJ6LhYyZ6g9AhfNHHBaxD0AGxfu0UooPQO4rhfYZfw9AAvymuD9WD0CAVdg7ZR8PQLxs/Bx57Q5AjWwtl4fUDkBcO05kQoAOQHQU/YSfUA5ACHiJ2dEoDkCqVQ1dZMwNQCy8/ezFsw1AuOiswrBmDUDiY/5U7BYNQO7Q1SiP9wxArAvakO+LDECaC/+8EnoMQDTB+XdeKAxAULP/JDndC0Cn4KrAJ74LQETBeKq8RQtACVsAjV9AC0ArVnqovLoKQL8CAfWFowpAr4rG5f8eCkB3qgFdrAYKQBo7PkaAfwlALlICxdJpCUD2FL/gg/IIQOT5Ai35zAhA0vZtodFpCECcoQOVHzAIQHiNWupg0QdAUkkE/UWTB0BUeOLe/xQHQArxBGVs9gZAwJgFzZJZBkCoanNWxTcGQHhABjW5vAVAfIjg81teBUAw6Aad3x8FQOaPBwUGgwRAAuLo54p7BECeNwhtLOYDQAIgwhNBkANAVN8I1VJJA0AMhwk9eawCQI9eupyGlAJAwi4KpZ8PAkAj25ej+HwBQHrWCg3GcgFAMH4LdezVAEDoJQzdEjkAQGFbntj0DwBAQJsZinI4/z+s6hpav/79P+bzLFsI6vw/HDocKgzF/D+IiR36WIv7P/jYHsqlUfo/ZCggmvIX+T8aqAsq0xT5P9R3IWo/3vc/QMciOoyk9j+wFiQK2Wr1PyBmJdolMfQ/jLUmqnL38j/8BCh6v73xP2pUKUoMhPA/sEdVNLKU7j+M5lfUSyHsP4LAKepj9es/aIVadOWt6T9EJF0UfzrnPyDDX7QYx+Q/M5MsHCwS4z/8YWJUslPiP7AByuiXwN8/qjoMFdBo3T9wP88oy9naP7QVfEHyKtY/KH3UaP7y1T/gutmoMQzRPyBlidfixsk/MPG90clKyD9jsJ/UiKfFPxT+Q7gShME/QdmQo2D6vD9LUyhB1Oa6P8WtxU1t5LU/B5nor3ewsj9MOJZ7zYWuP3BWflJIKKY/QKBLR1u+oj+kwevpaxegP2pUKUoMhPA/sMTUTOeH8D9aAyI7oQXxP/wEKHq/vfE/SWdzA5Tl8T+NtSaqcvfyPzNC2LRx//I/IGYl2iUx9D9aosOFLWf1P7AWJArZavU/QMciOoyk9j/UdyFqP973P2QoIJryF/k/+NgeyqVR+j+IiR36WIv7Pxw6HCoMxfw/rOoaWr/+/T+u7tDnoSj/P0CbGYpyOP8/6CUM3RI5AEAwfgt17NUAQG/yQ0d1GwFAetYKDcZyAUDCLgqlnw8CQPFa2TNlJgJADIcJPXmsAkC1JzaPxBkDQFTfCNVSSQNAnjcIbSzmA0BmjMEQ5O0DQOaPBwUGgwRALHuDIZWOBEDn4156UB4FQDDoBp3fHwVADFSA6BOoBUB4QAY1ubwFQCEopW0wIQZAwJgFzZJZBkBqWXnXAYYGQM8T591H5AZACvEEZWz2BkAEhlNjtj4HQDtiPcXCiQdAUkkE/UWTB0BE8/tEV8oHQCZ0Bt2B/QdATNN8U/UjCECcoQOVHzAIQI0bxzO0PAhA1MUrvuhHCEB74ZlMUEQIQJyhA5UfMAhAU3zrwAgnCEBgMCleA/gHQEOiaQW0xwdAUkkE/UWTB0CFFgh4lG0HQArxBGVs9gZAnqgnylKaBkDAmAXNklkGQHhABjW5vAVAPdKtQh8/BUAw6Aad3x8FQOaPBwUGgwRAnjcIbSzmA0BU3wjVUkkDQAyHCT15rAJAkeqI2lVyAkDCLgqlnw8CQHrWCg3GcgFAMH4LdezVAEDoJQzdEjkAQKOUtKPMIABAQJsZinI4/z+s6hpav/79P9NY4Dtk1/0/HDocKgzF/D/gZB/tXCH8P4mJHfpYi/s/EQ3w+/WI+j/42B7KpVH6P2QoIJryF/k/P31z73X2+D/UdyFqP973P7QEQ2Zhevc/QMciOoyk9j/wRQX3Lkz2P7AWJArZavU/hPXIT76f9D8gZiXaJTH0PzbcY5Pu0PM/f67FJg0S8z+MtSaqcvfyP0RG8sQdgfI/2ssVMGQD8j/8BCh6v73xP5ZfwDikkPE/XcuvijYs8T9UVylFjuLwP7b2m9LotfA/4ggjeOOY8D9qVClKDITwP08vZnByffA/alQpSgyE8D8=","dtype":"float64","order":"little","shape":[310]},"y":{"__ndarray__":"eNJcm+ch8z/J8BFhP0b0P9JLIhnt0/Q/HA/HJpdq9T9sLXzs7o72P7xLMbJGs/c/EGrmd57X+D9giJs99vv5P7CmUANOIPs/ZJ4r8l6O+z8AxQXJpUT8P1Djuo79aP0/pAFwVFWN/j8wVaXnXtD+P/QfJRqtsf8/Ih/tbwJrAEDi5GdY1MkAQEyux1Iu/QBAdD2iNVqPAUBqyzPkFdYBQJzMfBiGIQJAhtOy21OtAkDEW1f7sbMCQOzqMd7dRQNAypOEsJd1A0AWegzBCdgDQPcYxhfrTwRAPgnnozVqBEBmmMGGYfwEQDwmwtRmIAVAkCecaY2OBUDfjPQahtwFQLi2dky5IAZAKUyqRcd/BkDgRVEv5bIGQEyRnHomGgdACNUrEhFFB0ABEtbDj8MHQDBkBvU81wdA+XlJarFWCEBa8+DXaGkIQDaAwIghxghAgoK7upT7CED8jbukcS8JQKoRlp3AjQlAD+UEvhiYCUDVQabHEP8JQNSgcIDsHwpA/wSEgBBpCkD8L0tjGLIKQFyfokvY2wpAJL8lRkREC0A5vuBk1EYLQFxm4tqSpAtATE4AKXDWC0CHxs3ZrvcLQKut5nGyTAxAdN3aC5xoDEBS13ZLtqEMQJhFa38c6QxAnmy17sf6DECwvGs/oCoNQCoE0FeTZA1Ax/uP0fOMDUDmmqQALpUNQDfZELUSxQ1AAZRLD/jwDUBgxXks0hkOQO6KarQfHw5ArpbNBOVIDkBwMwOS8XMOQCS13th+jg5AK4ifW6+bDkBmaZVJGqQOQGRVCr/oqA5AMZMwjlGkDkChAFpCzZ4OQBl06UjTmg5Anaj5uuKFDkCyZytxZGMOQJEfSinIRA5AkRIzMFclDkDuimq0Hx8OQBSsM7Eb7A1AxvuP0fOMDUCjV4u5u4oNQOj4islhKA1Anmy17sf6DEByudkJDsQMQHTd2gucaAxA5g26ayEpDEBMTgApcNYLQAZoYdxSbQtAJL8lRkREC0D8L0tjGLIKQLF4wdwvrApA1KBwgOwfCkCqEZadwI0JQIKCu7qU+whAhbD+/kfrCEBa8+DXaGkIQDBkBvU81wdACdUrEhFFB0DgRVEv5bIGQLi2dky5IAZAkCecaY2OBUBmmMGGYfwEQD4J56M1agRAxhRF8ywgBEAWegzBCdgDQOzqMd7dRQNAxFtX+7GzAkCeRS07j0UCQJzMfBiGIQJAdD2iNVqPAUBMrsdSLv0AQBT0P0JenQBAIh/tbwJrAED0HyUarbH/P7qR+sgtGP8/pAFwVFWN/j9Q47qO/Wj9PwLOmLm8JP0/AMUFyaVE/D/evuIzS3T7P7CmUANOIPs/YIibPfb7+T+oe74zC8r5PxBq5nee1/g/a9za7ZsJ+D+8SzGyRrP3P2wtfOzujvY/OKJEgYeD9j8cD8cml2r1P6prev2rP/U/yPARYT9G9D8OuIloPRr0P3jSXJvnIfM/0J2yqxr48j8otKfVj/3xP26GTZWjq/E/2JXyDzjZ8D/CN5Y9GV/wPwzvepTAae8/KgTriw+Q7j9oshAJESHtP8b8hgNdzuw/K2dTxmY16z/IdaZ9YdjqP44iQu9ViOk/KDk88rGP6D9mbOMe1eLnP7FTR9twWeY/hPzRZgJH5j/hAXB8gM7kP+C/Z9tS/uM/jyEsA09R4z9EI22a9urhP0CD/U+jteE/6qSmRgGP4D9AjSaJ59nePyJG/xtert4/ePgqjlt33D8LBAbUrbDaP/gTUnKISNo/iDmJAp8M2T84Q5PChTPXP7CafVspt9U/VBnK56J/1T8qBX41exLUP440mSw1odI/izm3vVYo0T9wIalEyiXRP8tHytt4ItA/nIhfjHwyzz8PSaDpsnnOP5R5qBrq0c0/EYzDji42zT+mxZA0f1LNP2TgxtNRZM4/9dBjPpoZ0D83Ps4mjRrRP3AhqUTKJdE/3sNhHFKU0T97Z/csyELSP8xqQHXb89M/sJp9Wym31T/f6Ec1GYDWP5I4zKYa/tg/+BNScohI2j/NWcecX7PbP0CNJonn2d4/M3p2C7wL3z9Ag/1Po7XhP+C/Z9tS/uM/8F+C3PSw5D+E/NFmAkfmPyg5PPKxj+g/jK1Tudw66j/IdaZ9YdjqP2iyEAkRIe0/DO96lMBp7z/YlfIPONnwPyi0p9WP/fE/Wyez196w8j940lyb5yHzP2hQIqvCDPg/vEsxskaz9z9sLXzs7o72Py0kWxGMm/U/HA/HJpdq9T9wnXRpy0z0P8jwEWE/RvQ/PBxpdN2V8z940lyb5yHzP9CJ+LeLIPM/xLEpnlHK8j9CpcFOKpzyPxQtUNlvmfI/GqIZYyOS8j9+DN4BuH/yP9ZiwNMGifI/CPTd0D3C8j950lyb5yHzP0F49DP1JvM/OLtBA2OU8z8DyQ0IAAX0P8jwEWE/RvQ/VPsy+VqY9D9gxIhHP0/1PxwPxyaXavU/pjvmyhwQ9j9sLXzs7o72Py9MpahQy/Y//zUr926m9z+8SzGyRrP3P2miZlCxwfg/EGrmd57X+D9giJs99vv5P7odoK1O//k/sKZQA04g+z/5Ijl7t1H7PwDFBcmlRPw/cOH675Xn/D9Q47qO/Wj9P6QBcFRVjf4/44ID80rG/j/0HyUarbH/PyIf7W8CawBAokI/Y8+AAEBMrsdSLv0AQHQ9ojVajwFAnMx8GIYhAkB9CBpuzWwCQMRbV/uxswJA7Oox3t1FA0AWegzBCdgDQFIKnw02OwRAPgnnozVqBEBmmMGGYfwEQJAnnGmNjgVA2CwxNtv0BUC4tnZMuSAGQAWEpomOeAZA4EVRL+WyBkDz6rghG90GQDpvX5Y/KQdACNUrEhFFB0B7ldwRqEoHQADIyUICZgdANZuo3mNzB0BOYxpdm2oHQFe2OicbUQdACNUrEhFFB0BMJCmdBTAHQHQY7K69EAdA6/DCn+/tBkDumBc3b7wGQOBFUS/lsgZA80Agy0J8BkCiNQQn3SwGQLi2dky5IAZAxZ4sMyXHBUCQJ5xpjY4FQJMTxN4YWQVAZpjBhmH8BED6juBGB+gEQE/t9E5MdgRAPgnnozVqBED2pooTSAAEQBZ6DMEJ2ANAp/3fQgxzA0Ds6jHe3UUDQMRbV/uxswJAnMx8GIYhAkCw1F4UTdMBQHQ9ojVajwFATK7HUi79AED7WQcr8OIAQCIf7W8CawBA9B8lGq2x/z+Q1BhbYAD/P6QBcFRVjf4/UOO6jv1o/T8AxQXJpUT8P7CmUANOIPs/X4ibPfb7+T82svU88Bz5PxBq5nee1/g/aFAiq8IM+D8=","dtype":"float64","order":"little","shape":[310]}},"selected":{"id":"21177"},"selection_policy":{"id":"21176"}},"id":"21152","type":"ColumnDataSource"},{"attributes":{"children":[[{"id":"21111"},0,0]]},"id":"21181","type":"GridBox"},{"attributes":{"data":{"x":{"__ndarray__":"MbbyeZeQ779LCDq2kg7wv4YqFbJXAfC/FUe25Feu778kwUsuYBTvv8g0aStNsO6/wYHcjkVG7r/AXjSxy7Ttv8TYA8DdOO2/aWvl/gqp7L+k02vL5jzsvz1+LXnPO+y/XvMz8UH167/84IIHAIvrv0Yqg2XPBeu/CpkA/PBQ6r+Acm5rgMnpv8Bo35M/fum/VrLIE0996L9gEXELGlbnvxplEnZMM+e/qQRYZxt85r9SLYBrHtXlvzywc6uz4uS/e29V4ve85L9cyEEwDT/jvxhPdktNb+K/cAnJFxSG4b/o2/HWzfffv4FEkhqF5d+/JjX3SEsg3b+gGfcWARHbvx6VsLEHj9q/iVdelqjf179YV/xWNCrWv0FgTSuuhtS/EJUBl2dD0b/CA7hQ4ZHQv5ClDa41uci/6Ido4qBxv78BQjBcONe9v8re0EJ1YKe/AHKKuAp4pL9U/5N1qXSTP0CgS0dbvqI/6v/jGoYasT9A2ZCjYPq8P14Sydqx178/MPG90clKyD9kvX3UFIXKP+C62agxDNE/543UoT/60T/sjxJP0wjVPyh91Gj+8tU/K3+lh+tM2D9wP88oy9naP8OGEso9Wt0/sAHK6JfA3z/nsei8qQPiP/xhYlSyU+I/IMNftBjH5D/Loe3GVu7kP0QkXRR/Ouc/xXbCqrMp6D9ohVp05a3pP6Ilw1+fW+s/jOZX1Esh7D/tOs54jNjtP7BHVTSylO4/NirEzuw28D9qVClKDITwP/wEKHq/vfE/2W/9+EnU8T+MtSaqcvfyP67s8a3FafM/IGYl2iUx9D9S09xQa1H1P68WJArZavU/QMciOoyk9j/UdyFqP973P7scDsctc/g/ZCggmvIX+T/42B7KpVH6P1AQuXOsRvs/iIkd+liL+z8cOhwqDMX8P6tQIue13f0/rOoaWr/+/T9AmxmKcjj/P5XeGg3XKABA6CUM3RI5AEAwfgt17NUAQDfaHvGeUwFAetYKDcZyAUDCLgqlnw8CQAyHCT15rAJAJjppYzg+A0BU3wjVUkkDQJ43CG0s5gNA5o8HBQaDBEAw6Aad3x8FQMF/njQvLAVAeEAGNbm8BUDAmAXNklkGQArxBGVs9gZAsKT6zJsbB0BSSQT9RZMHQJyhA5UfMAhA5PkCLfnMCEAuUgLF0mkJQHaqAV2sBgpAvgIB9YWjCkAIWwCNX0ALQFCz/yQ53QtAmgv/vBJ6DEDiY/5U7BYNQCy8/ezFsw1AdBT9hJ9QDkC8bPwcee0OQHWVD7hhDA9ABsX7tFKKD0Cnjn0mlhMQQC2C2HmLTBBAzDp98gJiEEDw5ny+b7AQQPabARN4uRBAFZN8itz+EEA5P3xWSU0RQF7reyK2mxFAVnlvPcSxEUCCl3vuIuoRQKZDe7qPOBJALCxpophGEkDL73qG/IYSQOSzlDNNsRJA7H1pxYbGEkDvm3pSadUSQCx2qKMb6hJAFEh6HtYjE0D2ime9NC8TQIuo1stTbhNAOPR56kJyE0BMMwKHs5MTQD76pf8UrxNAXaB5tq/AE0APkAJhp9ITQHWCfgg16BNAcmmzBRniE0C+fZm+G9cTQHOOodhW8RNAgUx5ghwPFED+yBZS6TQUQNo6sefASxRAqyILHhBMFEDkjdgzMUkUQEQJxvm+QhRAChnq/KgxFECDRPX3ABwUQHWSdxY1FRRA1YulM5wVFECBTHmCHA8UQK99HhH0DRRAN1i8khABFEDxQEsbe/ETQIIWi0Si4RNAI685NGrOE0BeoHm2r8ATQCwhdT/CshNAATWOKUOOE0A49HnqQnITQOazf1CnZRNACok95HREE0D66gDScSYTQBRIeh7WIxNAKVDY3hUKE0DurqqBmt8SQO+belJp1RJAk79eWKnDEkBGKUmqs7sSQM6g+vSEpRJAy+96hvyGEkBVUJ/nwXkSQBhal904ORJApkN7uo84EkBSXssWJvARQIKXe+4i6hFA/sOqJqqxEUBe63sitpsRQBG90OyMgxFAtTEzeoVhEUA5P3xWSU0RQC4QAlxuPxFAfpBxraETEUAVk3yK3P4QQHfDejJY1RBA8OZ8vm+wEECSd0L9dYcQQMw6ffICYhBAIZx1eDI7EECnjn0mlhMQQC4fRSuq7Q9ABsX7tFKKD0AYPEkrrWoPQLxs/Bx57Q5AyYxGKGvgDkB0FP2En1AOQPBb+s6pPQ5ALLz97MWzDUDwkPHWcIsNQOJj/lTsFg1AhlBy0dnvDECaC/+8EnoMQIaiSFSBZQxAULP/JDndC0BnntFlUcgLQAhbAI1fQAtA3tiKYRMRC0C+AgH1haMKQDq0VQpeYwpAdqoBXawGCkC0BI0Db7gJQC5SAsXSaQlAzvpW9J74CEDk+QIt+cwIQOje5ZfPOwhAnKEDlR8wCEBSSQT9RZMHQNFf1AvlaQdACvEEZWz2BkDkxetuZ3UGQMCYBc2SWQZAeEAGNbm8BUB8HLYKSWcFQDDoBp3fHwVA5o8HBQaDBEBUI51qdzgEQJ43CG0s5gNAVN8I1VJJA0CmzZ4abdwCQAyHCT15rAJAwi4KpZ8PAkAVf3Xq6t0BQHrWCg3GcgFAMH4LdezVAEBIhj3DkmUAQOglDN0SOQBAQJsZinI4/z+s6hpav/79P62gVrw/zP0/HDocKgzF/D+IiR36WIv7P3V5SnhEePo/+NgeyqVR+j9kKCCa8hf5P9R3IWo/3vc/AExmd/Ox9j9AxyI6jKT2P7AWJArZavU/IGYl2iUx9D+MtSaqcvfyP/wEKHq/vfE/w8hLp9LV8D9qVClKDITwP7BHVTSylO4/jeZX1Esh7D9ohVp05a3pP0QkXRR/Ouc/9HEedlxm5j8gw1+0GMfkP/xhYlSyU+I/IrVI0U0L4T+vAcrol8DfP3A/zyjL2do/KH3UaP7y1T/gutmoMQzRPxDVgk7jfMw/MPG90clKyD9A2ZCjYPq8P1aR+qyK/qs/QKBLR1u+oj8Acoq4Cnikv7HCaN1+27S/AEIwXDjXvb+QpQ2uNbnIvxCVAZdnQ9G/HxyH/Acn1b9YV/xWNCrWv/agTEZOmte/oBn3FgER27+MDV5H98Tcv+jb8dbN99+/O8zPMQsc4r8YT3ZLTW/ivzywc6uz4uS/oDAYODSc5r9gEXELGlbnv6WX737if+e/eXvpffKE578Zw5v1yZfnv4r6UdT9gei/gHJua4DJ6b+WzP+z5Kjqv6TTa8vmPOy/CLtYDr787L9EgISjuU/tvxoAcID5Ce2/pPrCw4B17b/ojijMkkDuv86QMqQMVu6/c+RLvFqN7r/INGkrTbDuvzG28nmXkO+/QKBLR1u+oj9wVn5SSCimP0w4lnvNha4/B5nor3ewsj/FrcVNbeS1P0tTKEHU5ro/QNmQo2D6vD8U/kO4EoTBP2Own9SIp8U/L/G90clKyD8gZYnX4sbJP+C62agxDNE/J33UaP7y1T+0FXxB8irWP3A/zyjL2do/qjoMFdBo3T+wAcrol8DfP/xhYlSyU+I/M5MsHCwS4z8gw1+0GMfkP0QkXRR/Ouc/aIVadOWt6T+CwCnqY/XrP4zmV9RLIew/sEdVNLKU7j9qVClKDITwP/wEKHq/vfE/jLUmqnL38j8gZiXaJTH0P7AWJArZavU/QMciOoyk9j/UdyFqP973PxuoCyrTFPk/ZCggmvIX+T/42B7KpVH6P4iJHfpYi/s/HDocKgzF/D/m8yxbCOr8P6zqGlq//v0/QJsZinI4/z9hW57Y9A8AQOglDN0SOQBAMH4LdezVAEB61goNxnIBQCPbl6P4fAFAwi4KpZ8PAkCPXrqchpQCQAyHCT15rAJAVN8I1VJJA0ACIMITQZADQJ43CG0s5gNAAuLo54p7BEDmjwcFBoMEQDDoBp3fHwVAfIjg81teBUB4QAY1ubwFQKdqc1bFNwZAwJgFzZJZBkAK8QRlbPYGQFR44t7/FAdAUkkE/UWTB0B4jVrqYNEHQJyhA5UfMAhA0vZtodFpCEDk+QIt+cwIQPYUv+CD8ghALlICxdJpCUAaOz5GgH8JQHaqAV2sBgpAr4rG5f8eCkC+AgH1haMKQCtWeqi8ugpACFsAjV9AC0BEwXiqvEULQKfgqsAnvgtAULP/JDndC0A0wfl3XigMQJoL/7wSegxArAvakO+LDEDt0NUoj/cMQONj/lTsFg1AuOiswrBmDUAsvP3sxbMNQKlVDV1kzA1ACHiJ2dEoDkB0FP2En1AOQFw7TmRCgA5AjWwtl4fUDkC8bPwcee0OQIBV2DtlHw9AAvymuD9WD0DuK4X2GX8PQAbF+7RSig9AhfNHHBaxD0Cei4WMmeoPQOEaBJ1MDBBAp459JpYTEEDEWxgz9BsQQEiH9r5uJBBA8fOhBEcoEEAeadJLHCcQQLFLvtdFIhBAnmTzFAchEEC+obXLvCIQQMBSGI4pHhBAp459JpYTEEBithq0ZRIQQKu7GB8CBRBAJD18vgXaD0AHxfu0UooPQMGwpB/ihQ9A73HpsW0PD0C8bPwcee0OQOb59tURlg5AdBT9hJ9QDkC44Wb7QB4OQCy8/ezFsw1Axgy+tKNeDUDiY/5U7BYNQJoL/7wSegxAae+0uup2DEBQs/8kOd0LQDSrG/xHVAtACFsAjV9AC0C+AgH1haMKQHaqAV2sBgpALlICxdJpCUDk+QIt+cwIQJyhA5UfMAhAUkkE/UWTB0AK8QRlbPYGQMCYBc2SWQZAeEAGNbm8BUAw6Aad3x8FQOaPBwUGgwRAnjcIbSzmA0B2T2aYV14DQFTfCNVSSQNADIcJPXmsAkDCLgqlnw8CQHrWCg3GcgFAcLCiTUNbAUAwfgt17NUAQOglDN0SOQBAmwFVBrGS/z9BmxmKcjj/P6zqGlq//v0/NJSQkX0u/T8cOhwqDMX8P4iJHfpYi/s/kiN9obMR+z/42B7KpVH6P2QoIJryF/k/UmR4YUsQ+T/UdyFqP973P3LT1l1Rb/c/QMciOoyk9j//KTXvdNH1P7AWJArZavU/IGYl2iUx9D8deFgGBRP0P4y1Jqpy9/I/HliUP8tZ8j/8BCh6v73xPxB7avBnsvA/alQpSgyE8D8IeyMvfOLuP7BHVTSylO4/P0MYVjTQ7D+M5lfUSyHsP6bB88uBfeo/aIVadOWt6T90pZ2vHSnoP0QkXRR/Ouc/7HOWCBcp5j8gw1+0GMfkP1DdXCXzVOQ/FvexB9Gf4j/8YWJUslPiP/gs97qs+eA/sAHK6JfA3z9IJhyD5I3eP4WyiL+z/to/cD/PKMvZ2j+3QufKGHTXPyh91Gj+8tU/XKwdjZNt1D9t8sz4QdrRP+C62agxDNE/YgNEEBTwzj/euHW8F97KPzDxvdHJSsg/zaK6kudtxz9mzNhG/LjDPybhLleOWsA/QNmQo2D6vD/5XJEOr2+6P+cYCenxgLU/xVXf8r2dsj8rAk5w5dyvP7wawH8/fqk/CJCRSqCQpD9AoEtHW76iPzE/F5TKn6A/pMHr6WsXoD9AoEtHW76iPw==","dtype":"float64","order":"little","shape":[518]},"y":{"__ndarray__":"KDk88rGP6D/IdaZ9YdjqP2iyEAkRIe0/DO96lMBp7z/YlfIPONnwP3Z0+s71YPE/KLSn1Y/98T940lyb5yHzP8jwEWE/RvQ/HA/HJpdq9T8RD0ZMdIv2P2wtfOzujvY/vEsxskaz9z8QauZ3ntf4P2CImz32+/k/sKZQA04g+z8cTUTrJdP7PwDFBcmlRPw/UOO6jv1o/T9YJrYfoWP+P6QBcFRVjf4/9B8lGq2x/z8iH+1vAmsAQFrq9gC05ABATK7HUi79AEB0PaI1Wo8BQJTxCM+y0gFAnMx8GIYhAkA2OcCskbACQMRbV/uxswJA7Oox3t1FA0BGcVmJjLcDQBZ6DMEJ2ANAPgnnozVqBEDOx9j7zqwEQGaYwYZh/ARASGWAbo5zBUCQJ5xpjY4FQLi2dky5IAZA4EVRL+WyBkDi3GNWOMAGQAjVKxIRRQdAumOPNzlRB0AwZAb1PNcHQMaSjhIcCAhAWvPg12hpCECxkA9mmd4IQIKCu7qU+whAx7w62l5sCUCqEZadwI0JQDCfrPnP/AlA1KBwgOwfCkD8L0tjGLIKQKex3mui2gpAJL8lRkREC0BatAgEzZoLQExOAClw1gtA+G12mn4WDEB13doLnGgMQNoN1aP6dwxA1aiJwTbyDECebLXux/oMQHlQL70CZQ1AxvuP0fOMDUDFnietCc8NQO6KarQfHw5A+osX19VKDkAYGkWXS7EOQHITf/XQ3g5AQKkfendDD0AqpVZ3HmMPQDbCdiOZzg9AaDj6XKPVD0As9sKxOSAQQMhj6p/nMxBA5Ae6SbZXEEBcq1eR/XwQQNrDskcTgBBAaJ5NerWbEECR5dTbaLQQQPHyxIITxhBATvbiRBraEEBbStQLlvwQQIU6MnQpDxFAev+USfsVEUCsRd+7OjcRQBmCn2U/WBFACNiG30NdEUDMvqqfcYgRQK7JDFdVoRFAk8dT3kmlEUAtZKpUAM4RQEIRekhr6hFAIcg8mNjyEUDe7N50IxISQPzB8NoMIxJA1ljnOYEzEkCO+A4gHzUSQKUnTNlpURJAnp8yMUZrEkDD+yex5HsSQGqgVCuXfBJA2g9CSvGGEkBY4Kph5J8SQAL22UsPwRJA/ufBHK3FEkD2oEA+TdgSQCKm7nNJ1xJAKBExP/XMEkAHrRi0dNISQLZmPj9h7BJAKhqB8zv7EkDMrafcEfASQGPWhonM4xJAMyNNK/HdEkDm0gSawd0SQCgyd62x3RJAD57tOULaEkCOoUg/8soSQP7nwRytxRJAK9cce7uqEkAo85t7SJUSQGqgVCuXfBJAoi0BiedzEkCA4RylwzkSQNZY5zmBMxJA3ptBEzsWEkCRTDoxkAcSQNUCGYs68RFAQhF6SGvqEUDAel3e49IRQIL9sdbVqBFArskMV1WhEUC1CGbJeoERQBmCn2U/WBFAhToydCkPEUAHyUD+7+wQQPDyxIITxhBAEs5jWTeJEEBcq1eR/XwQQMhj6p/nMxBASh3pLM8sEEBoOPpco9UPQECpH3p3Qw9AAtyzv+nwDkAYGkWXS7EOQO6KarQfHw5AxvuP0fOMDUCebLXux/oMQHTd2gucaAxAbFF12CQtDEBMTgApcNYLQCS/JUZERAtA/C9LYxiyCkDUoHCA7B8KQKoRlp3AjQlAgoK7upT7CEBa8+DXaGkIQDBkBvU81wdAB9UrEhFFB0AqLJDgaM0GQOBFUS/lsgZAuLZ2TLkgBkCQJ5xpjY4FQGaYwYZh/ARAPgnnozVqBEDyALDdvSQEQBZ6DMEJ2ANA7Oox3t1FA0DzvcAV8OQCQMRbV/uxswJAnMx8GIYhAkB0PaI1Wo8BQGWQmb6EgwFATK7HUi79AEAiH+1vAmsAQAa1T/+oOwBA9B8lGq2x/z+kAXBUVY3+P1Djuo79aP0/6NAlvTml/D8AxQXJpUT8P6+mUANOIPs/SZfOw78d+z9giJs99vv5P5g7okAV5Pk/EGrmd57X+D+DRBCmOFj4P7xLMbJGs/c/bC187O6O9j847HTGcun1PxwPxyaXavU/yPARYT9G9D+ej+XbMeHzP3jSXJvnIfM/pcfZSQ+K8j8otKfVj/3xPxDkYkbIaPE/2JXyDzjZ8D9wSfALYjPwPwzvepTAae8/k6kxavu37T9oshAJESHtP6p1g2hzE+s/yHWmfWHY6j8grq/iOM3oPyg5PPKxj+g/NK+SPs6+5j+E/NFmAkfmP1Y3XCnjkOQ/4L9n21L+4z/NT3IUiA/iP0CD/U+jteE/mWmoyIp03z9AjSaJ59neP5ZqzmjqfNs/+BNScohI2j+qp6ErxHHXP7CafVspt9U/lDygMZAY0z9wIalEyiXRP0d0AI9iGs4/YFCpW9YoyT8huE5wMNrGP9BdAC4YBsA/lF+88q6/vj8+p+fZAy6xPwCtXQFojas/HuUwkwfElT8AOoxqIfuRv/agTtjfuZm/DGks9qXxsb+A8/S1RMS2v8AWYebmuru/TfLi+bbFwr9QbKOI4ITEvxyROe8NAce/ckJr7aiLyr/gXky2nqfNv1IoAXYcDs+/2vupUPSN0r+wqPpxLmXTv8BaumQiTdW/CLH4O1sJ17/wIc+IjfbXvyoEV9dcWNi/XO1Oy2gc2r8t1BIWWDXcvzibo5/sh9y/14wNIY9p3r8bZbWo5evfv0AKPNuljOC/8tT72Uml4L/CY4Vi5IDhv0W67C2+OeK/4EamZlXV4r/kl2TY9Nziv3ydcFdnluO/w4Ow7uRN5L/GJT4Ntafkv3tDWVSb5+S/gIMQ8gQe5b+SMNidADjlv7TXn+RgPOW/oe2KbVdJ5b+QM3aSeZ3lv/xAv1rUXOW/gIMQ8gQe5b/BcVPZ7sTkvzSzHPqs0eS/gIMQ8gQe5b98dcvA4HTlv++x3w3UH+a/XJvE8YE25r8gN7pUbH7lv4CDEPIEHuW//Fxcl0Xa5L8ggPqUtvzjv+BGpmZV1eK/PTXN2FJv4r+H36SeEe/gv0AKPNuljOC/PPVo0x9W4L8ocVoeZITgvzyhE68AaOC/OJujn+yH3L817tcD6Xrav/Ahz4iN9te/5hkE/7vi1L+wqPpxLmXTv610TEEnm9C/4F5Mtp6nzb+ZmxNTQl7Nv6T6RtUHlMq/UGyjiOCExL8q8YE/jnK6v4Dz9LVExLa/ADqMaiH7kb8ArV0BaI2rP9BdAC4YBsA/en/H/wYxxj9gUKlb1ijJPzabek2/Uc4/cCGpRMol0T+wmn1bKbfVP/cTUnKISNo/QI0miefZ3j9Ag/1Po7XhP+C/Z9tS/uM/hPzRZgJH5j/+GlmlrbHmPyg5PPKxj+g/Wyez196w8j8otKfVj/3xP9iV8g842fA/DO96lMBp7z9oshAJESHtP8h1pn1h2Oo/jK1Tudw66j8nOTzysY/oP4T80WYCR+Y/71+C3PSw5D/gv2fbUv7jP0CD/U+jteE/M3p2C7wL3z9BjSaJ59neP81Zx5xfs9s/+BNScohI2j+SOMymGv7YP97oRzUZgNY/sJp9Wym31T/MakB12/PTP3tn9yzIQtI/3cNhHFKU0T9wIalEyiXRPzg+ziaNGtE/9tBjPpoZ0D9k4MbTUWTOP6bFkDR/Us0/EYzDji42zT+Ueaga6tHNPw5JoOmyec4/nIhfjHwyzz/LR8rbeCLQP3AhqUTKJdE/ijm3vVYo0T+ONJksNaHSPykFfjV7EtQ/VBnK56J/1T+wmn1bKbfVPzhDk8KFM9c/iDmJAp8M2T/4E1JyiEjaPwsEBtStsNo/ePgqjlt33D8iRv8bXq7eP0CNJonn2d4/6qSmRgGP4D9Ag/1Po7XhP0QjbZr26uE/jyEsA09R4z/gv2fbUv7jP+EBcHyAzuQ/g/zRZgJH5j+xU0fbcFnmP2Zs4x7V4uc/KDk88rGP6D+OIkLvVYjpP8d1pn1h2Oo/KmdTxmY16z/G/IYDXc7sP2iyEAkRIe0/KgTriw+Q7j8M73qUwGnvP8I3lj0ZX/A/2JXyDzjZ8D9thk2Vo6vxPyi0p9WP/fE/0J2yqxr48j940lyb5yHzPw24iWg9GvQ/yPARYT9G9D+qa3r9qz/1PxwPxyaXavU/OKJEgYeD9j9sLXzs7o72P7xLMbJGs/c/a9za7ZsJ+D8QauZ3ntf4P6h7vjMLyvk/YIibPfb7+T+wplADTiD7P9++4jNLdPs/AMUFyaVE/D8Czpi5vCT9P1Djuo79aP0/pAFwVFWN/j+6kfrILRj/P/QfJRqtsf8/Ih/tbwJrAEAU9D9CXp0AQEyux1Iu/QBAdD2iNVqPAUCczHwYhiECQJ5FLTuPRQJAxFtX+7GzAkDs6jHe3UUDQBZ6DMEJ2ANAxhRF8ywgBEA+CeejNWoEQGaYwYZh/ARAkCecaY2OBUC4tnZMuSAGQOBFUS/lsgZACNUrEhFFB0AwZAb1PNcHQFrz4NdoaQhAhbD+/kfrCECCgru6lPsIQKoRlp3AjQlA1KBwgOwfCkCxeMHcL6wKQPwvS2MYsgpAJL8lRkREC0AGaGHcUm0LQExOAClw1gtA5g26ayEpDEB13doLnGgMQHK52QkOxAxAnmy17sf6DEDo+IrJYSgNQKNXi7m7ig1Ax/uP0fOMDUAUrDOxG+wNQO6KarQfHw5AkRIzMFclDkCQH0opyEQOQLJnK3FkYw5AnKj5uuKFDkAZdOlI05oOQKEAWkLNng5AMJMwjlGkDkBkVQq/6KgOQGZplUkapA5AK4ifW6+bDkAjtd7Yfo4OQHAzA5Lxcw5ArZbNBOVIDkDuimq0Hx8OQF/FeSzSGQ5AApRLD/jwDUA42RC1EsUNQOaapAAulQ1AxvuP0fOMDUAqBNBXk2QNQLC8az+gKg1Anmy17sf6DECYRWt/HOkMQFLXdku2oQxAdN3aC5xoDECqreZxskwMQIfGzdmu9wtATE4AKXDWC0BcZuLakqQLQDm+4GTURgtAJL8lRkREC0Bcn6JL2NsKQPwvS2MYsgpA/wSEgBBpCkDUoHCA7B8KQNRBpscQ/wlAD+UEvhiYCUCqEZadwI0JQPuNu6RxLwlAgoK7upT7CEA2gMCIIcYIQFrz4NdoaQhA+XlJarFWCEAwZAb1PNcHQAES1sOPwwdACNUrEhFFB0BMkZx6JhoHQOBFUS/lsgZAKUyqRcd/BkC4tnZMuSAGQN+M9BqG3AVAkCecaY2OBUA8JsLUZiAFQGaYwYZh/ARAPgnnozVqBED3GMYX608EQBZ6DMEJ2ANAypOEsJd1A0Ds6jHe3UUDQMNbV/uxswJAhtOy21OtAkCczHwYhiECQGrLM+QV1gFAdD2iNVqPAUBMrsdSLv0AQOLkZ1jUyQBAIh/tbwJrAED0HyUarbH/PzBVpede0P4/pAFwVFWN/j9Q47qO/Wj9PwDFBcmlRPw/ZJ4r8l6O+z+wplADTiD7P2CImz32+/k/EGrmd57X+D+8SzGyRrP3P2wtfOzujvY/HA/HJpdq9T/SSyIZ7dP0P8jwEWE/RvQ/eNJcm+ch8z9bJ7PX3rDyPw==","dtype":"float64","order":"little","shape":[518]}},"selected":{"id":"21175"},"selection_policy":{"id":"21174"}},"id":"21147","type":"ColumnDataSource"},{"attributes":{"axis":{"id":"21120"},"grid_line_color":null,"ticker":null},"id":"21123","type":"Grid"},{"attributes":{"data":{"x":{"__ndarray__":"Ty9mcHJ98D9qVClKDITwP+MII3jjmPA/tvab0ui18D9UVylFjuLwP13Lr4o2LPE/l1/AOKSQ8T/8BCh6v73xP9rLFTBkA/I/RUbyxB2B8j+MtSaqcvfyP4CuxSYNEvM/Ntxjk+7Q8z8gZiXaJTH0P4T1yE++n/Q/sBYkCtlq9T/wRQX3Lkz2P0DHIjqMpPY/tARDZmF69z/UdyFqP973Pz99c+919vg/ZCggmvIX+T/42B7KpVH6PxAN8Pv1iPo/iIkd+liL+z/gZB/tXCH8Pxw6HCoMxfw/01jgO2TX/T+s6hpav/79P0CbGYpyOP8/o5S0o8wgAEDoJQzdEjkAQDB+C3Xs1QBAetYKDcZyAUDCLgqlnw8CQJDqiNpVcgJADIcJPXmsAkBU3wjVUkkDQJ43CG0s5gNA5o8HBQaDBEAw6Aad3x8FQDzSrUIfPwVAeEAGNbm8BUDAmAXNklkGQJ6oJ8pSmgZACvEEZWz2BkCEFgh4lG0HQFJJBP1FkwdAQ6JpBbTHB0BgMCleA/gHQFN868AIJwhAnKEDlR8wCEB74ZlMUEQIQNXFK77oRwhAjRvHM7Q8CECcoQOVHzAIQEzTfFP1IwhAJ3QG3YH9B0BE8/tEV8oHQFJJBP1FkwdAPGI9xcKJB0AEhlNjtj4HQArxBGVs9gZAzxPn3UfkBkBqWXnXAYYGQMCYBc2SWQZAISilbTAhBkB4QAY1ubwFQAxUgOgTqAVAMOgGnd8fBUDn4156UB4FQCx7gyGVjgRA5o8HBQaDBEBmjMEQ5O0DQJ03CG0s5gNAVN8I1VJJA0C1JzaPxBkDQAyHCT15rAJA8FrZM2UmAkDCLgqlnw8CQHrWCg3GcgFAb/JDR3UbAUAwfgt17NUAQOglDN0SOQBAQJsZinI4/z+t7tDnoSj/P6zqGlq//v0/HDocKgzF/D+IiR36WIv7P/jYHsqlUfo/ZCggmvIX+T/UdyFqP973P0DHIjqMpPY/sBYkCtlq9T9aosOFLWf1PyBmJdolMfQ/M0LYtHH/8j+MtSaqcvfyP0lncwOU5fE//AQoer+98T9aAyI7oQXxP7DE1Eznh/A/alQpSgyE8D9PL2Zwcn3wPw==","dtype":"float64","order":"little","shape":[104]},"y":{"__ndarray__":"D2rmd57X+D82svU88Bz5P2CImz32+/k/sKZQA04g+z8AxQXJpUT8P1Djuo79aP0/pAFwVFWN/j+Q1BhbYAD/P/QfJRqtsf8/Ih/tbwJrAED7WQcr8OIAQEyux1Iu/QBAdD2iNVqPAUCv1F4UTdMBQJzMfBiGIQJAxFtX+7GzAkDs6jHe3UUDQKf930IMcwNAFnoMwQnYA0D2pooTSAAEQD4J56M1agRAT+30Tkx2BED6juBGB+gEQGaYwYZh/ARAkhPE3hhZBUCQJ5xpjY4FQMWeLDMlxwVAuLZ2TLkgBkCiNQQn3SwGQPNAIMtCfAZA4EVRL+WyBkDumBc3b7wGQOvwwp/v7QZAdBjsrr0QB0BMJCmdBTAHQAjVKxIRRQdAV7Y6JxtRB0BPYxpdm2oHQDWbqN5jcwdAAMjJQgJmB0B7ldwRqEoHQAjVKxIRRQdAOm9flj8pB0Dz6rghG90GQOBFUS/lsgZABYSmiY54BkC4tnZMuSAGQNgsMTbb9AVAkCecaY2OBUBmmMGGYfwEQD4J56M1agRAUgqfDTY7BEAWegzBCdgDQOvqMd7dRQNAxFtX+7GzAkB9CBpuzWwCQJzMfBiGIQJAdD2iNVqPAUBMrsdSLv0AQKFCP2PPgABAIh/tbwJrAED0HyUarbH/P+OCA/NKxv4/pAFwVFWN/j9Q47qO/Wj9P3Dh+u+V5/w/AMUFyaVE/D/5Ijl7t1H7P7CmUANOIPs/uR2grU7/+T9giJs99vv5Pw9q5nee1/g/aaJmULHB+D+9SzGyRrP3P/81K/dupvc/MEylqFDL9j9sLXzs7o72P6Y75socEPY/HA/HJpdq9T9gxIhHP0/1P1T7MvlamPQ/yPARYT9G9D8DyQ0IAAX0Pzi7QQNjlPM/QXj0M/Um8z940lyb5yHzPwj03dA9wvI/1mLA0waJ8j9+DN4BuH/yPxqiGWMjkvI/FC1Q2W+Z8j9CpcFOKpzyP8SxKZ5RyvI/0In4t4sg8z940lyb5yHzPzwcaXTdlfM/yPARYT9G9D9wnXRpy0z0PxwPxyaXavU/LiRbEYyb9T9sLXzs7o72P7xLMbJGs/c/aVAiq8IM+D8PauZ3ntf4Pw==","dtype":"float64","order":"little","shape":[104]}},"selected":{"id":"21179"},"selection_policy":{"id":"21178"}},"id":"21157","type":"ColumnDataSource"},{"attributes":{"overlay":{"id":"21137"}},"id":"21132","type":"LassoSelectTool"},{"attributes":{},"id":"21169","type":"BasicTickFormatter"},{"attributes":{"data_source":{"id":"21157"},"glyph":{"id":"21158"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"21159"},"view":{"id":"21161"}},"id":"21160","type":"GlyphRenderer"},{"attributes":{"fill_color":"#94c4df","line_alpha":0.25,"line_color":"#94c4df","x":{"field":"x"},"y":{"field":"y"}},"id":"21148","type":"Patch"},{"attributes":{"source":{"id":"21147"}},"id":"21151","type":"CDSView"},{"attributes":{},"id":"21125","type":"BasicTicker"},{"attributes":{},"id":"21178","type":"UnionRenderers"},{"attributes":{"toolbars":[{"id":"21138"}],"tools":[{"id":"21128"},{"id":"21129"},{"id":"21130"},{"id":"21131"},{"id":"21132"},{"id":"21133"},{"id":"21134"},{"id":"21135"}]},"id":"21182","type":"ProxyToolbar"},{"attributes":{"source":{"id":"21152"}},"id":"21156","type":"CDSView"},{"attributes":{},"id":"21129","type":"PanTool"},{"attributes":{"end":6.8528428441750115,"start":-2.8736937253829993},"id":"21162","type":"Range1d"},{"attributes":{},"id":"21170","type":"AllLabels"},{"attributes":{"callback":null},"id":"21135","type":"HoverTool"},{"attributes":{},"id":"21131","type":"WheelZoomTool"},{"attributes":{"data_source":{"id":"21147"},"glyph":{"id":"21148"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"21149"},"view":{"id":"21151"}},"id":"21150","type":"GlyphRenderer"},{"attributes":{},"id":"21176","type":"UnionRenderers"},{"attributes":{"end":6.191871325996353,"start":-2.8724702967873306},"id":"21163","type":"Range1d"},{"attributes":{},"id":"21166","type":"BasicTickFormatter"},{"attributes":{},"id":"21167","type":"AllLabels"},{"attributes":{"fill_alpha":0.1,"fill_color":"#4a98c9","line_alpha":0.1,"line_color":"#4a98c9","x":{"field":"x"},"y":{"field":"y"}},"id":"21154","type":"Patch"},{"attributes":{"data_source":{"id":"21152"},"glyph":{"id":"21153"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"21154"},"view":{"id":"21156"}},"id":"21155","type":"GlyphRenderer"},{"attributes":{"bottom_units":"screen","fill_alpha":0.5,"fill_color":"lightgrey","left_units":"screen","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"right_units":"screen","syncable":false,"top_units":"screen"},"id":"21136","type":"BoxAnnotation"},{"attributes":{"formatter":{"id":"21169"},"major_label_policy":{"id":"21170"},"ticker":{"id":"21121"}},"id":"21120","type":"LinearAxis"},{"attributes":{"fill_alpha":0.5,"fill_color":"lightgrey","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"syncable":false,"xs_units":"screen","ys_units":"screen"},"id":"21137","type":"PolyAnnotation"},{"attributes":{"toolbar":{"id":"21182"},"toolbar_location":"above"},"id":"21183","type":"ToolbarBox"},{"attributes":{"axis":{"id":"21124"},"dimension":1,"grid_line_color":null,"ticker":null},"id":"21127","type":"Grid"},{"attributes":{"fill_alpha":0.1,"fill_color":"#94c4df","line_alpha":0.1,"line_color":"#94c4df","x":{"field":"x"},"y":{"field":"y"}},"id":"21149","type":"Patch"},{"attributes":{"active_multi":null,"tools":[{"id":"21128"},{"id":"21129"},{"id":"21130"},{"id":"21131"},{"id":"21132"},{"id":"21133"},{"id":"21134"},{"id":"21135"}]},"id":"21138","type":"Toolbar"},{"attributes":{},"id":"21179","type":"Selection"},{"attributes":{"fill_alpha":0.1,"fill_color":"#1764ab","line_alpha":0.1,"line_color":"#1764ab","x":{"field":"x"},"y":{"field":"y"}},"id":"21159","type":"Patch"},{"attributes":{},"id":"21175","type":"Selection"},{"attributes":{"overlay":{"id":"21136"}},"id":"21130","type":"BoxZoomTool"},{"attributes":{},"id":"21121","type":"BasicTicker"},{"attributes":{},"id":"21174","type":"UnionRenderers"},{"attributes":{"below":[{"id":"21120"}],"center":[{"id":"21123"},{"id":"21127"}],"height":500,"left":[{"id":"21124"}],"output_backend":"webgl","renderers":[{"id":"21150"},{"id":"21155"},{"id":"21160"}],"title":{"id":"21164"},"toolbar":{"id":"21138"},"toolbar_location":null,"width":500,"x_range":{"id":"21162"},"x_scale":{"id":"21116"},"y_range":{"id":"21163"},"y_scale":{"id":"21118"}},"id":"21111","subtype":"Figure","type":"Plot"},{"attributes":{},"id":"21164","type":"Title"},{"attributes":{},"id":"21133","type":"UndoTool"},{"attributes":{},"id":"21118","type":"LinearScale"},{"attributes":{},"id":"21134","type":"SaveTool"},{"attributes":{"formatter":{"id":"21166"},"major_label_policy":{"id":"21167"},"ticker":{"id":"21125"}},"id":"21124","type":"LinearAxis"}],"root_ids":["21184"]},"title":"Bokeh Application","version":"2.3.2"}}';
                  var render_items = [{"docid":"f9ad5ea0-f4ff-46c9-b897-8ecb71bd9a8e","root_ids":["21184"],"roots":{"21184":"8e5f0f0a-f198-4c8f-aff3-10786c88ad98"}}];
                  root.Bokeh.embed.embed_items(docs_json, render_items);
                
                  }
                  if (root.Bokeh !== undefined) {
                    embed_document(root);
                  } else {
                    var attempts = 0;
                    var timer = setInterval(function(root) {
                      if (root.Bokeh !== undefined) {
                        clearInterval(timer);
                        embed_document(root);
                      } else {
                        attempts++;
                        if (attempts > 100) {
                          clearInterval(timer);
                          console.log("Bokeh: ERROR: Unable to run BokehJS code because BokehJS library is missing");
                        }
                      }
                    }, 10, root)
                  }
                })(window);
              });
            };
            if (document.readyState != "loading") fn();
            else document.addEventListener("DOMContentLoaded", fn);
          })();
        },
        function(Bokeh) {
        
        
        }
      ];
    
      function run_inline_js() {
        
        for (var i = 0; i < inline_js.length; i++) {
          inline_js[i].call(root, root.Bokeh);
        }
        
      }
    
      if (root._bokeh_is_loading === 0) {
        console.debug("Bokeh: BokehJS loaded, going straight to plotting");
        run_inline_js();
      } else {
        load_libs(css_urls, js_urls, function() {
          console.debug("Bokeh: BokehJS plotting callback run at", now());
          run_inline_js();
        });
      }
    }(window));
  };
  if (document.readyState != "loading") fn();
  else document.addEventListener("DOMContentLoaded", fn);
})();