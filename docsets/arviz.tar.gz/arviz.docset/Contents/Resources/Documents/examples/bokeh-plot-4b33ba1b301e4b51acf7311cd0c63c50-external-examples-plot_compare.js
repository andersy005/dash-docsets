(function() {
  var fn = function() {
    
    (function(root) {
      function now() {
        return new Date();
      }
    
      var force = false;
    
      if (typeof root._bokeh_onload_callbacks === "undefined" || force === true) {
        root._bokeh_onload_callbacks = [];
        root._bokeh_is_loading = undefined;
      }
    
      
      
    
      var element = document.getElementById("ce188fc5-1016-4525-9aef-41694fa0818d");
        if (element == null) {
          console.warn("Bokeh: autoload.js configured with elementid 'ce188fc5-1016-4525-9aef-41694fa0818d' but no matching script tag was found.")
        }
      
    
      function run_callbacks() {
        try {
          root._bokeh_onload_callbacks.forEach(function(callback) {
            if (callback != null)
              callback();
          });
        } finally {
          delete root._bokeh_onload_callbacks
        }
        console.debug("Bokeh: all callbacks have finished");
      }
    
      function load_libs(css_urls, js_urls, callback) {
        if (css_urls == null) css_urls = [];
        if (js_urls == null) js_urls = [];
    
        root._bokeh_onload_callbacks.push(callback);
        if (root._bokeh_is_loading > 0) {
          console.debug("Bokeh: BokehJS is being loaded, scheduling callback at", now());
          return null;
        }
        if (js_urls == null || js_urls.length === 0) {
          run_callbacks();
          return null;
        }
        console.debug("Bokeh: BokehJS not loaded, scheduling load and callback at", now());
        root._bokeh_is_loading = css_urls.length + js_urls.length;
    
        function on_load() {
          root._bokeh_is_loading--;
          if (root._bokeh_is_loading === 0) {
            console.debug("Bokeh: all BokehJS libraries/stylesheets loaded");
            run_callbacks()
          }
        }
    
        function on_error(url) {
          console.error("failed to load " + url);
        }
    
        for (let i = 0; i < css_urls.length; i++) {
          const url = css_urls[i];
          const element = document.createElement("link");
          element.onload = on_load;
          element.onerror = on_error.bind(null, url);
          element.rel = "stylesheet";
          element.type = "text/css";
          element.href = url;
          console.debug("Bokeh: injecting link tag for BokehJS stylesheet: ", url);
          document.body.appendChild(element);
        }
    
        const hashes = {"https://cdn.bokeh.org/bokeh/release/bokeh-2.3.2.min.js": "XypntL49z55iwGVUW4qsEu83zKL3XEcz0MjuGOQ9SlaaQ68X/g+k1FcioZi7oQAc", "https://cdn.bokeh.org/bokeh/release/bokeh-tables-2.3.2.min.js": "bEsM86IHGDTLCS0Zod8a8WM6Y4+lafAL/eSiyQcuPzinmWNgNO2/olUF0Z2Dkn5i", "https://cdn.bokeh.org/bokeh/release/bokeh-widgets-2.3.2.min.js": "TX0gSQTdXTTeScqxj6PVQxTiRW8DOoGVwinyi1D3kxv7wuxQ02XkOxv0xwiypcAH"};
    
        for (let i = 0; i < js_urls.length; i++) {
          const url = js_urls[i];
          const element = document.createElement('script');
          element.onload = on_load;
          element.onerror = on_error.bind(null, url);
          element.async = false;
          element.src = url;
          if (url in hashes) {
            element.crossOrigin = "anonymous";
            element.integrity = "sha384-" + hashes[url];
          }
          console.debug("Bokeh: injecting script tag for BokehJS library: ", url);
          document.head.appendChild(element);
        }
      };
    
      function inject_raw_css(css) {
        const element = document.createElement("style");
        element.appendChild(document.createTextNode(css));
        document.body.appendChild(element);
      }
    
      
      var js_urls = ["https://cdn.bokeh.org/bokeh/release/bokeh-2.3.2.min.js", "https://cdn.bokeh.org/bokeh/release/bokeh-widgets-2.3.2.min.js", "https://cdn.bokeh.org/bokeh/release/bokeh-tables-2.3.2.min.js"];
      var css_urls = [];
      
    
      var inline_js = [
        function(Bokeh) {
          Bokeh.set_log_level("info");
        },
        
        function(Bokeh) {
          (function() {
            var fn = function() {
              Bokeh.safely(function() {
                (function(root) {
                  function embed_document(root) {
                    
                  var docs_json = '{"22e0cb85-9a38-4aed-bb88-d6b9e1f0ad85":{"defs":[],"roots":{"references":[{"attributes":{},"id":"15804","type":"Selection"},{"attributes":{"data":{"x":{"__ndarray__":"KAWarnTPPsA=","dtype":"float64","order":"little","shape":[1]},"y":[-0.75]},"selected":{"id":"15798"},"selection_policy":{"id":"15797"}},"id":"15762","type":"ColumnDataSource"},{"attributes":{"fill_alpha":0.5,"fill_color":"lightgrey","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"syncable":false,"xs_units":"screen","ys_units":"screen"},"id":"15750","type":"PolyAnnotation"},{"attributes":{},"id":"15800","type":"Selection"},{"attributes":{"overlay":{"id":"15749"}},"id":"15743","type":"BoxZoomTool"},{"attributes":{"callback":null},"id":"15748","type":"HoverTool"},{"attributes":{"formatter":{"id":"15793"},"major_label_overrides":{"-0.75":"","-1":"Centered 8 schools","0":"Non-centered 8 schools"},"major_label_policy":{"id":"15794"},"ticker":{"id":"15760"}},"id":"15737","type":"LinearAxis"},{"attributes":{},"id":"15801","type":"UnionRenderers"},{"attributes":{},"id":"15729","type":"LinearScale"},{"attributes":{},"id":"15794","type":"AllLabels"},{"attributes":{"data":{"x":{"__ndarray__":"eFcgQvKvPsAoBZqudM8+wA==","dtype":"float64","order":"little","shape":[2]},"y":[0.0,-1.0]},"selected":{"id":"15802"},"selection_policy":{"id":"15801"}},"id":"15772","type":"ColumnDataSource"},{"attributes":{"axis":{"id":"15733"},"ticker":null},"id":"15736","type":"Grid"},{"attributes":{},"id":"15741","type":"ResetTool"},{"attributes":{},"id":"15806","type":"Selection"},{"attributes":{"source":{"id":"15782"}},"id":"15786","type":"CDSView"},{"attributes":{"toolbars":[{"id":"15751"}],"tools":[{"id":"15741"},{"id":"15742"},{"id":"15743"},{"id":"15744"},{"id":"15745"},{"id":"15746"},{"id":"15747"},{"id":"15748"}]},"id":"15809","type":"ProxyToolbar"},{"attributes":{},"id":"15799","type":"UnionRenderers"},{"attributes":{"ticks":[0.0,-0.75,-1.0]},"id":"15760","type":"FixedTicker"},{"attributes":{"line_color":{"value":"grey"},"xs":{"field":"xs"},"ys":{"field":"ys"}},"id":"15768","type":"MultiLine"},{"attributes":{"data_source":{"id":"15782"},"glyph":{"id":"15783"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"15784"},"view":{"id":"15786"}},"id":"15785","type":"GlyphRenderer"},{"attributes":{"children":[{"id":"15810"},{"id":"15808"}]},"id":"15811","type":"Column"},{"attributes":{"dimension":"height","line_color":"grey","line_dash":[6],"line_width":1.7677669529663689,"location":-30.687290318389813},"id":"15787","type":"Span"},{"attributes":{"source":{"id":"15777"}},"id":"15781","type":"CDSView"},{"attributes":{"overlay":{"id":"15750"}},"id":"15745","type":"LassoSelectTool"},{"attributes":{"data":{"x":{"__ndarray__":"m/f9Q2zYPcDPGP3dN9s9wA==","dtype":"float64","order":"little","shape":[2]},"y":[0.0,-1.0]},"selected":{"id":"15806"},"selection_policy":{"id":"15805"}},"id":"15782","type":"ColumnDataSource"},{"attributes":{"fill_color":{"value":null},"line_width":{"value":2},"size":{"value":6},"x":{"field":"x"},"y":{"field":"y"}},"id":"15773","type":"Circle"},{"attributes":{"data":{"xs":[[-32.052286212415325,-29.322294424364305],[-32.23721121836336,-29.38353713483674]],"ys":[[0.0,0.0],[-1.0,-1.0]]},"selected":{"id":"15804"},"selection_policy":{"id":"15803"}},"id":"15777","type":"ColumnDataSource"},{"attributes":{"children":[[{"id":"15724"},0,0]]},"id":"15808","type":"GridBox"},{"attributes":{},"id":"15788","type":"Title"},{"attributes":{"axis_label":"Log","formatter":{"id":"15790"},"major_label_policy":{"id":"15792"},"ticker":{"id":"15734"}},"id":"15733","type":"LinearAxis"},{"attributes":{},"id":"15793","type":"BasicTickFormatter"},{"attributes":{},"id":"15731","type":"LinearScale"},{"attributes":{"data_source":{"id":"15772"},"glyph":{"id":"15773"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"15774"},"view":{"id":"15776"}},"id":"15775","type":"GlyphRenderer"},{"attributes":{"end":0.5,"start":-1.5},"id":"15727","type":"DataRange1d"},{"attributes":{},"id":"15742","type":"PanTool"},{"attributes":{},"id":"15797","type":"UnionRenderers"},{"attributes":{"source":{"id":"15772"}},"id":"15776","type":"CDSView"},{"attributes":{},"id":"15803","type":"UnionRenderers"},{"attributes":{},"id":"15746","type":"UndoTool"},{"attributes":{"fill_alpha":{"value":0.1},"fill_color":{"value":"grey"},"line_alpha":{"value":0.1},"line_color":{"value":"grey"},"line_width":{"value":2},"marker":{"value":"triangle"},"size":{"value":6},"x":{"field":"x"},"y":{"field":"y"}},"id":"15764","type":"Scatter"},{"attributes":{"source":{"id":"15767"}},"id":"15771","type":"CDSView"},{"attributes":{"fill_alpha":{"value":0.1},"fill_color":{"value":"black"},"line_alpha":{"value":0.1},"line_width":{"value":2},"size":{"value":6},"x":{"field":"x"},"y":{"field":"y"}},"id":"15784","type":"Circle"},{"attributes":{"axis":{"id":"15737"},"dimension":1,"ticker":null},"id":"15740","type":"Grid"},{"attributes":{"fill_alpha":{"value":0.1},"fill_color":{"value":null},"line_alpha":{"value":0.1},"line_width":{"value":2},"size":{"value":6},"x":{"field":"x"},"y":{"field":"y"}},"id":"15774","type":"Circle"},{"attributes":{"xs":{"field":"xs"},"ys":{"field":"ys"}},"id":"15778","type":"MultiLine"},{"attributes":{"data_source":{"id":"15767"},"glyph":{"id":"15768"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"15769"},"view":{"id":"15771"}},"id":"15770","type":"GlyphRenderer"},{"attributes":{"below":[{"id":"15733"}],"center":[{"id":"15736"},{"id":"15740"}],"height":500,"left":[{"id":"15737"}],"output_backend":"webgl","renderers":[{"id":"15765"},{"id":"15770"},{"id":"15775"},{"id":"15780"},{"id":"15785"},{"id":"15787"}],"title":{"id":"15788"},"toolbar":{"id":"15751"},"toolbar_location":null,"width":500,"x_range":{"id":"15725"},"x_scale":{"id":"15729"},"y_range":{"id":"15727"},"y_scale":{"id":"15731"}},"id":"15724","subtype":"Figure","type":"Plot"},{"attributes":{},"id":"15792","type":"AllLabels"},{"attributes":{},"id":"15790","type":"BasicTickFormatter"},{"attributes":{},"id":"15734","type":"BasicTicker"},{"attributes":{"data":{"xs":[[-30.896420573800537,-30.724327779399562]],"ys":[[-0.75,-0.75]]},"selected":{"id":"15800"},"selection_policy":{"id":"15799"}},"id":"15767","type":"ColumnDataSource"},{"attributes":{"data_source":{"id":"15777"},"glyph":{"id":"15778"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"15779"},"view":{"id":"15781"}},"id":"15780","type":"GlyphRenderer"},{"attributes":{"bottom_units":"screen","fill_alpha":0.5,"fill_color":"lightgrey","left_units":"screen","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"right_units":"screen","syncable":false,"top_units":"screen"},"id":"15749","type":"BoxAnnotation"},{"attributes":{"line_alpha":{"value":0.1},"line_color":{"value":"grey"},"xs":{"field":"xs"},"ys":{"field":"ys"}},"id":"15769","type":"MultiLine"},{"attributes":{},"id":"15805","type":"UnionRenderers"},{"attributes":{"active_multi":null,"tools":[{"id":"15741"},{"id":"15742"},{"id":"15743"},{"id":"15744"},{"id":"15745"},{"id":"15746"},{"id":"15747"},{"id":"15748"}]},"id":"15751","type":"Toolbar"},{"attributes":{},"id":"15747","type":"SaveTool"},{"attributes":{},"id":"15725","type":"DataRange1d"},{"attributes":{"fill_color":{"value":"black"},"line_width":{"value":2},"size":{"value":6},"x":{"field":"x"},"y":{"field":"y"}},"id":"15783","type":"Circle"},{"attributes":{},"id":"15744","type":"WheelZoomTool"},{"attributes":{"source":{"id":"15762"}},"id":"15766","type":"CDSView"},{"attributes":{"data_source":{"id":"15762"},"glyph":{"id":"15763"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"15764"},"view":{"id":"15766"}},"id":"15765","type":"GlyphRenderer"},{"attributes":{},"id":"15802","type":"Selection"},{"attributes":{"line_alpha":{"value":0.1},"xs":{"field":"xs"},"ys":{"field":"ys"}},"id":"15779","type":"MultiLine"},{"attributes":{"fill_color":{"value":"grey"},"line_color":{"value":"grey"},"line_width":{"value":2},"marker":{"value":"triangle"},"size":{"value":6},"x":{"field":"x"},"y":{"field":"y"}},"id":"15763","type":"Scatter"},{"attributes":{},"id":"15798","type":"Selection"},{"attributes":{"toolbar":{"id":"15809"},"toolbar_location":"above"},"id":"15810","type":"ToolbarBox"}],"root_ids":["15811"]},"title":"Bokeh Application","version":"2.3.2"}}';
                  var render_items = [{"docid":"22e0cb85-9a38-4aed-bb88-d6b9e1f0ad85","root_ids":["15811"],"roots":{"15811":"ce188fc5-1016-4525-9aef-41694fa0818d"}}];
                  root.Bokeh.embed.embed_items(docs_json, render_items);
                
                  }
                  if (root.Bokeh !== undefined) {
                    embed_document(root);
                  } else {
                    var attempts = 0;
                    var timer = setInterval(function(root) {
                      if (root.Bokeh !== undefined) {
                        clearInterval(timer);
                        embed_document(root);
                      } else {
                        attempts++;
                        if (attempts > 100) {
                          clearInterval(timer);
                          console.log("Bokeh: ERROR: Unable to run BokehJS code because BokehJS library is missing");
                        }
                      }
                    }, 10, root)
                  }
                })(window);
              });
            };
            if (document.readyState != "loading") fn();
            else document.addEventListener("DOMContentLoaded", fn);
          })();
        },
        function(Bokeh) {
        
        
        }
      ];
    
      function run_inline_js() {
        
        for (var i = 0; i < inline_js.length; i++) {
          inline_js[i].call(root, root.Bokeh);
        }
        
      }
    
      if (root._bokeh_is_loading === 0) {
        console.debug("Bokeh: BokehJS loaded, going straight to plotting");
        run_inline_js();
      } else {
        load_libs(css_urls, js_urls, function() {
          console.debug("Bokeh: BokehJS plotting callback run at", now());
          run_inline_js();
        });
      }
    }(window));
  };
  if (document.readyState != "loading") fn();
  else document.addEventListener("DOMContentLoaded", fn);
})();