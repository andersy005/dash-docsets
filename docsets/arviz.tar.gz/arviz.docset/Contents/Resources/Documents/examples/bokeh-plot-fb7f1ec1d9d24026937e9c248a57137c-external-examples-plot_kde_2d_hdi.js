(function() {
  var fn = function() {
    
    (function(root) {
      function now() {
        return new Date();
      }
    
      var force = false;
    
      if (typeof root._bokeh_onload_callbacks === "undefined" || force === true) {
        root._bokeh_onload_callbacks = [];
        root._bokeh_is_loading = undefined;
      }
    
      
      
    
      var element = document.getElementById("1e7be886-016b-49fa-b1b0-2c6614040268");
        if (element == null) {
          console.warn("Bokeh: autoload.js configured with elementid '1e7be886-016b-49fa-b1b0-2c6614040268' but no matching script tag was found.")
        }
      
    
      function run_callbacks() {
        try {
          root._bokeh_onload_callbacks.forEach(function(callback) {
            if (callback != null)
              callback();
          });
        } finally {
          delete root._bokeh_onload_callbacks
        }
        console.debug("Bokeh: all callbacks have finished");
      }
    
      function load_libs(css_urls, js_urls, callback) {
        if (css_urls == null) css_urls = [];
        if (js_urls == null) js_urls = [];
    
        root._bokeh_onload_callbacks.push(callback);
        if (root._bokeh_is_loading > 0) {
          console.debug("Bokeh: BokehJS is being loaded, scheduling callback at", now());
          return null;
        }
        if (js_urls == null || js_urls.length === 0) {
          run_callbacks();
          return null;
        }
        console.debug("Bokeh: BokehJS not loaded, scheduling load and callback at", now());
        root._bokeh_is_loading = css_urls.length + js_urls.length;
    
        function on_load() {
          root._bokeh_is_loading--;
          if (root._bokeh_is_loading === 0) {
            console.debug("Bokeh: all BokehJS libraries/stylesheets loaded");
            run_callbacks()
          }
        }
    
        function on_error(url) {
          console.error("failed to load " + url);
        }
    
        for (let i = 0; i < css_urls.length; i++) {
          const url = css_urls[i];
          const element = document.createElement("link");
          element.onload = on_load;
          element.onerror = on_error.bind(null, url);
          element.rel = "stylesheet";
          element.type = "text/css";
          element.href = url;
          console.debug("Bokeh: injecting link tag for BokehJS stylesheet: ", url);
          document.body.appendChild(element);
        }
    
        const hashes = {"https://cdn.bokeh.org/bokeh/release/bokeh-2.3.2.min.js": "XypntL49z55iwGVUW4qsEu83zKL3XEcz0MjuGOQ9SlaaQ68X/g+k1FcioZi7oQAc", "https://cdn.bokeh.org/bokeh/release/bokeh-tables-2.3.2.min.js": "bEsM86IHGDTLCS0Zod8a8WM6Y4+lafAL/eSiyQcuPzinmWNgNO2/olUF0Z2Dkn5i", "https://cdn.bokeh.org/bokeh/release/bokeh-widgets-2.3.2.min.js": "TX0gSQTdXTTeScqxj6PVQxTiRW8DOoGVwinyi1D3kxv7wuxQ02XkOxv0xwiypcAH"};
    
        for (let i = 0; i < js_urls.length; i++) {
          const url = js_urls[i];
          const element = document.createElement('script');
          element.onload = on_load;
          element.onerror = on_error.bind(null, url);
          element.async = false;
          element.src = url;
          if (url in hashes) {
            element.crossOrigin = "anonymous";
            element.integrity = "sha384-" + hashes[url];
          }
          console.debug("Bokeh: injecting script tag for BokehJS library: ", url);
          document.head.appendChild(element);
        }
      };
    
      function inject_raw_css(css) {
        const element = document.createElement("style");
        element.appendChild(document.createTextNode(css));
        document.body.appendChild(element);
      }
    
      
      var js_urls = ["https://cdn.bokeh.org/bokeh/release/bokeh-2.3.2.min.js", "https://cdn.bokeh.org/bokeh/release/bokeh-widgets-2.3.2.min.js", "https://cdn.bokeh.org/bokeh/release/bokeh-tables-2.3.2.min.js"];
      var css_urls = [];
      
    
      var inline_js = [
        function(Bokeh) {
          Bokeh.set_log_level("info");
        },
        
        function(Bokeh) {
          (function() {
            var fn = function() {
              Bokeh.safely(function() {
                (function(root) {
                  function embed_document(root) {
                    
                  var docs_json = '{"1dc2c5ac-d3e6-4f3e-9f19-38840cb4ef9e":{"defs":[],"roots":{"references":[{"attributes":{},"id":"21256","type":"UnionRenderers"},{"attributes":{},"id":"21214","type":"SaveTool"},{"attributes":{"overlay":{"id":"21216"}},"id":"21210","type":"BoxZoomTool"},{"attributes":{"fill_alpha":0.1,"fill_color":"#94c4df","line_alpha":0.1,"line_color":"#94c4df","x":{"field":"x"},"y":{"field":"y"}},"id":"21229","type":"Patch"},{"attributes":{"data":{"x":{"__ndarray__":"sbPDDRs/77+QGCAORq3vv1R/1CSuAfC/rqD61vV4779scZ4ZrRvvv/HwhrSN8u6/UoDwIcoX779scZ4ZrRvvv7z2zUwMau+/F8pWSU4e779tcZ4ZrRvvv5zN6L9YaO6/gI7JRlG67b9GoQV4AVTtv9wE3SiI7Oy/sFHcgDiN7L8iDWx6UUzsv4odpKFwYuu/VQgrZcxG6r/xMRrow/7pvzfBcxvRT+m/0V4UJOyA6L97naziZ8TnvzASWE9PcOe/EuEUPxr65r906xE9DvDlv3Tylbba4eS/+HOO7jhl5L+9SNdHhQLjv7TS0x1mU+K/XTqZB4kU4r/N0JsgXl7hv9JThiwqZeC/8GUjCuOJ379U03+ZXL7dv3Amn9j5bNq/vGAgQli72b/7U86+NSfWv/DmGqcQUNW/HNx6JoRS07+vdpve0lzQv3inlnUnM9C/ssgEIbMWyr/wzySIfCzGvyvGiCeqdsK/4KE4SlTlt7/ae35hZxe2vxqWZZ7OYqC/ACA9IXyNi79wDPhcsjedPwBa6UH1AbE/Knjhc2QPvD8ALP0DzbrCP56x7SgD28g/8KoFZ5/0zD/tW1uwRx7QP/gUB+U4l9M/11UgRMbJ0z+/04QoXHbYP3BUixYitNg/e/LnXIxL3T/wkw9IC9HdP5630wpIpOA/uOnJPPp24T9czeOkZrriP3QJjNVuBeQ/KqOL1Zsj5T8wKU5u45PmPyKsoSTn4Oc/8EgQB1gi6T8IWnL/5ObqP7Bo0p/MsOs/cIiUOEE/7j+D+X4KBrTuPxhUq+jaZvA/+GMMNRWu8T/Uc22BT/XyPxYMuFAATfM/tIPOzYk89D83LTjVKRT1P5STLxrEg/U/dKOQZv7K9j+7L33Oxzj3P1Sz8bI4Evg/5p/2oEdZ+T8ww1L/cln5PxDTs0utoPo/CTXPQwzi+z/w4hSY5+f7P9DydeQhL/0/W47qNH9z/j+wAtcwXHb+P4wSOH2Wvf8/msG48K5IAEA2kcxkaIIAQCYZ/YoFJgFAS8Ebqxg5AUAWoS2xoskBQAYpXtc/bQJAxBcIxOiTAkD0sI793BADQOQ4vyN6tANA1MDvSRdYBEDESCBwtPsEQLTQUJZRnwVAVNq6JPUXBkCkWIG87kIGQJLgseKL5gZAgmjiCCmKB0By8BIvxi0IQCuGiFtYUwhAYXhDVWPRCEBSAHR7AHUJQECIpKGdGApAMBDVxzq8CkAgmAXu118LQDeig4U92gtAECA2FHUDDEAAqGY6EqcMQG5eioXB9gxA8C+XYK9KDUDet8eGTO4NQM4/+KzpkQ5AxIp4Y+eqDkC+xyjThjUPQK5PWfkj2Q9Az+vEj2A+EEDGL90iL5AQQAhnAwWtshBAvnP1tf3hEEDwr2Ao/ukQQLa3DUnMMxFArvsl3JqFEUDVzuQbe58RQKY/Pm9p1xFA9HdkJyvyEUCdg1YCOCkSQGy/vNOBYRJAlcdulQZ7EkAyBYGxi6gSQI4LhyjVzBJAL/EsConbEkCFT5+7ox4TQI6IeIJ5IxNAYxHlXZBcE0B8k7dOcnATQPuKIdQBdRNA7cZ4dGSlE0B018/hQMITQEO+3Jo62RNAGqWWbqrnE0AKc5oGNuUTQGiKILOX5hNAAmODzez3E0BsG+h0DxQUQPTz7kqZIBRAoINIfKI1FEDRh+07zCkUQGwb6HQPFBRAKrdNeygSFEA2giUL4w0UQGwb6HQPFBRAjBC7oHYdFECMeDNu4CsUQAP0XP11KhRAHg/xXM4hFECUvGDefigUQAiFMx/HNhRAFNy+essuFEBsG+h0DxQUQG1SnOCHEhRAHPwb737yE0CIB9EVPtkTQG39pE0mzBNAdNfP4UDCE0B/R4BycL0TQGOAna4DoxNAZDvSfS6EE0B8k7dOcnATQJmAYfAXXxNAGwwFwlE1E0CET5+7ox4TQGXnOQBtEhNABgcAbZn4EkDqQpUbKdkSQI4LhyjVzBJARCxtB3yuEkCVx26VBnsSQAXKx7kLeBJA1HEtb5tBEkCdg1YCOCkSQKKxfs64DRJANnhCeCvjEUCmPz5vadcRQG/TdqL/vBFAutpoIfaHEUCu+yXcmoURQFaCg+6iQBFAtrcNScwzEUBSWk5D2P4QQL5z9bX94RBAOEkRVqPKEECFWwJzMp8QQMYv3SIvkBBAAElsSmZ2EEB2MAnWgkgQQM/rxI9gPhBAwlra640MEECuT1n5I9kPQORfnzFPbw9Avsco04Y1D0Bd8ogZ2rEOQM4/+KzpkQ5AhZEZp/MgDkDet8eGTO4NQPf6pt8vlQ1A8C+XYK9KDUBStGleB+sMQACoZjoSpwxAWnIQw4siDEAQIDYUdQMMQPG+vq4geQtAIJgF7tdfC0Cdo2wGp94KQDAQ1cc6vApADxs6eLkkCkBAiKShnRgKQFIAdHsAdQlAAxABHZdjCUBieENVY9EIQACZ52wNiAhAcvASL8YtCEDNUglznJsHQIJo4ggpigdAwtXJVL/mBkCS4LHii+YGQKRYgbzuQgZA0gmg/xU8BkC00FCWUZ8FQIBEBCt+UwVAxEggcLT7BEDUwO9JF1gEQGTxpYCTOARA5Di/I3q0A0BUDAEivDIDQPSwjv3cEANABile1z9tAkAWoS2xoskBQA/6gkKjsgFAJhn9igUmAUA2kcxkaIIAQLmNWl7hx/8/jRI4fZa9/z+wAtcwXHb+P966vPsOfv0/0PJ15CEv/T/w4hSY5+f7P7I/zVYjSvs/ENOzS62g+j8ww1L/cln5PyskZg0e4vg/VLPxsjgS+D90o5Bm/sr2P5STLxrEg/U/tIPOzYk89D/Uc22BT/XyP/hjDDUVrvE/FLmCs+qb8T8YVKvo2mbwP3CIlDhBP+4/sGjSn8yw6z/wSBAHWCLpPzApTm7jk+Y/dAmM1W4F5D+46ck8+nbhP/CTD0gL0d0/cFSLFiK02D/4FAflOJfTPx5CvBbWNNI/8KoFZ5/0zD8ALP0DzbrCPwBa6UH1AbE/ACA9IXyNi78rSzE7hcCxv+ChOEpU5be/zEjBue58wL/wzySIfCzGvxskLVlDCc2/eKeWdScz0L+GAZE4yzvSv/DmGqcQUNW/cCaf2Pls2r/wZSMK44nfv8d/NwBIU+C/tNLTHWZT4r9gNWS6b1Xjv2FKVJ3FLeS/PA7f+9HL5L908pW22uHkv4ZHjL5cz+a/MBJYT09w5798mvAXHfPpv/AxGujD/um/QfFVo11r6r+eHxTfGezqv9O8xcD3MOy/sFHcgDiN7L/cLDmrhrXsv0KKHlTbaO2/Sni7jE9s7r93u07emtnuvyuK7zWtGe+/bHGeGa0b77+xs8MNGz/vvwBa6UH1AbE/Z5CXRVmssT8s52yhPpi6PwAs/QPNusI/fTUrueYowz8qtPMpvu/FPyTtvYIbdsg/8KoFZ5/0zD+C3NbSjKjQP/gUB+U4l9M/shUCJp0i1z9wVIsWIrTYP587zoTgT9w/8JMPSAvR3T+46ck8+nbhP1wm8mXFXuI/dAmM1W4F5D8wKU5u45PmP/BIEAdYIuk/XWCiqmR76j+waNKfzLDrP3CIlDhBP+4/GFSr6Npm8D/4Yww1Fa7xP9RzbYFP9fI/tIPOzYk89D+Uky8axIP1P3SjkGb+yvY/TsdkX5dG9z9Vs/GyOBL4PzHDUv9yWfk/ENOzS62g+j/w4hSY5+f7P4QLztJVpPw/0PJ15CEv/T+wAtcwXHb+P5J3VjnFf/8/jBI4fZa9/z82kcxkaIIAQCYZ/YoFJgFAWJm+3gM5AUAWoS2xoskBQIzHbvExbAJABile1z9tAkD0sI793BADQJu7pZQghANA5Di/I3q0A0DUwO9JF1gEQNOFkvWjbQRAxEggcLT7BEC9bnG1XjIFQLTQUJZRnwVAafCd80r3BUCkWIG87kIGQAhkObFVwQZAkuCx4ovmBkCCaOIIKYoHQKPojD17jwdAcvASL8YtCEAuqrZuN1AIQGJ4Q1Vj0QhAMIoEJoryCEBSAHR7AHUJQD6jgFwngAlA2ajGcm4KCkBAiKShnRgKQLe8FKmamwpAMBDVxzq8CkDHW5TlQywLQCCYBe7XXwtAU2B0bkitC0AQIDYUdQMMQJIgCrC3HAxAnrBp+pSBDEAAqGY6EqcMQBLz4LdY1gxAIpw6i1MpDUDwL5dgr0oNQIX7ORZmgg1AfqYrAF7YDUDet8eGTO4NQHnR4TuXKQ5Asd9dljB4DkDOP/is6ZEOQM7UmyO1xw5AYREDxM4OD0C+xyjThjUPQPyI91mBTA9AnmyfEzWCD0CUC3z1ZbIPQK5PWfkj2Q9AH5KUElbnD0AKedAWxgwQQCgglvhWHRBAXFiLw8wjEEAMVgwJpyQQQEkiBP8/IRBAHtgoeeUeEEB6ejHIHCAQQH4T0w5NIRBArdJO3voeEEB9dRWeFBMQQOna9+8x+Q9Ark9Z+SPZD0BCG2etycIPQOSUNnL3hA9Av8co04Y1D0A2OOhazScPQP/B+KBhnQ5Azj/4rOmRDkCWt1cbAigOQN63x4ZM7g1AwyTA5iTADUDwL5dgr0oNQALKXr7a7gxAAKhmOhKnDEAQIDYUdQMMQKZmwk+7zwtAIJgF7tdfC0AwENXHOrwKQBZ/BApCMQpAQIikoZ0YCkBSAHR7AHUJQGJ4Q1Vj0QhAcvASL8YtCECCaOIIKYoHQJLgseKL5gZApFiBvO5CBkC00FCWUZ8FQMefKj3RegVAxEggcLT7BEDUwO9JF1gEQOQ4vyN6tANA9LCO/dwQA0AGKV7XP20CQDsQlQLEMAJAFqEtsaLJAUAmGf2KBSYBQEalVtKD/gBANpHMZGiCAECMEjh9lr3/PziVRdT0pP8/sQLXMFx2/j/Q8nXkIS/9P+wp4qCGxvw/8OIUmOfn+z8Q07NLraD6P1vlF2MHWfo/MMNS/3JZ+T8/HnQqBiH4P1Sz8bI4Evg/dKOQZv7K9j8dzFH5EWn2P5STLxrEg/U/AI3EzXEH9T+0g87NiTz0P0lD+rzixPM/1HNtgU/18j8IGHm2YnLyP/hjDDUVrvE/wLpvf+UY8T8YVKvo2mbwPxbw3WOckO8/cIiUOEE/7j80cjO5VfrsP7Bo0p/MsOs/5O/v5eWL6j/wSBAHWCLpPwO+So/LYOg/MClObuOT5j8kStk3r2zmPxrwO0w0auQ/dAmM1W4F5D8ksqzHjVziP7jpyTz6duE/0gPOoZuG4D/EK3S+nhTeP/CTD0gL0d0/GeBtTXZN2z9wVIsWIrTYP1a4rubPgdg/6AWn6b++1T/4FAflOJfTP3q0sXG5PdM/TVf+qLLV0D+fOFL57Y/NP/CqBWef9Mw/hTC6kiqIyT+EsgpY9nbFPwAs/QPNusI/5bq4TRqjwT/YRbkPow69P+Ph8DoYSLc/AFrpQfUBsT9SOLjaYBqoPzK/dO12sqM/VENzEhmOoD8+MxWZJRaaP7ITNlMZUJc/RhqNtFMEmj8p3zr1tGubP9N71kJ19pw/TDUH2dC2pT8AWulB9QGxPw==","dtype":"float64","order":"little","shape":[518]},"y":{"__ndarray__":"nyd79XvO5T+QzLpGmwboP3xx+pe6Puo/aBY66dl27D+AiRHFDeztP1i7eTr5ru4/IrDcRYxz8D9vlZVpUILwP5qCfO6bj/E/EFUcl6ur8j/yQtrpWa/yP4gnvD+7x/M//vlb6Mrj9D90zPuQ2v/1P+yemznqG/c/eOzvg8XA9z9kcTvi+Tf4P9hD24oJVPk/TxZ7Mxlw+j8QnmCkVrz6P8joGtwojPs/QLu6hDio/D+0jVotSMT9P26SM6uxMf4/LGD61Vfg/j+kMpp+Z/z/P1K1UmC7XwBAjAKdkzuMAEDI6+xnQxoBQB5gVBfVgAFABNU8PEuoAUBAvowQUzYCQHqn3ORaxAJAsaUVjRUDA0C2kCy5YlIDQFMrYq14xgNA8nl8jWrgA0AsY8xhcm4EQISHXyMukQRAaEwcNnr8BECkNWwKgooFQAYPi9gokQVA4B683okYBkA+eNA6MWIGQBoIDLORpgZAfiSRE+4iB0BW8VuHmTQHQJLaq1uhwgdAEeIruZLxB0DOw/svqVAIQODvbg0OlwhACK1LBLHeCEA82cWahBUJQESWm9i4bAlAZBrkSkuwCUCAf+uswPoJQBR0GCsHgQpAumg7gciICkD2UYtV0BYLQGSyUO9THgtAMjvbKdikC0BWBW0dQLgLQG4kK/7fMgxAsAw9vSdwDECoDXvS58AMQArFbqUeDQ1A5PbKpu9ODUBp7ZPRt5YNQCDgGnv33A1AMP8hTyYYDkBayWpP/2oOQNZBbBwIkA5AhjXF8W/tDkCWsrojB/kOQKwCncsDPA9A0psK+A6HD0AmMeudvPcPQIdCLWaLChBAMMZR4Vk0EEAkN1VQj1EQQCNrScL+YBBAfff/7EGJEEDCK306k5gQQHqIJ+JctxBAYCClJJffEEAKFLV/nd8QQG2tRngaCRFA/RTNDpsmEUCesqR2ZScRQEZRkoVGURFAmwn1+J5tEUDHscu1+m0RQJJ/pHOIlhFAOf4c46K0EUCLAnZqi8gRQDQgvppr9xFA1/JEzab7EUC8yifFCR4SQDITxL4kPBJAdOdst6pCEkC/NjZoqVsSQI7iALbZbBJAYIhqxLVvEkCdWpHdIHESQFoVOB4XfBJAEtyUoa6JEkCDIzRAYI4SQMXmR8xUoRJAmqs4GY+1EkAk+n1N2csSQLDQvIuy0BJAOTyCJFjkEkCg/Ke8NPYSQNgK00Lg8BJAwxjOOKPcEkCZY6gKPNYSQLDQvIuy0BJA4xRRuInPEkCwpfk5ZM0SQLDQvIuy0BJAZpzboBbWEkDt68IABt8SQDzLDnHz1RJAsNC8i7LQEkD/9Bh+va4SQEL448tMohJAK9kyHMmoEkBC4m9aS6ISQBLclKGuiRJA7hZHs4tKEkB052y3qkISQBxZVFejGhJA6KvDeUEHEkDX8kTNpvsRQK/TxpQO0BFAOf4c46K0EUCleuoutZMRQJsJ9fiebRFAePr4IaJWEUD9FM0OmyYRQPduA9vJ7xBAYCClJJffEEA5FFyR8ZwQQMIrfTqTmBBAJDdVUI9REEDgC2VijhUQQIdCLWaLChBA0psK+A6HD0DOFRye8UQPQJayuiMH+Q5AWclqT/9qDkAg4Bp799wNQOT2yqbvTg1AqA170ufADEBYz3qhxFkMQG4kK/7fMgxAMjvbKdikC0D2UYtV0BYLQOL33egYlgpAumg7gciICkCAf+uswPoJQKk+as6ktglARZab2LhsCUAIrUsEsd4IQM7D+y+pUAhAk9qrW6HCB0BV8VuHmTQHQBoIDLORpgZA4B683okYBkDnb5Jx1JIFQKQ1bAqCigVAaEwcNnr8BEAsY8xhcm4EQPJ5fI1q4ANA/Ui+dDiDA0C2kCy5YlIDQHqn3ORaxAJAQL6MEFM2AkBJy7kqJugBQATVPDxLqAFAyOvsZ0MaAUBU3qoqFrwAQIwCnZM7jABApDKafmf8/z8sYPrVV+D+P4BA3XTqkf4/tI1aLUjE/T/0ap76rbj8P0C7uoQ4qPw/yOga3CiM+z948zL8EB77P1AWezMZcPo/2UPbiglU+T/CIJYX5AX5P2RxO+L5N/g/7Z6bOeob9z88JesBqxD3P3TM+5Da//U/ZU7TCvfM9T/++VvoyuP0P3t/LORSVPQ/iCe8P7vH8z8QVRyXq6vyP2JUqfFKSPI/moJ87puP8T8isNxFjHPwP4ILo367P/A/WLt5Ovmu7j/ABpkmOcLtP2gWOunZduw/bJP2/urI6z98cfqXuj7qP4YMNdvuzuk/kMy6RpsG6D8c9Gs0dTznP6Ane/V7zuU/jH8Ah+jH5D+0gjukXJbjP6pavnVh0eI/xN37Uj1e4T8yXnSxFQPhP7BxeAM8TN4/6J60cg2O3T/QJ/lg/dvZPxzjy4+a39g/+N15vr5r1T/oRJrogSDVP4QvynRsadE/IJT6G4D70D+sexKVOe3LP4CU9vKCFsk/Z4RmsAy7xT/QAPitBTbAP2YA9FEp0L4/QLTloyFWrT+tLxDZcUqtP+Wvhj0GGIS/AGpSwE2viL+kPw5Fm96vv8B0B0Lk1rS/pAKy/9l1ur/cKkrSGzXCvxBOAmbvS8O/BjxAEyr/x7/Q4QCrbCzMv1/+k1s0Zc2//jvWXJ/I0L9Bq16lBU7Sv8C6//d0htK//XEMRM0j1L98GwaMgJDVv5gEf5qz9ta/BlFBAzQD178Q8AxwYW7Zv3hO/jzyZtu/24GyYqcm3L86/QR377Xev1CYfd8w19+/t/OUpduS4L/Mc/OK/8vhvxhx/sC3I+K/Gp7saN3I4r/sHk8XRVTjv7TldbfihuO/GhS8WD14478aTLjemqTjv0SbBkCVUeS/BBY+Etdb5L/k7PXTlyvlv3gluyjso+W/hyF59AP/5b9k7OLnf+Xlvwk7oofnReW/HpPF+d/r5L++Eo/MPuPkv/l/Sp0N0eS/2ISLZwSy5L/lMTwtvHjkvwQWPhLXW+S/Rrwx8HQK5L9BM59/tKfjv52rFhjVmOO/O9Hgifln478Ycf7AtyPiv6i6ltAiSuG/UZh93zDX379wSMmliPPdv3hO/jzyZtu/EPLaWy4p2b+YBH+as/bWvxcnLgU0+dS/VeJPk831079G+vnRzO3Sv8C6//d0htK/S+MrPsBO0L/P4QCrbCzMvxBOAmbvS8O/wHQHQuTWtL9XKPlW04OzvwBqUsBNr4i/QB4QxE8KTz9AtOWjIVatP5xbXGst/q8/0AD4rQU2wD+AlPbyghbJPyCU+huA+9A/mu/swUk+1D/43Xm+vmvVP9An+WD929k/sHF4AzxM3j/E3ftSPV7hP7SCO6RcluM/djJc7RG24z+fJ3v1e87lP9BPbVD5qew/aBY66dl27D98cfqXuj7qP3Qq5Z8uOug/kMy6RpsG6D+gJ3v1e87lP7SCO6RcluM/BWb2t68z4j/E3ftSPV7hP5g8Hi9tdOA/sHF4AzxM3j/YbQihgtbcP9An+WD929k/OSqBo13K2D/Sj7Ko9C/WP/jdeb6+a9U/HEy1Dvc01D9lagK6+a3SP81UZGZ0j9E/IJT6G4D70D9aCY/qhGfQP1BHVwvz684/FvF0F8aDzj9/OmIqi+vOP1jSqB+jg88/phCIv7g20D879+5zbLfQPwAEyh1x79A/IJT6G4D70D+OPTnpag7RP4pZHE9esdE/kA5eVqHT0j8quISbKlfUP/jdeb6+a9U/BvqAo5s01j90Z0UCOyfYP9An+WD929k/EEsvK8E02j8wZ+qoVAzcP5qfWl3ACd4/sHF4AzxM3j+PaYqU7BbgP8Td+1I9XuE/HtFDRUVg4T+wUzmbqKPiP7SCO6RcluM/LdMo0yP/4z9rPoFWuJHlP6Ane/V7zuU/eMiS5Mll5z+QzLpGmwboPzatVVOGROk/fHH6l7o+6j8qX8QhVxHrP2gWOunZduw/ShrT1rba7D9F2x6ytp/uP1i7eTr5ru4/6+buoCw98D8isNxFjHPwP2icPdfLUPE/moJ87puP8T9sfGSI2JTyPxBVHJerq/I/iCe8P7vH8z/J76hCyeTzP/75W+jK4/Q/3rC6lHkj9T90zPuQ2v/1P6ocfYRNcfY/7J6bOeob9z+MW5ltbPz3P2RxO+L5N/g/2EPbiglU+T8c1TszsNT5P1AWezMZcPo/yOga3CiM+z+BKPh5gvr7P0C7uoQ4qPw/tI1aLUjE/T80o0eCiBL+Pyxg+tVX4P4/pDKafmf8/z9ptmtkUDAAQIwCnZM7jABAyOvsZ0MaAUAOZEo1B3YBQATVPDxLqAFAQL6MEFM2AkB6p9zkWsQCQMIepjqRLgNAtpAsuWJSA0DyeXyNauADQCxjzGFybgRAaEwcNnr8BECkNWwKgooFQOAevN6JGAZAGggMs5GmBkBW8VuHmTQHQJLaq1uhwgdAzsP7L6lQCEAIrUsEsd4IQESWm9i4bAlAfOEPZmC7CUCAf+uswPoJQLpoO4HIiApA1OmlyLEEC0D2UYtV0BYLQDI72ynYpAtArP0Wgj+xC0BuJCv+3zIMQFvU2Zx0hQxAqA170ufADEDK1OxVPSANQOT2yqbvTg1A/ymuhB50DUAiLsTY1MoNQCDgGnv33A1AbopRcsH+DUBerf4NfTkOQFrJak//ag5Ayk6IY0FyDkDkdT2fBI0OQMOEkIrQlw5Apfsd2DShDkAG2NolIKkOQJBMEpGDoQ5AJkxHlI6IDkDRk48stG4OQFrJak//ag5A+0bIA8FfDkDY/7P5m1AOQCgCqsJhPg5AfL4bs8AhDkAEP1RBF/QNQCDgGnv33A1AoqsPhfyyDUByuQCQyWMNQOT2yqbvTg1A27xnHIoRDUA1xzEl58UMQKgNe9LnwAxAjCnRCnSKDECpGd5WKEsMQG4kK/7fMgxA+Ocz/FQEDEA6wARHzLYLQDI72ynYpAtAOn8aIydrC0D2UYtV0BYLQOO4jDj3EgtAlK/yXZOsCkC6aDuByIgKQGIxjvhNLgpAgH/rrMD6CUBoDrCikaAJQESWm9i4bAlABAQYTPMVCUAIrUsEsd4IQLNRp/1FjwhAzsP7L6lQCEB2EgcoTgUIQJLaq1uhwgdABT4/3EV6B0BW8VuHmTQHQA+QolBD6gZAGggMs5GmBkD/BVPNcEoGQOAevN6JGAZAShfhjo+VBUCkNWwKgooFQGhMHDZ6/ARABVFBawbhBEAsY8xhcm4EQNAhS1OBKQRA8nl8jWrgA0C3kCy5YlIDQK0SHk31QwNAeqfc5FrEAkBjOaTT3j8CQEC+jBBTNgJABNU8PEuoAUD6L+hL0iwBQMjr7GdDGgFAjAKdkzuMAECkMpp+Z/z/P54HEyIvz/8/LGD61Vfg/j+0jVotSMT9PzIONh8c+fw/QLu6hDio/D/I6BrcKIz7P1AWezMZcPo/2EPbiglU+T9kcTvi+Tf4P+yemznqG/c/dMz7kNr/9T/++VvoyuP0P4gnvD+7x/M/EFUcl6ur8j+agnzum4/xPyKw3EWMc/A/WLt5Ovmu7j/QT21Q+ansPw==","dtype":"float64","order":"little","shape":[518]}},"selected":{"id":"21255"},"selection_policy":{"id":"21254"}},"id":"21227","type":"ColumnDataSource"},{"attributes":{},"id":"21246","type":"BasicTickFormatter"},{"attributes":{},"id":"21196","type":"LinearScale"},{"attributes":{"callback":null},"id":"21215","type":"HoverTool"},{"attributes":{"source":{"id":"21227"}},"id":"21231","type":"CDSView"},{"attributes":{"children":[{"id":"21263"},{"id":"21261"}]},"id":"21264","type":"Column"},{"attributes":{"formatter":{"id":"21249"},"major_label_policy":{"id":"21251"},"ticker":{"id":"21205"}},"id":"21204","type":"LinearAxis"},{"attributes":{},"id":"21259","type":"Selection"},{"attributes":{},"id":"21211","type":"WheelZoomTool"},{"attributes":{},"id":"21205","type":"BasicTicker"},{"attributes":{"toolbars":[{"id":"21218"}],"tools":[{"id":"21208"},{"id":"21209"},{"id":"21210"},{"id":"21211"},{"id":"21212"},{"id":"21213"},{"id":"21214"},{"id":"21215"}]},"id":"21262","type":"ProxyToolbar"},{"attributes":{"source":{"id":"21232"}},"id":"21236","type":"CDSView"},{"attributes":{"children":[[{"id":"21191"},0,0]]},"id":"21261","type":"GridBox"},{"attributes":{},"id":"21248","type":"AllLabels"},{"attributes":{"bottom_units":"screen","fill_alpha":0.5,"fill_color":"lightgrey","left_units":"screen","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"right_units":"screen","syncable":false,"top_units":"screen"},"id":"21216","type":"BoxAnnotation"},{"attributes":{"fill_color":"#4a98c9","line_alpha":0.25,"line_color":"#4a98c9","x":{"field":"x"},"y":{"field":"y"}},"id":"21233","type":"Patch"},{"attributes":{},"id":"21201","type":"BasicTicker"},{"attributes":{"fill_color":"#94c4df","line_alpha":0.25,"line_color":"#94c4df","x":{"field":"x"},"y":{"field":"y"}},"id":"21228","type":"Patch"},{"attributes":{"data":{"x":{"__ndarray__":"r2v802MA8T9GnF5bc7HwPx40FW2ikfA/ocfIoPqd8D8E3U17HcTwPxl878lr9fA/AuPpOfRG8T/4Yww1Fa7xP5CRyAaWuPE/8rehluwg8j+iIQvBQIXyP9RzbYFP9fI/Vj2xDZr18j/koV1kMZrzP7SDzs2JPPQ/zERFezRp9D9EEKLBoHf1P5STLxrEg/U/1EveYLG/9j9zo5Bm/sr2PxcYdbysCfg/VLPxsjgS+D8GlbD0lzz5PzDDUv9yWfk/OjIaEwaI+j8Q07NLraD6P/DiFJjn5/s/Rqo3dD0Y/D/Q8nXkIS/9PwciGf2B5f0/sALXMFx2/j+MEjh9lr3/P3D+jge/EQBANpHMZGiCAEAmGf2KBSYBQBahLbGiyQFA4oiq1PsnAkAGKV7XP20CQPSwjv3cEANA5Di/I3q0A0DUwO9JF1gEQMRIIHC0+wRAZ2Izt6UyBUC00FCWUZ8FQKRYgbzuQgZAfHOh61igBkCS4LHii+YGQE2GPiLeSQdAgmjiCCmKB0B30JYyRsoHQItNx/3uHghAcvASL8YtCEAUq7nHPU4IQJQYNMw/XghAunmBGL5dCEDcOvPCGlYIQEkBTjQrPQhAcvASL8YtCEC7gYrrXxMIQPAnFbkb4gdAWfOtKHqqB0CCaOIIKYoHQMWErMciYQdABzyoSlkKB0CS4LHii+YGQDgsiYCRqAZApFiBvO5CBkD8C8vgUTkGQGfQk5YgsgVAtNBQllGfBUCuCUyjXhwFQMRIIHC0+wRAicJbykV6BEDUwO9JF1gEQFB49aF11QNA5Di/I3q0A0D27Lt/TDEDQPSwjv3cEANAHRIk1EdyAkAGKV7XP20CQBahLbGiyQFAG8PpUFl5AUAmGf2KBSYBQDaRzGRoggBAiJ8JLZZeAECMEjh9lr3/P7AC1zBcdv4/U5gLarFk/T/Q8nXkIS/9P/DiFJjn5/s/ENOzS62g+j8ww1L/cln5P1Sz8bI4Evg/dKOQZv7K9j92nH95hkX2P5STLxrEg/U/tIPOzYk89D+6t9etHd3zP9RzbYFP9fI/5pR1AymI8j/4Yww1Fa7xP69r/NNjAPE/","dtype":"float64","order":"little","shape":[102]},"y":{"__ndarray__":"7J6bOeob9z9kcTvi+Tf4P9hD24oJVPk/UBZ7Mxlw+j/I6BrcKIz7P0C7uoQ4qPw/tI1aLUjE/T8/hXKwH8b+Pyxg+tVX4P4/pDKafmf8/z+MAp2TO4wAQAtlWB7nGQFAyOvsZ0MaAUAE1Tw8S6gBQFzyj/JTGgJAQL6MEFM2AkB6p9zkWsQCQPkNhDsxygJAtpAsuWJSA0DcpmQ3WlcDQPJ5fI1q4ANAENZljVTkA0AsY8xhcm4EQCHtCG8NewRAaEwcNnr8BECEe1ZQ3gUFQAEvn1k2egVApDVsCoKKBUA2NLcGKuEFQOAevN6JGAZApt7G16lCBkAZI6dyy5MGQBoIDLORpgZAywYOOhPPBkDU5G7CNPoGQLmB9oy7HwdAVvFbh5k0B0CBwJ3gFEQHQKFuZdygYgdA5Hy0M1NwB0DaMZc9NmkHQCBALYOQRQdAVvFbh5k0B0CcyaDSWBIHQNZ67MqI2AZAGggMs5GmBkDd58quMHQGQOAevN6JGAZAq4XSIyvXBUCkNWwKgooFQGhMHDZ6/ARAUi5kGtPUBEAsY8xhcm4EQPJ5fI1q4ANAtpAsuWJSA0B6p9zkWsQCQEC+jBBTNgJAPICZkY//AUAE1Tw8S6gBQMjr7GdDGgFAjAKdkzuMAEDcXFdNd00AQKQymn5n/P8/LGD61Vfg/j8aAw1DA3H+P7SNWi1IxP0/zjp0+8a+/D9Au7qEOKj8P8joGtwojPs/hDdCnh9p+z9QFnszGXD6P6ST36sJOfo/2EPbiglU+T/e6ofOKhv5P2RxO+L5N/g/LLRD2Q/+9z/snps56hv3P/olmqTQ5fY/dMz7kNr/9T8vt2W/+/j1P30cb/EuOfU//vlb6Mrj9D9blKW/Oon0P/2Xd/h55vM/iCe8P7vH8z9EYaaQhWDzP2l/ilMc+PI/EFUcl6ur8j9zOAIcdJ3yP8zAQM2SVPI/VtlN8N0o8j+l/WFHPyryP/TdNABqSPI/peK6cdKC8j8QVRyXq6vyP5iior/H+fI/4JGWrHOT8z+IJ7w/u8fzPzqUrXq8afQ//vlb6Mrj9D90zPuQ2v/1P+yemznqG/c/","dtype":"float64","order":"little","shape":[102]}},"selected":{"id":"21259"},"selection_policy":{"id":"21258"}},"id":"21237","type":"ColumnDataSource"},{"attributes":{"fill_alpha":0.1,"fill_color":"#1764ab","line_alpha":0.1,"line_color":"#1764ab","x":{"field":"x"},"y":{"field":"y"}},"id":"21239","type":"Patch"},{"attributes":{},"id":"21255","type":"Selection"},{"attributes":{"data_source":{"id":"21227"},"glyph":{"id":"21228"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"21229"},"view":{"id":"21231"}},"id":"21230","type":"GlyphRenderer"},{"attributes":{"source":{"id":"21237"}},"id":"21241","type":"CDSView"},{"attributes":{"fill_color":"#1764ab","line_alpha":0.25,"line_color":"#1764ab","x":{"field":"x"},"y":{"field":"y"}},"id":"21238","type":"Patch"},{"attributes":{},"id":"21244","type":"Title"},{"attributes":{},"id":"21209","type":"PanTool"},{"attributes":{"below":[{"id":"21200"}],"center":[{"id":"21203"},{"id":"21207"}],"height":500,"left":[{"id":"21204"}],"output_backend":"webgl","renderers":[{"id":"21230"},{"id":"21235"},{"id":"21240"}],"title":{"id":"21244"},"toolbar":{"id":"21218"},"toolbar_location":null,"width":500,"x_range":{"id":"21242"},"x_scale":{"id":"21196"},"y_range":{"id":"21243"},"y_scale":{"id":"21198"}},"id":"21191","subtype":"Figure","type":"Plot"},{"attributes":{},"id":"21208","type":"ResetTool"},{"attributes":{"end":6.298876126517565,"start":-2.508684463715187},"id":"21243","type":"Range1d"},{"attributes":{"fill_alpha":0.1,"fill_color":"#4a98c9","line_alpha":0.1,"line_color":"#4a98c9","x":{"field":"x"},"y":{"field":"y"}},"id":"21234","type":"Patch"},{"attributes":{"data":{"x":{"__ndarray__":"SzUH2dC2pT/Re9ZCdfacPynfOvW0a5s/RhqNtFMEmj+0EzZTGVCXPz4zFZklFpo/VENzEhmOoD8yv3TtdrKjP1M4uNpgGqg/AFrpQfUBsT/j4fA6GEi3P9hFuQ+jDr0/5bq4TRqjwT8ALP0DzbrCP4SyClj2dsU/hTC6kiqIyT/wqgVnn/TMP584Uvntj80/TVf+qLLV0D96tLFxuT3TP/gUB+U4l9M/6AWn6b++1T9WuK7mz4HYP3BUixYitNg/GeBtTXZN2z/wkw9IC9HdP8QrdL6eFN4/0gPOoZuG4D+46ck8+nbhPySyrMeNXOI/dAmM1W4F5D8a8DtMNGrkPyRK2TevbOY/MClObuOT5j8EvkqPy2DoP/BIEAdYIuk/5O/v5eWL6j+waNKfzLDrPzRyM7lV+uw/cIiUOEE/7j8W8N1jnJDvPxhUq+jaZvA/wLpvf+UY8T/4Yww1Fa7xPwgYebZicvI/1HNtgU/18j9JQ/q84sTzP7SDzs2JPPQ/AI3EzXEH9T+Uky8axIP1Px3MUfkRafY/dKOQZv7K9j9Us/GyOBL4Pz8edCoGIfg/MMNS/3JZ+T9b5RdjB1n6PxDTs0utoPo/8OIUmOfn+z/rKeKghsb8P9DydeQhL/0/sALXMFx2/j84lUXU9KT/P4wSOH2Wvf8/NpHMZGiCAEBGpVbSg/4AQCYZ/YoFJgFAFqEtsaLJAUA7EJUCxDACQAYpXtc/bQJA9LCO/dwQA0DkOL8jerQDQNTA70kXWARAxEggcLT7BEDHnyo90XoFQLTQUJZRnwVApFiBvO5CBkCS4LHii+YGQIJo4ggpigdAcvASL8YtCEBieENVY9EIQFIAdHsAdQlAQIikoZ0YCkAWfwQKQjEKQDAQ1cc6vApAIJgF7tdfC0CmZsJPu88LQBAgNhR1AwxAAKhmOhKnDEACyl6+2u4MQPAvl2CvSg1AwiTA5iTADUDet8eGTO4NQJa3VxsCKA5Azj/4rOmRDkD/wfigYZ0OQDY46FrNJw9Avsco04Y1D0DjlDZy94QPQEEbZ63Jwg9Ark9Z+SPZD0Dp2vfvMfkPQH11FZ4UExBArdJO3voeEEB+E9MOTSEQQHt6McgcIBBAHdgoeeUeEEBJIgT/PyEQQAxWDAmnJBBAW1iLw8wjEEApIJb4Vh0QQAp50BbGDBBAH5KUElbnD0CuT1n5I9kPQJQLfPVlsg9An2yfEzWCD0D9iPdZgUwPQL7HKNOGNQ9AYREDxM4OD0DO1JsjtccOQM4/+KzpkQ5Asd9dljB4DkB50eE7lykOQN63x4ZM7g1AfqYrAF7YDUCF+zkWZoINQPAvl2CvSg1AIpw6i1MpDUAS8+C3WNYMQACoZjoSpwxAnrBp+pSBDECSIAqwtxwMQBAgNhR1AwxAU2B0bkitC0AgmAXu118LQMdblOVDLAtAMBDVxzq8CkC3vBSpmpsKQECIpKGdGApA2ajGcm4KCkA+o4BcJ4AJQFIAdHsAdQlAMIoEJoryCEBieENVY9EIQC6qtm43UAhAcvASL8YtCECj6Iw9e48HQIFo4ggpigdAkuCx4ovmBkAIZDmxVcEGQKRYgbzuQgZAaPCd80r3BUC00FCWUZ8FQL1ucbVeMgVAxEggcLT7BEDThZL1o20EQNTA70kXWARA5Di/I3q0A0Cbu6WUIIQDQPSwjv3cEANABile1z9tAkCMx27xMWwCQBahLbGiyQFAWJm+3gM5AUAmGf2KBSYBQDaRzGRoggBAjBI4fZa9/z+Td1Y5xX//P7AC1zBcdv4/0PJ15CEv/T+EC87SVaT8P/DiFJjn5/s/ENOzS62g+j8ww1L/cln5P1Sz8bI4Evg/TsdkX5dG9z90o5Bm/sr2P5STLxrEg/U/tIPOzYk89D/Uc22BT/XyP/hjDDUVrvE/GFSr6Npm8D9wiJQ4QT/uP7Fo0p/MsOs/XWCiqmR76j/wSBAHWCLpPzApTm7jk+Y/dAmM1W4F5D9cJvJlxV7iP7jpyTz6duE/8JMPSAvR3T+fO86E4E/cP3BUixYitNg/shUCJp0i1z/4FAflOJfTP4Lc1tKMqNA/8KoFZ5/0zD8k7b2CG3bIPyq08ym+78U/fTUrueYowz8ALP0DzbrCPyznbKE+mLo/Z5CXRVmssT8AWulB9QGxP0s1B9nQtqU/+GMMNRWu8T/llHUDKYjyP9RzbYFP9fI/urfXrR3d8z+0g87NiTz0P5STLxrEg/U/dpx/eYZF9j90o5Bm/sr2P1Sz8bI4Evg/MMNS/3JZ+T8Q07NLraD6P/DiFJjn5/s/0PJ15CEv/T9UmAtqsWT9P7AC1zBcdv4/jBI4fZa9/z+Inwktll4AQDaRzGRoggBAJhn9igUmAUAbw+lQWXkBQBahLbGiyQFABile1z9tAkAdEiTUR3ICQPSwjv3cEANA9uy7f0wxA0DkOL8jerQDQFB49aF11QNA1MDvSRdYBECKwlvKRXoEQMRIIHC0+wRArglMo14cBUC00FCWUZ8FQGfQk5YgsgVA/AvL4FE5BkCkWIG87kIGQDgsiYCRqAZAkuCx4ovmBkAHPKhKWQoHQMWErMciYQdAgmjiCCmKB0BZ860oeqoHQPAnFbkb4gdAu4GK618TCEBy8BIvxi0IQEoBTjQrPQhA3DrzwhpWCEC6eYEYvl0IQJUYNMw/XghAFKu5xz1OCEBy8BIvxi0IQIpNx/3uHghAd9CWMkbKB0CCaOIIKYoHQE2GPiLeSQdAkuCx4ovmBkB8c6HrWKAGQKRYgbzuQgZAtNBQllGfBUBoYjO3pTIFQMRIIHC0+wRA1MDvSRdYBEDkOL8jerQDQPSwjv3cEANABile1z9tAkDiiKrU+ycCQBahLbGiyQFAJhn9igUmAUA2kcxkaIIAQHD+jge/EQBAjBI4fZa9/z+wAtcwXHb+PwciGf2B5f0/0PJ15CEv/T9Fqjd0PRj8P/DiFJjn5/s/ENOzS62g+j86MhoTBoj6PzDDUv9yWfk/B5Ww9Jc8+T9Us/GyOBL4PxcYdbysCfg/dKOQZv7K9j/US95gsb/2P5STLxrEg/U/RBCiwaB39T/MREV7NGn0P7SDzs2JPPQ/5KFdZDGa8z9WPbENmvXyP9RzbYFP9fI/oiELwUCF8j/yt6GW7CDyP5CRyAaWuPE/+GMMNRWu8T8C4+k59EbxPxl878lr9fA/Bd1Nex3E8D+gx8ig+p3wPx40FW2ikfA/RpxeW3Ox8D+va/zTYwDxP/hjDDUVrvE/","dtype":"float64","order":"little","shape":[306]},"y":{"__ndarray__":"V7t5Ovmu7j8isNxFjHPwP5qCfO6bj/E/EFUcl6ur8j+IJ7w/u8fzP/75W+jK4/Q/dMz7kNr/9T/snps56hv3P2RxO+L5N/g/2EPbiglU+T9QFnszGXD6P8joGtwojPs/QLu6hDio/D8yDjYfHPn8P7SNWi1IxP0/LGD61Vfg/j+eBxMiL8//P6Qymn5n/P8/jAKdkzuMAEDI6+xnQxoBQPov6EvSLAFABNU8PEuoAUBBvowQUzYCQGI5pNPePwJAeqfc5FrEAkCuEh5N9UMDQLaQLLliUgNA8nl8jWrgA0DQIUtTgSkEQCxjzGFybgRABVFBawbhBEBoTBw2evwEQKU1bAqCigVAShfhjo+VBUDgHrzeiRgGQP8FU81wSgZAGggMs5GmBkAQkKJQQ+oGQFbxW4eZNAdABT4/3EV6B0CS2qtbocIHQHYSByhOBQhAzsP7L6lQCECzUaf9RY8IQAitSwSx3ghABAQYTPMVCUBElpvYuGwJQGgOsKKRoAlAgH/rrMD6CUBiMY74TS4KQLpoO4HIiApAlK/yXZOsCkDjuIw49xILQPZRi1XQFgtAOn8aIydrC0AyO9sp2KQLQDrABEfMtgtA+Ocz/FQEDEBuJCv+3zIMQKkZ3lYoSwxAiynRCnSKDECoDXvS58AMQDXHMSXnxQxA2rxnHIoRDUDk9sqm704NQHK5AJDJYw1AoqsPhfyyDUAg4Bp799wNQAQ/VEEX9A1AfL4bs8AhDkApAqrCYT4OQNf/s/mbUA5A+0bIA8FfDkBayWpP/2oOQNGTjyy0bg5AJkxHlI6IDkCQTBKRg6EOQAXY2iUgqQ5Apfsd2DShDkDEhJCK0JcOQOR1PZ8EjQ5Ayk6IY0FyDkBayWpP/2oOQF2t/g19OQ5AbopRcsH+DUAg4Bp799wNQCEuxNjUyg1A/ymuhB50DUDk9sqm704NQMrU7FU9IA1AqA170ufADEBb1NmcdIUMQG4kK/7fMgxArP0Wgj+xC0AyO9sp2KQLQPZRi1XQFgtA0+mlyLEEC0C6aDuByIgKQIB/66zA+glAfOEPZmC7CUBElpvYuGwJQAitSwSx3ghAzsP7L6lQCECS2qtbocIHQFbxW4eZNAdAGggMs5GmBkDgHrzeiRgGQKQ1bAqCigVAaEwcNnr8BEAsY8xhcm4EQPJ5fI1q4ANAtpAsuWJSA0DCHqY6kS4DQHqn3ORaxAJAQL6MEFM2AkAE1Tw8S6gBQA5kSjUHdgFAyOvsZ0MaAUCMAp2TO4wAQGm2a2RQMABApDKafmf8/z8sYPrVV+D+PzSjR4KIEv4/tI1aLUjE/T9Au7qEOKj8P4Eo+HmC+vs/yOga3CiM+z9QFnszGXD6PxzVOzOw1Pk/2EPbiglU+T9kcTvi+Tf4P41bmW1s/Pc/7J6bOeob9z+qHH2ETXH2P3TM+5Da//U/3bC6lHkj9T/++VvoyuP0P8jvqELJ5PM/iCe8P7vH8z8QVRyXq6vyP2x8ZIjYlPI/moJ87puP8T9onD3Xy1DxPyKw3EWMc/A/6+buoCw98D9Xu3k6+a7uP0TbHrK2n+4/ShrT1rba7D9oFjrp2XbsPypfxCFXEes/fHH6l7o+6j82rVVThkTpP5DMukabBug/eMiS5Mll5z+gJ3v1e87lP2o+gVa4keU/LdMo0yP/4z+0gjukXJbjP7BTOZuoo+I/HtFDRUVg4T/E3ftSPV7hP49pipTsFuA/sHF4AzxM3j+an1pdwAnePzBn6qhUDNw/EEsvK8E02j/QJ/lg/dvZP3NnRQI7J9g/BvqAo5s01j/43Xm+vmvVPyq4hJsqV9Q/kA5eVqHT0j+KWRxPXrHRP409OelqDtE/IJT6G4D70D8ABModce/QPzv37nNst9A/phCIv7g20D9Y0qgfo4PPP386YiqL684/FvF0F8aDzj9QR1cL8+vOP1oJj+qEZ9A/IJT6G4D70D/NVGRmdI/RP2VqArr5rdI/HEy1Dvc01D/43Xm+vmvVP9KPsqj0L9Y/OSqBo13K2D/QJ/lg/dvZP9htCKGC1tw/sHF4AzxM3j+YPB4vbXTgP8Td+1I9XuE/BWb2t68z4j+0gjukXJbjP6Ane/V7zuU/kMy6RpsG6D90KuWfLjroP3xx+pe6Puo/aBY66dl27D/PT21Q+ansP1e7eTr5ru4/dMz7kNr/9T/++VvoyuP0PzqUrXq8afQ/iCe8P7vH8z/fkZasc5PzP5iior/H+fI/EFUcl6ur8j+l4rpx0oLyP/TdNABqSPI/pf1hRz8q8j9W2U3w3SjyP8zAQM2SVPI/czgCHHSd8j8QVRyXq6vyP2p/ilMc+PI/RGGmkIVg8z+IJ7w/u8fzP/2Xd/h55vM/W5SlvzqJ9D/++VvoyuP0P30cb/EuOfU/MLdlv/v49T90zPuQ2v/1P/olmqTQ5fY/7J6bOeob9z8stEPZD/73P2RxO+L5N/g/3uqHziob+T/YQ9uKCVT5P6ST36sJOfo/UBZ7Mxlw+j+EN0KeH2n7P8joGtwojPs/Qbu6hDio/D/POnT7xr78P7WNWi1IxP0/GQMNQwNx/j8sYPrVV+D+P6Qymn5n/P8/3FxXTXdNAECMAp2TO4wAQMjr7GdDGgFABNU8PEuoAUA8gJmRj/8BQEC+jBBTNgJAeqfc5FrEAkC2kCy5YlIDQPJ5fI1q4ANALGPMYXJuBEBSLmQa09QEQGhMHDZ6/ARApDVsCoKKBUCrhdIjK9cFQOAevN6JGAZA3efKrjB0BkAaCAyzkaYGQNZ67MqI2AZAnMmg0lgSB0BW8VuHmTQHQCBALYOQRQdA2jGXPTZpB0DkfLQzU3AHQKJuZdygYgdAgcCd4BREB0BW8VuHmTQHQLmB9oy7HwdA1ORuwjT6BkDLBg46E88GQBoIDLORpgZAGSOncsuTBkCm3sbXqUIGQOAevN6JGAZANjS3BirhBUCkNWwKgooFQAEvn1k2egVAhXtWUN4FBUBoTBw2evwEQCHtCG8NewRALGPMYXJuBEAQ1mWNVOQDQPJ5fI1q4ANA3KZkN1pXA0C2kCy5YlIDQPkNhDsxygJAeqfc5FrEAkBAvowQUzYCQFvyj/JTGgJABNU8PEuoAUDI6+xnQxoBQAxlWB7nGQFAjAKdkzuMAECkMpp+Z/z/Pyxg+tVX4P4/PoVysB/G/j+0jVotSMT9P0C7uoQ4qPw/yega3CiM+z9QFnszGXD6P9dD24oJVPk/ZHE74vk3+D/snps56hv3P3TM+5Da//U/","dtype":"float64","order":"little","shape":[306]}},"selected":{"id":"21257"},"selection_policy":{"id":"21256"}},"id":"21232","type":"ColumnDataSource"},{"attributes":{"data_source":{"id":"21237"},"glyph":{"id":"21238"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"21239"},"view":{"id":"21241"}},"id":"21240","type":"GlyphRenderer"},{"attributes":{"end":6.777161016940845,"start":-3.3688158995803903},"id":"21242","type":"Range1d"},{"attributes":{"axis":{"id":"21200"},"grid_line_color":null,"ticker":null},"id":"21203","type":"Grid"},{"attributes":{"active_multi":null,"tools":[{"id":"21208"},{"id":"21209"},{"id":"21210"},{"id":"21211"},{"id":"21212"},{"id":"21213"},{"id":"21214"},{"id":"21215"}]},"id":"21218","type":"Toolbar"},{"attributes":{},"id":"21251","type":"AllLabels"},{"attributes":{},"id":"21258","type":"UnionRenderers"},{"attributes":{"toolbar":{"id":"21262"},"toolbar_location":"above"},"id":"21263","type":"ToolbarBox"},{"attributes":{"fill_alpha":0.5,"fill_color":"lightgrey","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"syncable":false,"xs_units":"screen","ys_units":"screen"},"id":"21217","type":"PolyAnnotation"},{"attributes":{},"id":"21213","type":"UndoTool"},{"attributes":{"data_source":{"id":"21232"},"glyph":{"id":"21233"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"21234"},"view":{"id":"21236"}},"id":"21235","type":"GlyphRenderer"},{"attributes":{},"id":"21198","type":"LinearScale"},{"attributes":{},"id":"21254","type":"UnionRenderers"},{"attributes":{"axis":{"id":"21204"},"dimension":1,"grid_line_color":null,"ticker":null},"id":"21207","type":"Grid"},{"attributes":{},"id":"21257","type":"Selection"},{"attributes":{},"id":"21249","type":"BasicTickFormatter"},{"attributes":{"overlay":{"id":"21217"}},"id":"21212","type":"LassoSelectTool"},{"attributes":{"formatter":{"id":"21246"},"major_label_policy":{"id":"21248"},"ticker":{"id":"21201"}},"id":"21200","type":"LinearAxis"}],"root_ids":["21264"]},"title":"Bokeh Application","version":"2.3.2"}}';
                  var render_items = [{"docid":"1dc2c5ac-d3e6-4f3e-9f19-38840cb4ef9e","root_ids":["21264"],"roots":{"21264":"1e7be886-016b-49fa-b1b0-2c6614040268"}}];
                  root.Bokeh.embed.embed_items(docs_json, render_items);
                
                  }
                  if (root.Bokeh !== undefined) {
                    embed_document(root);
                  } else {
                    var attempts = 0;
                    var timer = setInterval(function(root) {
                      if (root.Bokeh !== undefined) {
                        clearInterval(timer);
                        embed_document(root);
                      } else {
                        attempts++;
                        if (attempts > 100) {
                          clearInterval(timer);
                          console.log("Bokeh: ERROR: Unable to run BokehJS code because BokehJS library is missing");
                        }
                      }
                    }, 10, root)
                  }
                })(window);
              });
            };
            if (document.readyState != "loading") fn();
            else document.addEventListener("DOMContentLoaded", fn);
          })();
        },
        function(Bokeh) {
        
        
        }
      ];
    
      function run_inline_js() {
        
        for (var i = 0; i < inline_js.length; i++) {
          inline_js[i].call(root, root.Bokeh);
        }
        
      }
    
      if (root._bokeh_is_loading === 0) {
        console.debug("Bokeh: BokehJS loaded, going straight to plotting");
        run_inline_js();
      } else {
        load_libs(css_urls, js_urls, function() {
          console.debug("Bokeh: BokehJS plotting callback run at", now());
          run_inline_js();
        });
      }
    }(window));
  };
  if (document.readyState != "loading") fn();
  else document.addEventListener("DOMContentLoaded", fn);
})();