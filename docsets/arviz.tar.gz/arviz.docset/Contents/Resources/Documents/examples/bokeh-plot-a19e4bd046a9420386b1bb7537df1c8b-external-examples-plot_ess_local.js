(function() {
  var fn = function() {
    
    (function(root) {
      function now() {
        return new Date();
      }
    
      var force = false;
    
      if (typeof root._bokeh_onload_callbacks === "undefined" || force === true) {
        root._bokeh_onload_callbacks = [];
        root._bokeh_is_loading = undefined;
      }
    
      
      
    
      var element = document.getElementById("b1406617-0d83-4f9a-bd2e-9a8d2279dc9a");
        if (element == null) {
          console.warn("Bokeh: autoload.js configured with elementid 'b1406617-0d83-4f9a-bd2e-9a8d2279dc9a' but no matching script tag was found.")
        }
      
    
      function run_callbacks() {
        try {
          root._bokeh_onload_callbacks.forEach(function(callback) {
            if (callback != null)
              callback();
          });
        } finally {
          delete root._bokeh_onload_callbacks
        }
        console.debug("Bokeh: all callbacks have finished");
      }
    
      function load_libs(css_urls, js_urls, callback) {
        if (css_urls == null) css_urls = [];
        if (js_urls == null) js_urls = [];
    
        root._bokeh_onload_callbacks.push(callback);
        if (root._bokeh_is_loading > 0) {
          console.debug("Bokeh: BokehJS is being loaded, scheduling callback at", now());
          return null;
        }
        if (js_urls == null || js_urls.length === 0) {
          run_callbacks();
          return null;
        }
        console.debug("Bokeh: BokehJS not loaded, scheduling load and callback at", now());
        root._bokeh_is_loading = css_urls.length + js_urls.length;
    
        function on_load() {
          root._bokeh_is_loading--;
          if (root._bokeh_is_loading === 0) {
            console.debug("Bokeh: all BokehJS libraries/stylesheets loaded");
            run_callbacks()
          }
        }
    
        function on_error(url) {
          console.error("failed to load " + url);
        }
    
        for (let i = 0; i < css_urls.length; i++) {
          const url = css_urls[i];
          const element = document.createElement("link");
          element.onload = on_load;
          element.onerror = on_error.bind(null, url);
          element.rel = "stylesheet";
          element.type = "text/css";
          element.href = url;
          console.debug("Bokeh: injecting link tag for BokehJS stylesheet: ", url);
          document.body.appendChild(element);
        }
    
        const hashes = {"https://cdn.bokeh.org/bokeh/release/bokeh-2.3.2.min.js": "XypntL49z55iwGVUW4qsEu83zKL3XEcz0MjuGOQ9SlaaQ68X/g+k1FcioZi7oQAc", "https://cdn.bokeh.org/bokeh/release/bokeh-tables-2.3.2.min.js": "bEsM86IHGDTLCS0Zod8a8WM6Y4+lafAL/eSiyQcuPzinmWNgNO2/olUF0Z2Dkn5i", "https://cdn.bokeh.org/bokeh/release/bokeh-widgets-2.3.2.min.js": "TX0gSQTdXTTeScqxj6PVQxTiRW8DOoGVwinyi1D3kxv7wuxQ02XkOxv0xwiypcAH"};
    
        for (let i = 0; i < js_urls.length; i++) {
          const url = js_urls[i];
          const element = document.createElement('script');
          element.onload = on_load;
          element.onerror = on_error.bind(null, url);
          element.async = false;
          element.src = url;
          if (url in hashes) {
            element.crossOrigin = "anonymous";
            element.integrity = "sha384-" + hashes[url];
          }
          console.debug("Bokeh: injecting script tag for BokehJS library: ", url);
          document.head.appendChild(element);
        }
      };
    
      function inject_raw_css(css) {
        const element = document.createElement("style");
        element.appendChild(document.createTextNode(css));
        document.body.appendChild(element);
      }
    
      
      var js_urls = ["https://cdn.bokeh.org/bokeh/release/bokeh-2.3.2.min.js", "https://cdn.bokeh.org/bokeh/release/bokeh-widgets-2.3.2.min.js", "https://cdn.bokeh.org/bokeh/release/bokeh-tables-2.3.2.min.js"];
      var css_urls = [];
      
    
      var inline_js = [
        function(Bokeh) {
          Bokeh.set_log_level("info");
        },
        
        function(Bokeh) {
          (function() {
            var fn = function() {
              Bokeh.safely(function() {
                (function(root) {
                  function embed_document(root) {
                    
                  var docs_json = '{"b321cd7c-cd87-4ca3-af30-f964036fa2f7":{"defs":[],"roots":{"references":[{"attributes":{"callback":null},"id":"18501","type":"HoverTool"},{"attributes":{},"id":"18499","type":"UndoTool"},{"attributes":{},"id":"18478","type":"DataRange1d"},{"attributes":{"fill_alpha":0.5,"fill_color":"lightgrey","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"syncable":false,"xs_units":"screen","ys_units":"screen"},"id":"18503","type":"PolyAnnotation"},{"attributes":{"data_source":{"id":"18519"},"glyph":{"id":"18518"},"hover_glyph":null,"muted_glyph":null,"view":{"id":"18521"}},"id":"18520","type":"GlyphRenderer"},{"attributes":{},"id":"18500","type":"SaveTool"},{"attributes":{"axis_label":"Quantile","formatter":{"id":"18527"},"major_label_policy":{"id":"18529"},"ticker":{"id":"18487"}},"id":"18486","type":"LinearAxis"},{"attributes":{"data":{"x":{"__ndarray__":"AAAAAAAAAACamZmZmZmpP5qZmZmZmbk/NDMzMzMzwz+amZmZmZnJPwAAAAAAANA/NDMzMzMz0z9nZmZmZmbWP5qZmZmZmdk/zczMzMzM3D8AAAAAAADgP5qZmZmZmeE/NDMzMzMz4z/NzMzMzMzkP2dmZmZmZuY/AAAAAAAA6D+amZmZmZnpPzQzMzMzM+s/zczMzMzM7D9nZmZmZmbuPw==","dtype":"float64","order":"little","shape":[20]},"y":{"__ndarray__":"PSWUrfrllUC6ZTfE07ObQIHSxpixD6BAXutlA2Fon0AWemawUmmdQBJdptJ4v59A48F0NdPPm0BhLg6FQP6cQNT8SMHKBJ1AN/hQuCybnECYCNGlG7+ZQOL2UqcslZtAhDgC8IHHmkDe0e+ORHOcQJp7JDyiB6BAxVCwvOY1n0BSmX0dHQ6gQFTe5JuCLJtAHVMIAw/Em0COFXr8JyGYQA==","dtype":"float64","order":"little","shape":[20]}},"selected":{"id":"18536"},"selection_policy":{"id":"18535"}},"id":"18513","type":"ColumnDataSource"},{"attributes":{},"id":"18532","type":"AllLabels"},{"attributes":{"children":[[{"id":"18477"},0,0]]},"id":"18540","type":"GridBox"},{"attributes":{},"id":"18487","type":"BasicTicker"},{"attributes":{},"id":"18538","type":"Selection"},{"attributes":{"children":[{"id":"18542"},{"id":"18540"}]},"id":"18543","type":"Column"},{"attributes":{},"id":"18480","type":"DataRange1d"},{"attributes":{},"id":"18529","type":"AllLabels"},{"attributes":{"angle":{"value":1.5707963267948966},"line_alpha":{"value":0.35},"marker":{"value":"dash"},"size":{"value":8},"x":{"field":"rug_x"},"y":{"field":"rug_y"}},"id":"18518","type":"Scatter"},{"attributes":{},"id":"18482","type":"LinearScale"},{"attributes":{},"id":"18491","type":"BasicTicker"},{"attributes":{},"id":"18495","type":"PanTool"},{"attributes":{"axis_label":"ESS for small intervals","formatter":{"id":"18530"},"major_label_policy":{"id":"18532"},"ticker":{"id":"18491"}},"id":"18490","type":"LinearAxis"},{"attributes":{"source":{"id":"18513"}},"id":"18517","type":"CDSView"},{"attributes":{"fill_color":{"value":"#1f77b4"},"line_color":{"value":"#1f77b4"},"size":{"value":6},"x":{"field":"x"},"y":{"field":"y"}},"id":"18514","type":"Circle"},{"attributes":{"data":{"rug_x":{"__ndarray__":"u/QnuP7V5z9SIsxa1SLgPw==","dtype":"float64","order":"little","shape":[2]},"rug_y":{"__ndarray__":"nB0+wbWyacCcHT7BtbJpwA==","dtype":"float64","order":"little","shape":[2]}},"selected":{"id":"18538"},"selection_policy":{"id":"18537"}},"id":"18519","type":"ColumnDataSource"},{"attributes":{},"id":"18537","type":"UnionRenderers"},{"attributes":{"toolbar":{"id":"18541"},"toolbar_location":"above"},"id":"18542","type":"ToolbarBox"},{"attributes":{"bottom_units":"screen","fill_alpha":0.5,"fill_color":"lightgrey","left_units":"screen","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"right_units":"screen","syncable":false,"top_units":"screen"},"id":"18502","type":"BoxAnnotation"},{"attributes":{},"id":"18494","type":"ResetTool"},{"attributes":{"axis":{"id":"18490"},"dimension":1,"ticker":null},"id":"18493","type":"Grid"},{"attributes":{"below":[{"id":"18486"}],"center":[{"id":"18489"},{"id":"18493"}],"height":500,"left":[{"id":"18490"}],"output_backend":"webgl","renderers":[{"id":"18516"},{"id":"18520"},{"id":"18522"},{"id":"18523"}],"title":{"id":"18524"},"toolbar":{"id":"18504"},"toolbar_location":null,"width":500,"x_range":{"id":"18478"},"x_scale":{"id":"18482"},"y_range":{"id":"18480"},"y_scale":{"id":"18484"}},"id":"18477","subtype":"Figure","type":"Plot"},{"attributes":{"text":"mu"},"id":"18524","type":"Title"},{"attributes":{"overlay":{"id":"18503"}},"id":"18498","type":"LassoSelectTool"},{"attributes":{"data_source":{"id":"18513"},"glyph":{"id":"18514"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"18515"},"view":{"id":"18517"}},"id":"18516","type":"GlyphRenderer"},{"attributes":{"active_multi":null,"tools":[{"id":"18494"},{"id":"18495"},{"id":"18496"},{"id":"18497"},{"id":"18498"},{"id":"18499"},{"id":"18500"},{"id":"18501"}]},"id":"18504","type":"Toolbar"},{"attributes":{},"id":"18484","type":"LinearScale"},{"attributes":{"source":{"id":"18519"}},"id":"18521","type":"CDSView"},{"attributes":{"overlay":{"id":"18502"}},"id":"18496","type":"BoxZoomTool"},{"attributes":{"toolbars":[{"id":"18504"}],"tools":[{"id":"18494"},{"id":"18495"},{"id":"18496"},{"id":"18497"},{"id":"18498"},{"id":"18499"},{"id":"18500"},{"id":"18501"}]},"id":"18541","type":"ProxyToolbar"},{"attributes":{"fill_alpha":{"value":0.1},"fill_color":{"value":"#1f77b4"},"line_alpha":{"value":0.1},"line_color":{"value":"#1f77b4"},"size":{"value":6},"x":{"field":"x"},"y":{"field":"y"}},"id":"18515","type":"Circle"},{"attributes":{"line_alpha":0.7,"line_width":1.5,"location":0},"id":"18522","type":"Span"},{"attributes":{},"id":"18527","type":"BasicTickFormatter"},{"attributes":{},"id":"18535","type":"UnionRenderers"},{"attributes":{},"id":"18497","type":"WheelZoomTool"},{"attributes":{},"id":"18530","type":"BasicTickFormatter"},{"attributes":{},"id":"18536","type":"Selection"},{"attributes":{"axis":{"id":"18486"},"ticker":null},"id":"18489","type":"Grid"},{"attributes":{"line_color":"red","line_dash":[6],"line_width":3,"location":400},"id":"18523","type":"Span"}],"root_ids":["18543"]},"title":"Bokeh Application","version":"2.3.2"}}';
                  var render_items = [{"docid":"b321cd7c-cd87-4ca3-af30-f964036fa2f7","root_ids":["18543"],"roots":{"18543":"b1406617-0d83-4f9a-bd2e-9a8d2279dc9a"}}];
                  root.Bokeh.embed.embed_items(docs_json, render_items);
                
                  }
                  if (root.Bokeh !== undefined) {
                    embed_document(root);
                  } else {
                    var attempts = 0;
                    var timer = setInterval(function(root) {
                      if (root.Bokeh !== undefined) {
                        clearInterval(timer);
                        embed_document(root);
                      } else {
                        attempts++;
                        if (attempts > 100) {
                          clearInterval(timer);
                          console.log("Bokeh: ERROR: Unable to run BokehJS code because BokehJS library is missing");
                        }
                      }
                    }, 10, root)
                  }
                })(window);
              });
            };
            if (document.readyState != "loading") fn();
            else document.addEventListener("DOMContentLoaded", fn);
          })();
        },
        function(Bokeh) {
        
        
        }
      ];
    
      function run_inline_js() {
        
        for (var i = 0; i < inline_js.length; i++) {
          inline_js[i].call(root, root.Bokeh);
        }
        
      }
    
      if (root._bokeh_is_loading === 0) {
        console.debug("Bokeh: BokehJS loaded, going straight to plotting");
        run_inline_js();
      } else {
        load_libs(css_urls, js_urls, function() {
          console.debug("Bokeh: BokehJS plotting callback run at", now());
          run_inline_js();
        });
      }
    }(window));
  };
  if (document.readyState != "loading") fn();
  else document.addEventListener("DOMContentLoaded", fn);
})();