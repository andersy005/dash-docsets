(function() {
  var fn = function() {
    
    (function(root) {
      function now() {
        return new Date();
      }
    
      var force = false;
    
      if (typeof root._bokeh_onload_callbacks === "undefined" || force === true) {
        root._bokeh_onload_callbacks = [];
        root._bokeh_is_loading = undefined;
      }
    
      
      
    
      var element = document.getElementById("632742c8-a606-4bf4-85c3-f11716c696c9");
        if (element == null) {
          console.warn("Bokeh: autoload.js configured with elementid '632742c8-a606-4bf4-85c3-f11716c696c9' but no matching script tag was found.")
        }
      
    
      function run_callbacks() {
        try {
          root._bokeh_onload_callbacks.forEach(function(callback) {
            if (callback != null)
              callback();
          });
        } finally {
          delete root._bokeh_onload_callbacks
        }
        console.debug("Bokeh: all callbacks have finished");
      }
    
      function load_libs(css_urls, js_urls, callback) {
        if (css_urls == null) css_urls = [];
        if (js_urls == null) js_urls = [];
    
        root._bokeh_onload_callbacks.push(callback);
        if (root._bokeh_is_loading > 0) {
          console.debug("Bokeh: BokehJS is being loaded, scheduling callback at", now());
          return null;
        }
        if (js_urls == null || js_urls.length === 0) {
          run_callbacks();
          return null;
        }
        console.debug("Bokeh: BokehJS not loaded, scheduling load and callback at", now());
        root._bokeh_is_loading = css_urls.length + js_urls.length;
    
        function on_load() {
          root._bokeh_is_loading--;
          if (root._bokeh_is_loading === 0) {
            console.debug("Bokeh: all BokehJS libraries/stylesheets loaded");
            run_callbacks()
          }
        }
    
        function on_error(url) {
          console.error("failed to load " + url);
        }
    
        for (let i = 0; i < css_urls.length; i++) {
          const url = css_urls[i];
          const element = document.createElement("link");
          element.onload = on_load;
          element.onerror = on_error.bind(null, url);
          element.rel = "stylesheet";
          element.type = "text/css";
          element.href = url;
          console.debug("Bokeh: injecting link tag for BokehJS stylesheet: ", url);
          document.body.appendChild(element);
        }
    
        const hashes = {"https://cdn.bokeh.org/bokeh/release/bokeh-2.3.2.min.js": "XypntL49z55iwGVUW4qsEu83zKL3XEcz0MjuGOQ9SlaaQ68X/g+k1FcioZi7oQAc", "https://cdn.bokeh.org/bokeh/release/bokeh-tables-2.3.2.min.js": "bEsM86IHGDTLCS0Zod8a8WM6Y4+lafAL/eSiyQcuPzinmWNgNO2/olUF0Z2Dkn5i", "https://cdn.bokeh.org/bokeh/release/bokeh-widgets-2.3.2.min.js": "TX0gSQTdXTTeScqxj6PVQxTiRW8DOoGVwinyi1D3kxv7wuxQ02XkOxv0xwiypcAH"};
    
        for (let i = 0; i < js_urls.length; i++) {
          const url = js_urls[i];
          const element = document.createElement('script');
          element.onload = on_load;
          element.onerror = on_error.bind(null, url);
          element.async = false;
          element.src = url;
          if (url in hashes) {
            element.crossOrigin = "anonymous";
            element.integrity = "sha384-" + hashes[url];
          }
          console.debug("Bokeh: injecting script tag for BokehJS library: ", url);
          document.head.appendChild(element);
        }
      };
    
      function inject_raw_css(css) {
        const element = document.createElement("style");
        element.appendChild(document.createTextNode(css));
        document.body.appendChild(element);
      }
    
      
      var js_urls = ["https://cdn.bokeh.org/bokeh/release/bokeh-2.3.2.min.js", "https://cdn.bokeh.org/bokeh/release/bokeh-widgets-2.3.2.min.js", "https://cdn.bokeh.org/bokeh/release/bokeh-tables-2.3.2.min.js"];
      var css_urls = [];
      
    
      var inline_js = [
        function(Bokeh) {
          Bokeh.set_log_level("info");
        },
        
        function(Bokeh) {
          (function() {
            var fn = function() {
              Bokeh.safely(function() {
                (function(root) {
                  function embed_document(root) {
                    
                  var docs_json = '{"42f7b3a4-1e8d-4cdc-82cb-d82d9b660ce1":{"defs":[],"roots":{"references":[{"attributes":{},"id":"43286","type":"Selection"},{"attributes":{"data":{"top":{"__ndarray__":"ZWZmZmZm7j9OG+i0gU7XP2cDnTbQad8/WfKLJb9Y2j9Bpw102kDTP17JL5b8Yt0/PW2g0wY60T9U8oslv1jaP1ws+cWSX9w/WlVVVVVV2T9SVVVVVVXZPzTQaQOdNuA/ZgOdNtBp3z9m8oslv1jaP0h+seQXS9Y/SH6x5BdL1j84baDTBjrRPz+nDXTaQNM/SH6x5BdL1j8=","dtype":"float64","order":"little","shape":[19]},"x":{"__ndarray__":"DeU1lNdQSkDKayivobxjQCivobyGcnBAbCivobwGd0CuobyG8pp9QHkN5TWUF4JAGsprKK9hhUC8hvIayquIQF5DeQ3l9YtAAAAAAABAj0BQXkN5DUWRQKK8hvIa6pJA8hrKayiPlEBDeQ3lNTSWQJTXUF5D2ZdA5DWU11B+mUA2lNdQXiObQIbyGspryJxA2FBeQ3ltnkA=","dtype":"float64","order":"little","shape":[19]}},"selected":{"id":"43265"},"selection_policy":{"id":"43266"}},"id":"43201","type":"ColumnDataSource"},{"attributes":{},"id":"43287","type":"UnionRenderers"},{"attributes":{"data":{"top":{"__ndarray__":"4Qd+4Af+BUDVSq3USq0EQBh6oRd6oQJAGHqhF3qhAkAUO7ETOzECQCu1Uiu10gRAd2IndmKnA0DFTuzETuwCQHIjN3IjNwNAJDdyIzfyA0Bu5EZu5MYCQB/4gR/4gQNAxU7sxE7sAkDTC73QCz0EQNALvdALPQRA0Au90As9BEB6oRd6oRcEQIIf+IEf+ARAhl7ohV5oBUA=","dtype":"float64","order":"little","shape":[19]},"x":{"__ndarray__":"DeU1lNdQSkDKayivobxjQCivobyGcnBAbCivobwGd0CuobyG8pp9QHkN5TWUF4JAGsprKK9hhUC8hvIayquIQF5DeQ3l9YtAAAAAAABAj0BQXkN5DUWRQKK8hvIa6pJA8hrKayiPlEBDeQ3lNTSWQJTXUF5D2ZdA5DWU11B+mUA2lNdQXiObQIbyGspryJxA2FBeQ3ltnkA=","dtype":"float64","order":"little","shape":[19]}},"selected":{"id":"43286"},"selection_policy":{"id":"43287"}},"id":"43241","type":"ColumnDataSource"},{"attributes":{"bottom":{"value":1},"fill_alpha":{"value":0.1},"fill_color":{"value":"#fa7c17"},"line_alpha":{"value":0.1},"line_color":{"value":"white"},"top":{"field":"top"},"width":{"value":105.26315789473684},"x":{"field":"x"}},"id":"43209","type":"VBar"},{"attributes":{"fill_alpha":{"value":0.1},"fill_color":{"value":"#2a2eec"},"line_alpha":{"value":0.1},"line_color":{"value":"white"},"top":{"field":"top"},"width":{"value":105.26315789473684},"x":{"field":"x"}},"id":"43203","type":"VBar"},{"attributes":{"source":{"id":"43201"}},"id":"43205","type":"CDSView"},{"attributes":{},"id":"43271","type":"Selection"},{"attributes":{},"id":"43154","type":"SaveTool"},{"attributes":{"data_source":{"id":"43201"},"glyph":{"id":"43202"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"43203"},"view":{"id":"43205"}},"id":"43204","type":"GlyphRenderer"},{"attributes":{"source":{"id":"43207"}},"id":"43211","type":"CDSView"},{"attributes":{},"id":"43272","type":"UnionRenderers"},{"attributes":{"bottom":{"value":1},"fill_color":{"value":"#fa7c17"},"line_color":{"value":"white"},"top":{"field":"top"},"width":{"value":105.26315789473684},"x":{"field":"x"}},"id":"43208","type":"VBar"},{"attributes":{},"id":"43151","type":"WheelZoomTool"},{"attributes":{"data":{"top":{"__ndarray__":"AAAAAAAA8D8OdNpApw30PxSuR+F6FPY/1AY6baDT9T8c6LSBThv4PxdLfrHkF/c/1QY6baDT9T+V/GLJL5b2P1jyiyW/WPc/43oUrkfh+T8ehetRuB75PxdLfrHkF/c/mJmZmZmZ9z8YrkfhehT2P1RVVVVVVfY/lfxiyS+W9j/gehSuR+H5P5iZmZmZmfc/kl8s+cWS9T8=","dtype":"float64","order":"little","shape":[19]},"x":{"__ndarray__":"DeU1lNdQSkDKayivobxjQCivobyGcnBAbCivobwGd0CuobyG8pp9QHkN5TWUF4JAGsprKK9hhUC8hvIayquIQF5DeQ3l9YtAAAAAAABAj0BQXkN5DUWRQKK8hvIa6pJA8hrKayiPlEBDeQ3lNTSWQJTXUF5D2ZdA5DWU11B+mUA2lNdQXiObQIbyGspryJxA2FBeQ3ltnkA=","dtype":"float64","order":"little","shape":[19]}},"selected":{"id":"43267"},"selection_policy":{"id":"43268"}},"id":"43207","type":"ColumnDataSource"},{"attributes":{"line_dash":[6],"location":1.4166666666666665},"id":"43212","type":"Span"},{"attributes":{"axis":{"id":"43174"},"ticker":null},"id":"43177","type":"Grid"},{"attributes":{"bottom":{"value":2},"fill_color":{"value":"#328c06"},"line_color":{"value":"white"},"top":{"field":"top"},"width":{"value":105.26315789473684},"x":{"field":"x"}},"id":"43214","type":"VBar"},{"attributes":{},"id":"43288","type":"Selection"},{"attributes":{"bottom":{"value":3},"fill_color":{"value":"#c10c90"},"line_color":{"value":"white"},"top":{"field":"top"},"width":{"value":105.26315789473684},"x":{"field":"x"}},"id":"43220","type":"VBar"},{"attributes":{"source":{"id":"43229"}},"id":"43233","type":"CDSView"},{"attributes":{"callback":null},"id":"43189","type":"HoverTool"},{"attributes":{"data_source":{"id":"43207"},"glyph":{"id":"43208"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"43209"},"view":{"id":"43211"}},"id":"43210","type":"GlyphRenderer"},{"attributes":{"data_source":{"id":"43235"},"glyph":{"id":"43236"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"43237"},"view":{"id":"43239"}},"id":"43238","type":"GlyphRenderer"},{"attributes":{"axis_label":"Chain","formatter":{"id":"43279"},"major_label_policy":{"id":"43278"},"ticker":{"id":"43253"}},"id":"43178","type":"LinearAxis"},{"attributes":{},"id":"43261","type":"AllLabels"},{"attributes":{"line_dash":[6],"location":2.4166666666666665},"id":"43218","type":"Span"},{"attributes":{"axis_label":"Rank (all chains)","formatter":{"id":"43276"},"major_label_overrides":{"0":"0","1":"1","2":"2","3":"3"},"major_label_policy":{"id":"43275"},"ticker":{"id":"43175"}},"id":"43174","type":"LinearAxis"},{"attributes":{"axis":{"id":"43140"},"ticker":null},"id":"43143","type":"Grid"},{"attributes":{"source":{"id":"43213"}},"id":"43217","type":"CDSView"},{"attributes":{},"id":"43175","type":"BasicTicker"},{"attributes":{},"id":"43289","type":"UnionRenderers"},{"attributes":{"callback":null},"id":"43155","type":"HoverTool"},{"attributes":{"data":{"top":{"__ndarray__":"AAAAAAAAAECkcD0K1yMBQCa/WPKLpQFA6LSBThtoAkBqA5020OkCQCz5xZJfrANA8O7u7u5uBEDrUbgehWsDQOtRuB6FawNAC9ejcD0KA0BKfrHkF0sDQA102kCnDQRAqqqqqqoqA0BQG+i0gU4EQC+W/GLJrwRAThvotIFOBECuR+F6FC4EQE4b6LSBTgRAcD0K16PwBEA=","dtype":"float64","order":"little","shape":[19]},"x":{"__ndarray__":"DeU1lNdQSkDKayivobxjQCivobyGcnBAbCivobwGd0CuobyG8pp9QHkN5TWUF4JAGsprKK9hhUC8hvIayquIQF5DeQ3l9YtAAAAAAABAj0BQXkN5DUWRQKK8hvIa6pJA8hrKayiPlEBDeQ3lNTSWQJTXUF5D2ZdA5DWU11B+mUA2lNdQXiObQIbyGspryJxA2FBeQ3ltnkA=","dtype":"float64","order":"little","shape":[19]}},"selected":{"id":"43269"},"selection_policy":{"id":"43270"}},"id":"43213","type":"ColumnDataSource"},{"attributes":{},"id":"43262","type":"BasicTickFormatter"},{"attributes":{"bottom":{"value":2},"fill_alpha":{"value":0.1},"fill_color":{"value":"#328c06"},"line_alpha":{"value":0.1},"line_color":{"value":"white"},"top":{"field":"top"},"width":{"value":105.26315789473684},"x":{"field":"x"}},"id":"43215","type":"VBar"},{"attributes":{},"id":"43172","type":"LinearScale"},{"attributes":{"source":{"id":"43247"}},"id":"43251","type":"CDSView"},{"attributes":{"axis":{"id":"43178"},"dimension":1,"ticker":null},"id":"43181","type":"Grid"},{"attributes":{"data_source":{"id":"43213"},"glyph":{"id":"43214"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"43215"},"view":{"id":"43217"}},"id":"43216","type":"GlyphRenderer"},{"attributes":{"text":"mu"},"id":"43255","type":"Title"},{"attributes":{"fill_alpha":0.5,"fill_color":"lightgrey","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"syncable":false,"xs_units":"screen","ys_units":"screen"},"id":"43157","type":"PolyAnnotation"},{"attributes":{"bottom":{"value":3},"fill_color":{"value":"#c10c90"},"line_color":{"value":"white"},"top":{"field":"top"},"width":{"value":105.26315789473684},"x":{"field":"x"}},"id":"43248","type":"VBar"},{"attributes":{"fill_color":{"value":"#2a2eec"},"line_color":{"value":"white"},"top":{"field":"top"},"width":{"value":105.26315789473684},"x":{"field":"x"}},"id":"43202","type":"VBar"},{"attributes":{"data_source":{"id":"43241"},"glyph":{"id":"43242"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"43243"},"view":{"id":"43245"}},"id":"43244","type":"GlyphRenderer"},{"attributes":{},"id":"43278","type":"AllLabels"},{"attributes":{"overlay":{"id":"43190"}},"id":"43184","type":"BoxZoomTool"},{"attributes":{"data":{"top":{"__ndarray__":"MzMzMzOzDUC4HoXrUTgPQDCW/GLJrwxA0GkDnTbQDEBtoNMGOu0LQOi0gU4baApAzszMzMzMC0DrUbgehWsLQClcj8L1qApAqA102kAnCkBH4XoUrkcKQMaSXyz5xQlA6LSBThtoCkAqXI/C9agKQClcj8L1qApACtejcD0KC0AGOm2g0wYKQMkvlvxiyQpAaQOdNtDpCkA=","dtype":"float64","order":"little","shape":[19]},"x":{"__ndarray__":"DeU1lNdQSkDKayivobxjQCivobyGcnBAbCivobwGd0CuobyG8pp9QHkN5TWUF4JAGsprKK9hhUC8hvIayquIQF5DeQ3l9YtAAAAAAABAj0BQXkN5DUWRQKK8hvIa6pJA8hrKayiPlEBDeQ3lNTSWQJTXUF5D2ZdA5DWU11B+mUA2lNdQXiObQIbyGspryJxA2FBeQ3ltnkA=","dtype":"float64","order":"little","shape":[19]}},"selected":{"id":"43271"},"selection_policy":{"id":"43272"}},"id":"43219","type":"ColumnDataSource"},{"attributes":{"source":{"id":"43235"}},"id":"43239","type":"CDSView"},{"attributes":{},"id":"43183","type":"PanTool"},{"attributes":{"source":{"id":"43241"}},"id":"43245","type":"CDSView"},{"attributes":{},"id":"43182","type":"ResetTool"},{"attributes":{},"id":"43279","type":"BasicTickFormatter"},{"attributes":{},"id":"43188","type":"SaveTool"},{"attributes":{"bottom":{"value":3},"fill_alpha":{"value":0.1},"fill_color":{"value":"#c10c90"},"line_alpha":{"value":0.1},"line_color":{"value":"white"},"top":{"field":"top"},"width":{"value":105.26315789473684},"x":{"field":"x"}},"id":"43249","type":"VBar"},{"attributes":{},"id":"43185","type":"WheelZoomTool"},{"attributes":{"line_dash":[6],"location":3.480769230769231},"id":"43252","type":"Span"},{"attributes":{"overlay":{"id":"43191"}},"id":"43186","type":"LassoSelectTool"},{"attributes":{},"id":"43187","type":"UndoTool"},{"attributes":{"data":{"top":{"__ndarray__":"EPzAD/zACUAg+IEf+IELQMEP/MAPfApAdmIndmKnC0A4ciM3ciMOQIZe6IVeaA1Ah17ohV5oDUDYiZ3YiR0NQD7wAz/wAw9Ae6EXeqEXDEAbuZEbuRELQHZiJ3ZipwtAeqEXeqEXDEB0IzdyIzcLQBu5kRu5EQtAFDuxEzsxCkByIzdyIzcLQBu5kRu5EQtAxU7sxE7sCkA=","dtype":"float64","order":"little","shape":[19]},"x":{"__ndarray__":"DeU1lNdQSkDKayivobxjQCivobyGcnBAbCivobwGd0CuobyG8pp9QHkN5TWUF4JAGsprKK9hhUC8hvIayquIQF5DeQ3l9YtAAAAAAABAj0BQXkN5DUWRQKK8hvIa6pJA8hrKayiPlEBDeQ3lNTSWQJTXUF5D2ZdA5DWU11B+mUA2lNdQXiObQIbyGspryJxA2FBeQ3ltnkA=","dtype":"float64","order":"little","shape":[19]}},"selected":{"id":"43288"},"selection_policy":{"id":"43289"}},"id":"43247","type":"ColumnDataSource"},{"attributes":{"active_multi":null,"tools":[{"id":"43182"},{"id":"43183"},{"id":"43184"},{"id":"43185"},{"id":"43186"},{"id":"43187"},{"id":"43188"},{"id":"43189"}]},"id":"43192","type":"Toolbar"},{"attributes":{},"id":"43134","type":"DataRange1d"},{"attributes":{"bottom":{"value":1},"fill_alpha":{"value":0.1},"fill_color":{"value":"#fa7c17"},"line_alpha":{"value":0.1},"line_color":{"value":"white"},"top":{"field":"top"},"width":{"value":105.26315789473684},"x":{"field":"x"}},"id":"43237","type":"VBar"},{"attributes":{"source":{"id":"43219"}},"id":"43223","type":"CDSView"},{"attributes":{"data_source":{"id":"43247"},"glyph":{"id":"43248"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"43249"},"view":{"id":"43251"}},"id":"43250","type":"GlyphRenderer"},{"attributes":{"line_dash":[6],"location":2.480769230769231},"id":"43246","type":"Span"},{"attributes":{"line_dash":[6],"location":3.4166666666666665},"id":"43224","type":"Span"},{"attributes":{"fill_alpha":{"value":0.1},"fill_color":{"value":"#2a2eec"},"line_alpha":{"value":0.1},"line_color":{"value":"white"},"top":{"field":"top"},"width":{"value":105.26315789473684},"x":{"field":"x"}},"id":"43231","type":"VBar"},{"attributes":{},"id":"43265","type":"Selection"},{"attributes":{"fill_color":{"value":"#2a2eec"},"line_color":{"value":"white"},"top":{"field":"top"},"width":{"value":105.26315789473684},"x":{"field":"x"}},"id":"43230","type":"VBar"},{"attributes":{"children":[{"id":"43293"},{"id":"43291"}]},"id":"43294","type":"Column"},{"attributes":{"toolbars":[{"id":"43158"},{"id":"43192"}],"tools":[{"id":"43148"},{"id":"43149"},{"id":"43150"},{"id":"43151"},{"id":"43152"},{"id":"43153"},{"id":"43154"},{"id":"43155"},{"id":"43182"},{"id":"43183"},{"id":"43184"},{"id":"43185"},{"id":"43186"},{"id":"43187"},{"id":"43188"},{"id":"43189"}]},"id":"43292","type":"ProxyToolbar"},{"attributes":{"bottom":{"value":2},"fill_alpha":{"value":0.1},"fill_color":{"value":"#328c06"},"line_alpha":{"value":0.1},"line_color":{"value":"white"},"top":{"field":"top"},"width":{"value":105.26315789473684},"x":{"field":"x"}},"id":"43243","type":"VBar"},{"attributes":{"data":{"top":{"__ndarray__":"6YVe6IVe4D9nZmZmZmbeP2dmZmZmZu4/WWqlVmql7D/eyI3cyI3YP7vQC73QC9U/uBM7sRM73T+vEzuxEzvdPyZ2Yid2Ytc/lxu5kRu52T8ZuZEbuZHfP5AbuZEbudk/QS/0Qi/04D8LwQ/8wA/cP5AbuZEbudk/q9RKrdRK4z9BL/RCL/TgPyZ2Yid2Ytc/USu1Uiu1wj8=","dtype":"float64","order":"little","shape":[19]},"x":{"__ndarray__":"DeU1lNdQSkDKayivobxjQCivobyGcnBAbCivobwGd0CuobyG8pp9QHkN5TWUF4JAGsprKK9hhUC8hvIayquIQF5DeQ3l9YtAAAAAAABAj0BQXkN5DUWRQKK8hvIa6pJA8hrKayiPlEBDeQ3lNTSWQJTXUF5D2ZdA5DWU11B+mUA2lNdQXiObQIbyGspryJxA2FBeQ3ltnkA=","dtype":"float64","order":"little","shape":[19]}},"selected":{"id":"43282"},"selection_policy":{"id":"43283"}},"id":"43229","type":"ColumnDataSource"},{"attributes":{"line_dash":[6],"location":1.4807692307692308},"id":"43240","type":"Span"},{"attributes":{"text":"tau"},"id":"43227","type":"Title"},{"attributes":{},"id":"43266","type":"UnionRenderers"},{"attributes":{"toolbar":{"id":"43292"},"toolbar_location":"above"},"id":"43293","type":"ToolbarBox"},{"attributes":{},"id":"43141","type":"BasicTicker"},{"attributes":{"bottom":{"value":3},"fill_alpha":{"value":0.1},"fill_color":{"value":"#c10c90"},"line_alpha":{"value":0.1},"line_color":{"value":"white"},"top":{"field":"top"},"width":{"value":105.26315789473684},"x":{"field":"x"}},"id":"43221","type":"VBar"},{"attributes":{"axis_label":"Rank (all chains)","formatter":{"id":"43259"},"major_label_overrides":{"0":"0","1":"1","2":"2","3":"3"},"major_label_policy":{"id":"43258"},"ticker":{"id":"43141"}},"id":"43140","type":"LinearAxis"},{"attributes":{"data_source":{"id":"43219"},"glyph":{"id":"43220"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"43221"},"view":{"id":"43223"}},"id":"43222","type":"GlyphRenderer"},{"attributes":{"ticks":[0,1,2,3]},"id":"43253","type":"FixedTicker"},{"attributes":{},"id":"43153","type":"UndoTool"},{"attributes":{},"id":"43282","type":"Selection"},{"attributes":{},"id":"43136","type":"LinearScale"},{"attributes":{},"id":"43258","type":"AllLabels"},{"attributes":{"bottom":{"value":2},"fill_color":{"value":"#328c06"},"line_color":{"value":"white"},"top":{"field":"top"},"width":{"value":105.26315789473684},"x":{"field":"x"}},"id":"43242","type":"VBar"},{"attributes":{"line_dash":[6],"location":0.48076923076923067},"id":"43234","type":"Span"},{"attributes":{},"id":"43170","type":"LinearScale"},{"attributes":{"data":{"top":{"__ndarray__":"P/ADP/AD9z+SG7mRG7n2Py/0Qi/0QvU/eqEXeqEX9D9IbuRGbuT3P4If+IEf+PQ/MPRCL/RC9T+ZmZmZmZn3Pyd2Yid2YvQ/9kIv9EIv+D+4kRu5kRv7P7ATO7ETO/o/oBd6oRd6+D+mF3qhF3r4P1ZqpVZqpfk/9EIv9EIv+D9GbuRGbuT3P07sxE7sxPg/wA/8wA/8+z8=","dtype":"float64","order":"little","shape":[19]},"x":{"__ndarray__":"DeU1lNdQSkDKayivobxjQCivobyGcnBAbCivobwGd0CuobyG8pp9QHkN5TWUF4JAGsprKK9hhUC8hvIayquIQF5DeQ3l9YtAAAAAAABAj0BQXkN5DUWRQKK8hvIa6pJA8hrKayiPlEBDeQ3lNTSWQJTXUF5D2ZdA5DWU11B+mUA2lNdQXiObQIbyGspryJxA2FBeQ3ltnkA=","dtype":"float64","order":"little","shape":[19]}},"selected":{"id":"43284"},"selection_policy":{"id":"43285"}},"id":"43235","type":"ColumnDataSource"},{"attributes":{},"id":"43138","type":"LinearScale"},{"attributes":{},"id":"43132","type":"DataRange1d"},{"attributes":{},"id":"43149","type":"PanTool"},{"attributes":{},"id":"43259","type":"BasicTickFormatter"},{"attributes":{"children":[[{"id":"43131"},0,0],[{"id":"43167"},0,1]]},"id":"43291","type":"GridBox"},{"attributes":{},"id":"43283","type":"UnionRenderers"},{"attributes":{"bottom":{"value":1},"fill_color":{"value":"#fa7c17"},"line_color":{"value":"white"},"top":{"field":"top"},"width":{"value":105.26315789473684},"x":{"field":"x"}},"id":"43236","type":"VBar"},{"attributes":{"bottom_units":"screen","fill_alpha":0.5,"fill_color":"lightgrey","left_units":"screen","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"right_units":"screen","syncable":false,"top_units":"screen"},"id":"43190","type":"BoxAnnotation"},{"attributes":{"active_multi":null,"tools":[{"id":"43148"},{"id":"43149"},{"id":"43150"},{"id":"43151"},{"id":"43152"},{"id":"43153"},{"id":"43154"},{"id":"43155"}]},"id":"43158","type":"Toolbar"},{"attributes":{"below":[{"id":"43140"}],"center":[{"id":"43143"},{"id":"43147"},{"id":"43206"},{"id":"43212"},{"id":"43218"},{"id":"43224"}],"height":331,"left":[{"id":"43144"}],"output_backend":"webgl","renderers":[{"id":"43204"},{"id":"43210"},{"id":"43216"},{"id":"43222"}],"title":{"id":"43227"},"toolbar":{"id":"43158"},"toolbar_location":null,"width":496,"x_range":{"id":"43132"},"x_scale":{"id":"43136"},"y_range":{"id":"43134"},"y_scale":{"id":"43138"}},"id":"43131","subtype":"Figure","type":"Plot"},{"attributes":{"overlay":{"id":"43157"}},"id":"43152","type":"LassoSelectTool"},{"attributes":{},"id":"43267","type":"Selection"},{"attributes":{"ticks":[0,1,2,3]},"id":"43225","type":"FixedTicker"},{"attributes":{"axis_label":"Chain","formatter":{"id":"43262"},"major_label_policy":{"id":"43261"},"ticker":{"id":"43225"}},"id":"43144","type":"LinearAxis"},{"attributes":{},"id":"43148","type":"ResetTool"},{"attributes":{"overlay":{"id":"43156"}},"id":"43150","type":"BoxZoomTool"},{"attributes":{},"id":"43268","type":"UnionRenderers"},{"attributes":{"axis":{"id":"43144"},"dimension":1,"ticker":null},"id":"43147","type":"Grid"},{"attributes":{"data_source":{"id":"43229"},"glyph":{"id":"43230"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"43231"},"view":{"id":"43233"}},"id":"43232","type":"GlyphRenderer"},{"attributes":{"bottom_units":"screen","fill_alpha":0.5,"fill_color":"lightgrey","left_units":"screen","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"right_units":"screen","syncable":false,"top_units":"screen"},"id":"43156","type":"BoxAnnotation"},{"attributes":{},"id":"43275","type":"AllLabels"},{"attributes":{"fill_alpha":0.5,"fill_color":"lightgrey","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"syncable":false,"xs_units":"screen","ys_units":"screen"},"id":"43191","type":"PolyAnnotation"},{"attributes":{},"id":"43284","type":"Selection"},{"attributes":{"below":[{"id":"43174"}],"center":[{"id":"43177"},{"id":"43181"},{"id":"43234"},{"id":"43240"},{"id":"43246"},{"id":"43252"}],"height":331,"left":[{"id":"43178"}],"output_backend":"webgl","renderers":[{"id":"43232"},{"id":"43238"},{"id":"43244"},{"id":"43250"}],"title":{"id":"43255"},"toolbar":{"id":"43192"},"toolbar_location":null,"width":496,"x_range":{"id":"43132"},"x_scale":{"id":"43170"},"y_range":{"id":"43134"},"y_scale":{"id":"43172"}},"id":"43167","subtype":"Figure","type":"Plot"},{"attributes":{"line_dash":[6],"location":0.41666666666666663},"id":"43206","type":"Span"},{"attributes":{},"id":"43276","type":"BasicTickFormatter"},{"attributes":{},"id":"43285","type":"UnionRenderers"},{"attributes":{},"id":"43269","type":"Selection"},{"attributes":{},"id":"43270","type":"UnionRenderers"}],"root_ids":["43294"]},"title":"Bokeh Application","version":"2.3.2"}}';
                  var render_items = [{"docid":"42f7b3a4-1e8d-4cdc-82cb-d82d9b660ce1","root_ids":["43294"],"roots":{"43294":"632742c8-a606-4bf4-85c3-f11716c696c9"}}];
                  root.Bokeh.embed.embed_items(docs_json, render_items);
                
                  }
                  if (root.Bokeh !== undefined) {
                    embed_document(root);
                  } else {
                    var attempts = 0;
                    var timer = setInterval(function(root) {
                      if (root.Bokeh !== undefined) {
                        clearInterval(timer);
                        embed_document(root);
                      } else {
                        attempts++;
                        if (attempts > 100) {
                          clearInterval(timer);
                          console.log("Bokeh: ERROR: Unable to run BokehJS code because BokehJS library is missing");
                        }
                      }
                    }, 10, root)
                  }
                })(window);
              });
            };
            if (document.readyState != "loading") fn();
            else document.addEventListener("DOMContentLoaded", fn);
          })();
        },
        function(Bokeh) {
        
        
        }
      ];
    
      function run_inline_js() {
        
        for (var i = 0; i < inline_js.length; i++) {
          inline_js[i].call(root, root.Bokeh);
        }
        
      }
    
      if (root._bokeh_is_loading === 0) {
        console.debug("Bokeh: BokehJS loaded, going straight to plotting");
        run_inline_js();
      } else {
        load_libs(css_urls, js_urls, function() {
          console.debug("Bokeh: BokehJS plotting callback run at", now());
          run_inline_js();
        });
      }
    }(window));
  };
  if (document.readyState != "loading") fn();
  else document.addEventListener("DOMContentLoaded", fn);
})();