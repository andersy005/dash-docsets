(function() {
  var fn = function() {
    
    (function(root) {
      function now() {
        return new Date();
      }
    
      var force = false;
    
      if (typeof root._bokeh_onload_callbacks === "undefined" || force === true) {
        root._bokeh_onload_callbacks = [];
        root._bokeh_is_loading = undefined;
      }
    
      
      
    
      var element = document.getElementById("ca047bf9-cce2-41f5-b996-df8dd832143a");
        if (element == null) {
          console.warn("Bokeh: autoload.js configured with elementid 'ca047bf9-cce2-41f5-b996-df8dd832143a' but no matching script tag was found.")
        }
      
    
      function run_callbacks() {
        try {
          root._bokeh_onload_callbacks.forEach(function(callback) {
            if (callback != null)
              callback();
          });
        } finally {
          delete root._bokeh_onload_callbacks
        }
        console.debug("Bokeh: all callbacks have finished");
      }
    
      function load_libs(css_urls, js_urls, callback) {
        if (css_urls == null) css_urls = [];
        if (js_urls == null) js_urls = [];
    
        root._bokeh_onload_callbacks.push(callback);
        if (root._bokeh_is_loading > 0) {
          console.debug("Bokeh: BokehJS is being loaded, scheduling callback at", now());
          return null;
        }
        if (js_urls == null || js_urls.length === 0) {
          run_callbacks();
          return null;
        }
        console.debug("Bokeh: BokehJS not loaded, scheduling load and callback at", now());
        root._bokeh_is_loading = css_urls.length + js_urls.length;
    
        function on_load() {
          root._bokeh_is_loading--;
          if (root._bokeh_is_loading === 0) {
            console.debug("Bokeh: all BokehJS libraries/stylesheets loaded");
            run_callbacks()
          }
        }
    
        function on_error(url) {
          console.error("failed to load " + url);
        }
    
        for (let i = 0; i < css_urls.length; i++) {
          const url = css_urls[i];
          const element = document.createElement("link");
          element.onload = on_load;
          element.onerror = on_error.bind(null, url);
          element.rel = "stylesheet";
          element.type = "text/css";
          element.href = url;
          console.debug("Bokeh: injecting link tag for BokehJS stylesheet: ", url);
          document.body.appendChild(element);
        }
    
        const hashes = {"https://cdn.bokeh.org/bokeh/release/bokeh-2.3.2.min.js": "XypntL49z55iwGVUW4qsEu83zKL3XEcz0MjuGOQ9SlaaQ68X/g+k1FcioZi7oQAc", "https://cdn.bokeh.org/bokeh/release/bokeh-tables-2.3.2.min.js": "bEsM86IHGDTLCS0Zod8a8WM6Y4+lafAL/eSiyQcuPzinmWNgNO2/olUF0Z2Dkn5i", "https://cdn.bokeh.org/bokeh/release/bokeh-widgets-2.3.2.min.js": "TX0gSQTdXTTeScqxj6PVQxTiRW8DOoGVwinyi1D3kxv7wuxQ02XkOxv0xwiypcAH"};
    
        for (let i = 0; i < js_urls.length; i++) {
          const url = js_urls[i];
          const element = document.createElement('script');
          element.onload = on_load;
          element.onerror = on_error.bind(null, url);
          element.async = false;
          element.src = url;
          if (url in hashes) {
            element.crossOrigin = "anonymous";
            element.integrity = "sha384-" + hashes[url];
          }
          console.debug("Bokeh: injecting script tag for BokehJS library: ", url);
          document.head.appendChild(element);
        }
      };
    
      function inject_raw_css(css) {
        const element = document.createElement("style");
        element.appendChild(document.createTextNode(css));
        document.body.appendChild(element);
      }
    
      
      var js_urls = ["https://cdn.bokeh.org/bokeh/release/bokeh-2.3.2.min.js", "https://cdn.bokeh.org/bokeh/release/bokeh-widgets-2.3.2.min.js", "https://cdn.bokeh.org/bokeh/release/bokeh-tables-2.3.2.min.js"];
      var css_urls = [];
      
    
      var inline_js = [
        function(Bokeh) {
          Bokeh.set_log_level("info");
        },
        
        function(Bokeh) {
          (function() {
            var fn = function() {
              Bokeh.safely(function() {
                (function(root) {
                  function embed_document(root) {
                    
                  var docs_json = '{"3295e71b-d5a5-434d-b40c-1fb39f4fcc24":{"defs":[],"roots":{"references":[{"attributes":{"toolbar":{"id":"21143"},"toolbar_location":"above"},"id":"21144","type":"ToolbarBox"},{"attributes":{"source":{"id":"21108"}},"id":"21112","type":"CDSView"},{"attributes":{"data_source":{"id":"21113"},"glyph":{"id":"21114"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"21115"},"view":{"id":"21117"}},"id":"21116","type":"GlyphRenderer"},{"attributes":{},"id":"21094","type":"UndoTool"},{"attributes":{"source":{"id":"21118"}},"id":"21122","type":"CDSView"},{"attributes":{"axis":{"id":"21081"},"grid_line_color":null,"ticker":null},"id":"21084","type":"Grid"},{"attributes":{"data_source":{"id":"21108"},"glyph":{"id":"21109"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"21110"},"view":{"id":"21112"}},"id":"21111","type":"GlyphRenderer"},{"attributes":{"end":6.609353828155742,"start":-2.6505230171022767},"id":"21123","type":"Range1d"},{"attributes":{},"id":"21137","type":"Selection"},{"attributes":{"fill_alpha":0.1,"fill_color":"#4a98c9","line_alpha":0.1,"line_color":"#4a98c9","x":{"field":"x"},"y":{"field":"y"}},"id":"21115","type":"Patch"},{"attributes":{},"id":"21131","type":"BasicTickFormatter"},{"attributes":{"source":{"id":"21113"}},"id":"21117","type":"CDSView"},{"attributes":{},"id":"21082","type":"BasicTicker"},{"attributes":{"fill_alpha":0.1,"fill_color":"#1764ab","line_alpha":0.1,"line_color":"#1764ab","x":{"field":"x"},"y":{"field":"y"}},"id":"21120","type":"Patch"},{"attributes":{"end":6.534879349640162,"start":-2.191438502691117},"id":"21124","type":"Range1d"},{"attributes":{"fill_alpha":0.5,"fill_color":"lightgrey","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"syncable":false,"xs_units":"screen","ys_units":"screen"},"id":"21098","type":"PolyAnnotation"},{"attributes":{"formatter":{"id":"21131"},"major_label_policy":{"id":"21130"},"ticker":{"id":"21086"}},"id":"21085","type":"LinearAxis"},{"attributes":{},"id":"21140","type":"UnionRenderers"},{"attributes":{"overlay":{"id":"21097"}},"id":"21091","type":"BoxZoomTool"},{"attributes":{"data_source":{"id":"21118"},"glyph":{"id":"21119"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"21120"},"view":{"id":"21122"}},"id":"21121","type":"GlyphRenderer"},{"attributes":{},"id":"21090","type":"PanTool"},{"attributes":{},"id":"21138","type":"UnionRenderers"},{"attributes":{},"id":"21136","type":"UnionRenderers"},{"attributes":{},"id":"21128","type":"BasicTickFormatter"},{"attributes":{},"id":"21092","type":"WheelZoomTool"},{"attributes":{"data":{"x":{"__ndarray__":"e//XTV2Fpj+alV2WWOGiP4fx/OfoxqI/UxxBkKuCoT8UpPWz8wOgP/mAwuQdsKI/APTp210vqD9xWjgronOpP6y/IyG+qa8/CLUXiJIJsj8lqlrxkEG0Pw5ehpThrrg/4P+YSBLCvj/PeVYCx3+/P+0tG7q2E8M/QX41IHN0xj/ggp7ROrbIP4KZhHz63Mk/+FLlLax8zT8wixWbZ/XQP/BCeD+2BdE/UKIvgLOA0z9oRCEWT7DVP+qUc/+fZNY/lUumHhaB2T/gRcrs51raPxDGX6hmqNw/YEdzw4AF3z9y5mt0LdjfP5eUcYpzkeE/bCQOzQzY4T9oebn+lErjPyilYjhZLeQ/E8tu5v/y5D/oJbejpYLmP7OFXMp9sOY/fnXou7m76D+kpgsP8tfoPyqEy5VHF+s/Xydgej4t6z/E6PyPEX7tPyCotOWKgu0/3CgJUdfX7z/gltW7QurvP87ULt6RFvE/3fB4xnRK8T8sFdkTOEHyP0yKZD4NsPI/ilWDSd5r8z/a/YE3kyP0P+qVLX+ElvQ/ciqHskm99T9I1te0KsH1P6gWgurQ6/Y/cMHSGAli9z8EVywgdxb4Pwb+/9orO/k/ZJfWVR1B+T/E14CLw2v6PyTBIaXHH/s/IBgrwWmW+z+AWNX2D8H8P7wz2QySGf0/4Jh/LLbr/T882SliXBb/P+TnURJG1f8/zgzqS4EgAED+LL9m1LUAQCxNlIEnSwFAXG1pnHrgAUCMjT63zXUCQLqtE9IgCwNANb6ptPMpA0Dqzejsc6ADQBruvQfHNQRASA6TIhrLBEB4Lmg9bWAFQLBjTjoemgVAqU49WMD1BUDWbhJzE4sGQAaP541mIAdANq+8qLm1B0Bkz5HDDEsIQJTvZt5f4AhAzygcQ/RfCUDEDzz5snUJQPIvERQGCwpAIlDmLlmgCkBScLtJrDULQL5uTAtHdwtAgJCQZP/KC0CxsGV/UmAMQGgdxu+3hgxA4NA6mqX1DEBtUGcvWIMNQA7xD7X4ig1AOneIRi4bDkA+EeXPSyAOQNsckwtukQ5AbjG66p61DkBitl8DSh0PQJxRjwXySg9AiOf+N55+D0AyfETUdsUPQMxxZCBF4A9AxnS0x4oNEEB1oAiLCiYQQKCTM4pZKhBAAdoeKt0oEEDvHr83KycQQAGc7vTkJRBAkoJEUMMkEEBchva39CMQQMikMdH4IxBAx/5UWU8dEEDISYVYVwwQQPKY0//H7Q9AzHFkIEXgD0CXmR1lfMUPQF9oqwZSmQ9A4mtp+nBiD0CcUY8F8koPQPClXWvzJQ9A4EgOfTLmDkBuMbrqnrUOQMD4mXDxng5AJ1jAAdRRDkA+EeXPSyAOQP5xViSE/w1A8ClaZcCtDUAO8Q+1+IoNQKGPR6uEWg1AFc/kXjD+DEDg0DqapfUMQKITZ2+VowxAsLBlf1JgDEAbTCf4PEIMQGM7mwB22AtAgJCQZP/KC0DjcHUgRFwLQFJwu0msNQtAPPoViZ3TCkAiUOYuWaAKQKprBKw4TwpA8i8RFAYLCkDMOaNZKccJQMQPPPmydQlAtFXhyEwyCUCU72beX+AIQEi2+clckghAZM+RwwxLCEA0jORSZ+UHQDavvKi5tQdAhiyLDOQ0B0AGj+eNZiAHQNZuEnMTiwZAusb7a0SABkCoTj1YwPUFQPhp8JgdvQVAeC5oPW1gBUDQFZUl3PQEQEgOkyIaywRAGu69B8c1BEC/SlWuIhQEQOrN6OxzoANA5Mz04wkcA0C6rRPSIAsDQIyNPrfNdQJAMkffOT73AUBcbWmceuABQCxNlIEnSwFAnEGZgSfSAED+LL9m1LUAQM4M6kuBIABA1ZkbJ0FI/z882SliXBb/P+CYfyy26/0/gFjV9g/B/D8gGCvBaZb7P6JODJybyvo/xNeAi8Nr+j9kl9ZVHUH5PwRXLCB3Fvg/qBaC6tDr9j9NXY/UeQr2P0jW17QqwfU/6pUtf4SW9D+LVYNJ3mvzPywV2RM4QfI/WmnBdtAa8T/O1C7ekRbxP9woCVHX1+8/IKi05YqC7T9gJ2B6Pi3rP6SmCw/y1+g/6CW3o6WC5j8Txx2QoMnlPyilYjhZLeQ/bCQOzQzY4T+tuG6JXt7gP2BHc8OABd8/4EXK7Oda2j+IzzUJRzTXP2hEIRZPsNU/BjBYOUOG0j/wQng/tgXRPz5Vci95/ss/4IKe0Tq2yD/b1hDTX+HDPzzw62nY0b8/4P+YSBLCvj8RpSxoEyC7P042TwFc77U/Kdggut/8rz8A9OnbXS+oP3v/101dhaY/ztQu3pEW8T/XRYvzukrxP7dpiXeaxfE/LBXZEzhB8j+JVY/qbrbyP4pVg0nea/M/EoM5fZ4W9D/qlS1/hJb0P0jW17QqwfU/qBaC6tDr9j+k6hS2NG33PwRXLCB3Fvg/ZJfWVR1B+T/zb+/1lmb5P8XXgIvDa/o/IBgrwWmW+z+AWNX2D8H8P+CYfyy26/0/PNkpYlwW/z8wvgLAzZ7/P84M6kuBIABA/iy/ZtS1AEDM4PCHNkMBQCxNlIEnSwFAXG1pnHrgAUCcfwI6pjMCQIyNPrfNdQJAdCSMnQn3AkC6rRPSIAsDQOrN6OxzoANAqvj2TdilA0Aa7r0HxzUEQIjAtB/1SwRASA6TIhrLBEB6bFhDp+0EQHguaD1tYAVAQt1C0JmFBUCoTj1YwPUFQDlm1d4VCwZA9UxaV3F6BkDWbhJzE4sGQIO+0cuy1wZABo/njWYgB0DUbF+GqDEHQNSnPswfiAdANq+8qLm1B0B5Ok91b9IHQMZEBELUCAhA9F+K5DQtCECyX4a/GEIIQInIXVglRwhA0Rgs1Kw8CEDwRqEg4SQIQOOWKPkDBghAUForIk3qB0ATVicM0cIHQDavvKi5tQdAB0oBmF9IB0AGj+eNZiAHQNZuEnMTiwZAvJLCT/obBkCoTj1YwPUFQHguaD1tYAVASA6TIhrLBEAb7r0HxzUEQOrN6OxzoANAuq0T0iALA0CMjT63zXUCQFxtaZx64AFALE2UgSdLAUD+LL9m1LUAQB52hMWEhABAzgzqS4EgAEA82SliXBb/P5BwlXSElf4/4Jh/LLbr/T99ceepzMH8P39Y1fYPwfw/IBgrwWmW+z/UsY1AAEb7P8TXgIvDa/o/2FEGh+bU+T9kl9ZVHUH5P9GUGn14Sfg/BFcsIHcW+D+oFoLq0Ov2P4T5ZQMWzPY/SNbXtCrB9T9iS0tB6az1P02UCjhW1fQ/6pUtf4SW9D/yLQ8dohD0P4pVg0nea/M/wyIdb5BQ8z+o5hveGKnyPywV2RM4QfI/YaLrA6QS8j/Ow1Y9to/xP87ULt6RFvE/BEItTFKw8D8aDISFaG/wP5MB4OlIXfA/ZluaN1Rx8D/kfqrZtpjwP6UtStqE4vA/ztQu3pEW8T8=","dtype":"float64","order":"little","shape":[322]},"y":{"__ndarray__":"QEIjHE0E7z/oy8Jul5vwP672c08ItfE/dCElMHnO8j88TNYQ6ufzPwJ3h/FaAfU/PIzAJhTf9T/IoTjSyxr2P5DM6bI8NPc/Vveak61N+D8cIkx0Hmf5P+RM/VSPgPo/OBEwdP50+z+qd641AJr7P3CiXxZxs/w/N80Q9+HM/T96onqHyIP+P/z3wddS5v4/xCJzuMP//z/HJpJMmowAQEzRycwekABAKLzqvFIZAUBYSdIZDYMBQIxRQy0LpgFA8OabncMyAkANoMDz5VYCQFJ89A18vwJAUY+m3esmA0C2EU1+NEwDQBqnpe7s2ANAwH6cQ1XvA0B8PP5epWUEQPhqOrZzrgRA4NFWz13yBEAtokGL+G8FQERnrz8WfwVApvwHsM4LBkA5sg4uZhIGQAqSYCCHmAZA0jNS0nmdBkBuJ7mQPyUHQAScs2FLJgdA/IuRkyquB0DQvBEB+LEHQFveSBlBKwhANFJqcbA+CECeYy+2yaEIQJjnwuFoywhADLWoDDIVCUD6fBtSIVgJQJRtNTONgAlAXhJ0wtnkCUAKfFuFKOYJQBZlKws/TApAwKfMMpJxCkD8AoXadawKQCQ9JaNK/gpAvhV8RRQAC0CArYGkXVgLQIjSfRMDiwtAMjGY7f6uC0CU8DVWDQMMQOpn1oO7FwxAYNlX2bxKDEC9vg/2EIMMQE79LvRzpAxAImt12565DEAL8xhw2/gMQLKSh2QsMQ1AlfJ2f19lDUBuxkP8BZENQJWUrBU/tw1AFCjg1OS9DUBwTrvch9sNQF+JHdwr+Q1A/GyOKysYDkCpHIl3fj0OQHi9OEWdSg5AvxTBS7BiDkCQa+VVo3EOQIi6rdEbYg5A50uLtJFRDkDweeTVS1kOQBjbp63nXw5AeL04RZ1KDkD8/h074UYOQMdycTXfFw5A88AqOsHuDUBAh+q/ZNINQBQo4NTkvQ1Aingg00OfDUDHIlVIzEgNQLGSh2QsMQ1AG2Kg+GLyDEBO/S70c6QMQM4rH977ngxA6mfWg7sXDEDcF5R01xEMQIjSfRMDiwtAnKMHCXljC0AkPSWjSv4KQPYJ4rrsxQpAwKfMMpJxCkBeEnTC2eQJQJoC9gD5twlA+nwbUiFYCUCY58LhaMsIQDRSanGwPghA0LwRAfixB0BuJ7mQPyUHQAqSYCCHmAZApvwHsM4LBkBEZ68/Fn8FQODRVs9d8gRAfDz+XqVlBEAap6Xu7NgDQLYRTX40TANAG6nLFxweA0BSfPQNfL8CQPDmm53DMgJAjFFDLQumAUC1BV9itHABQCi86rxSGQFAxiaSTJqMAEArJzSWLjAAQMQic7jD//8//PfB11Lm/j9qTVvTYUH+PzjNEPfhzP0/caJfFnGz/D+6psAbNj/8P6p3rjUAmvs/5Uz9VI+A+j8eDkf2Pmb6PxwiTHQeZ/k/Mv2Lvs+p+D9W95qTrU34P4/M6bI8NPc/nBOHnnwW9z/IoTjSyxr2P8d/7UiAzfU/AneH8VoB9T/3Hzc1xJj0PzxM1hDq5/M/yIGxvt1Z8z90ISUwec7yPy5F5uSjMPI/rvZzTwi18T+X0WGk/R7xP+jLwm6Xm/A/aLSGVTsh8D9AQiMcTQTvP42wAAJAau4/tOzAWmvR7D/LSc7WLpDsP3sTe5Gevuo/KJdemYme6j+Q5qOnggjpP5hB/Nena+g/rpiZOH9e5z8M7JkWxjjmP9J4lKvLweU/lIMekDlR5D+AljdV5AXkP5Ab8eKK9uI/8EDVkwLT4T+Be2Hkp6rhPzwocgF4dOA/yNblpEFA3z8esIjjtOfeP/eqkvYus9w/sCshIn7a2j/E4jJa8mfaPxhi81Q+ENg/mIBcn7p01j8wjrj9ExzWP2D2aL/ThNQ/Lpa9KhZp0z8mxlQEApbSP3jVlxz3DtI/HIb3ZrLE0T/NXd3tH63QPzxwWiK4184/zULsGjt+zD+/VKYzZ1LLPxxC6DvJ4so/MMbmG2ISyj9QWT+nPurJP3/tkFF/Qso/wFSmM2dSyz/CqitvWlbLP9eyGEfswsw/0NTn76fazT+AVqoYbxPPP4fj0FuyRtA/bZHFNmdl0T941Zcc9w7SP7QsJrq3atM/tGanpKaz1T+YgFyfunTWP45bf9dXddc/AA1CkC8S2T+wKyEiftraP3o0G8D2/Ns/yNblpEFA3z/rdZTjYm/gP/BA1ZMC0+E/lfaAKDJ/4j+AljdV5AXkPwzsmRbGOOY/sSo9/cu05j+YQfzXp2voPyiXXpmJnuo/tOzAWmvR7D/kab/eOaTuP0BCIxxNBO8/NC4gLS2m9j/IoTjSyxr2PwJ3h/FaAfU/qL7ZASll9D88TNYQ6ufzP2JxqG2ERPM/dCElMHnO8j/sWKIX6H3yP//x7CXcDPI/2GG5PdvD8T+u9nNPCLXxP2UiiD7to/E/ukZHyv6u8T+u9nNPCLXxP9wagSfk3PE/T7sdT6IV8j+qk3pB3UfyP6pyV2ldc/I/RwmYC8in8j90ISUwec7yPxtaSNcU+fI/EJ6ZRUVl8z88TNYQ6ufzP0ENieMl7/M/eOIqZBGW9D8Cd4fxWgH1P5GdRcvpW/U/yKE40ssa9j/RCacu3Dr2P4aOEwb6K/c/kMzpsjw09z9IWk2kvSn4P1b3mpOtTfg/Z1Whvfsp+T8cIkx0Hmf5P0Z0Raj2Nfo/5Ez9VI+A+j90Aw2OW2j7P6p3rjUAmvs/cKJfFnGz/D/IUoSs1eH8PzjNEPfhzP0/NJjbQ5Cw/j/898HXUub+P8Mic7jD//8/FM5HQ8tVAEDGJpJMmowAQCi86rxSGQFAjFFDLQumAUDw5pudwzICQFJ89A18vwJAthFNfjRMA0Aap6Xu7NgDQHw8/l6lZQRA4NFWz13yBEBEZ68/Fn8FQIir0eGclQVApvwHsM4LBkCllpJ/5SUGQAGBKKl3awZACpJgIIeYBkDl/VAiXqYGQIDcz4+63wZAUHVesNgHB0BFpd2LLxgHQHbzdS9SGQdA1SEHTq4RB0BFCrmTVgIHQIoyvvtR7AZAVn8D1qrPBkBkDOZ6kKkGQAqSYCCHmAZAZnN858NzBkDQkgGELy4GQKb8B7DOCwZA0C6W1tPaBUBEZ68/Fn8FQPmONWrbfgVAKehESYASBUDg0VbPXfIEQPpsyS32nQRAfDz+XqVlBEAM5+KEoy4EQBqnpe7s2ANAC6Nj2RTGA0A19P0UDFkDQLYRTX40TANAodmcQHDKAkBSfPQNfL8CQPDmm53DMgJAgIHOpN8GAkCMUUMtC6YBQNFftDJwLwFAKLzqvFIZAUDGJpJMmowAQEh8S8WfLQBAxCJzuMP//z/898HXUub+PzjNEPfhzP0/cKJfFnGz/D+qd641AJr7P+RM/VSPgPo/HCJMdB5n+T9W95qTrU34P5DM6bI8NPc/NC4gLS2m9j8=","dtype":"float64","order":"little","shape":[322]}},"selected":{"id":"21137"},"selection_policy":{"id":"21138"}},"id":"21113","type":"ColumnDataSource"},{"attributes":{},"id":"21139","type":"Selection"},{"attributes":{"formatter":{"id":"21128"},"major_label_policy":{"id":"21127"},"ticker":{"id":"21082"}},"id":"21081","type":"LinearAxis"},{"attributes":{},"id":"21077","type":"LinearScale"},{"attributes":{},"id":"21127","type":"AllLabels"},{"attributes":{},"id":"21089","type":"ResetTool"},{"attributes":{"toolbars":[{"id":"21099"}],"tools":[{"id":"21089"},{"id":"21090"},{"id":"21091"},{"id":"21092"},{"id":"21093"},{"id":"21094"},{"id":"21095"},{"id":"21096"}]},"id":"21143","type":"ProxyToolbar"},{"attributes":{"children":[{"id":"21144"},{"id":"21142"}]},"id":"21145","type":"Column"},{"attributes":{"axis":{"id":"21085"},"dimension":1,"grid_line_color":null,"ticker":null},"id":"21088","type":"Grid"},{"attributes":{},"id":"21126","type":"Title"},{"attributes":{"data":{"x":{"__ndarray__":"FCa701TH778hk8RyyEjwvzvC2lt+OfC/c0K4K3uA778ca+AAOCfvvyyLDicPz+6/FoD6TokM778ca+AAOCfvv8UzgYmBVu+/is51muZl77+S5N3dfmTvvxxr4AA4J++/I1cV8dwO77+es+ErVZLuv4Je3jKGAO6/1ohbLrE97b9g6ouV69HsvwOQ4t98oOy/q/w8YhRA7L+USyxSwa7rvzVMPUZf9+q/omk3Kp986r9Mhznu+xPqv1LbSrTn1+i/5OjivlIn6L/4AL69TjXnv/phZKwbC+a/JmiOUwbS5b/ScUPMEYjlv7ouZFOBBuW/Qwpacs4u5L9o5znouXzjv0wAjoXyveK/rGblfG0n4b9i1Mr6E+Dgv09katZCPd6/38shI0Kk3b9XBNinGI3bv2DKeEyp+di/GsCLI/Pa2L9nQQqPPw3Wv+jIz3UQT9S/0g7Ni3hG0r/gjk0+70jPv4c1LtLen8y/skCOTpOnxr/gi/uQvfPFvyIC5N3ORcK/4BFTxxc9ub9KIXdYwNG0vwAwvLLRSpq/oA8+GQMWUT8A9OnbXS+oP0VoUMOAFLA/g2TJ9LGXuz/g/5hIEsK+P+zB36xkjsM/4IKe0Tq2yD+J6/8wqD/LP/BCeD+2BdE/yXy2qg2r0j9oRCEWT7DVP95Qgr9YOtg/4EXK7Oda2j+cUpN2EFjdP2BHc8OABd8/nm4wBq6G4T9sJA7NDNjhPyilYjhZLeQ/A7BAh4145D/oJbejpYLmP5As3xDCOOc/pKYLD/LX6D+2y/kR3CnqP2AnYHo+Les/a8i3VNtJ7T8gqLTlioLtP9woCVHX1+8/lqsQGeEc8D/O1C7ekRbxP3w3mCz9yPE/LBXZEzhB8j+KVYNJ3mvzP17qpLAMefM/6pUtf4SW9D/NmqSNYvP0P0jW17QqwfU/qBaC6tDr9j/O1oeoxxf3PwRXLCB3Fvg/ZJfWVR1B+T9DpHJaycD5P8TXgIvDa/o/IBgrwWmW+z/NMqVW0b37P4BY1fYPwfw/MV4cRG7Y/T/gmH8stuv9PzzZKWJcFv8/zgzqS4EgAED+LL9m1LUAQAh8HkyYwABALE2UgSdLAUBBDyi8BM0BQFxtaZx64AFAjI0+t811AkC6rRPSIAsDQECGobl9KANA6s3o7HOgA0Aa7r0HxzUEQEgOkyIaywRAM5ixPbEMBUB3Lmg9bWAFQKhOPVjA9QVA1m4ScxOLBkDl0K9HVhAHQAaP541mIAdANq+8qLm1B0Bkz5HDDEsIQJTvZt5f4AhAxA88+bJ1CUDyLxEUBgsKQCJQ5i5ZoApAUnC7Saw1C0CBkJBk/8oLQLCwZX9SYAxA4NA6mqX1DEAO8Q+1+IoNQD4R5c9LIA5A9T8QVbV2DkBuMbrqnrUOQJxRjwXySg9AzHFkIEXgD0D+yJwdzDoQQBVZB6t1hRBAHC4cdoepEEAt6XE4H9AQQB8e+EyM1hBARXncxcgaEUAQIIGPtEkRQFwJR1NyZRFAdJmx4BuwEUBiU1FJWeURQIwpHG7F+hFACFPr+sEgEkCkuYb7bkUSQNV9oJUcbRJAu0nxiBiQEkAu6D8IisgSQNPZWxbC2hJAeI67JNb/EkDracajayUTQKIuvXQMQRNAAvowMRVwE0C3CTIxkYkTQLuVbU27rRNAkbGaaua2E0Aaipu+vroTQAqJnh7+zBNAfApklGv7E0AyGgZMaAUUQFHBGTJKCxRAiTaj21gHFEBtuHEaHAsUQJQOO8C7HRRAkqtgZlsoFEC8Qi4IzSYUQHa4ijnpKxRAZOyxWEE5FEB6ljAcnEEUQIe4/sNNPxRAu3GAbZM1FEBWqnwqGzAUQLv57ZORLBRA22UEhIAiFEBmrgR+xA4UQDIaBkxoBRRA/N07mzb1E0Bt/z7nW9ITQBqKm76+uhNAprn7H2ytE0Czpzz4RY0TQAL6MDEVcBNAzmb0w0FsE0AVl6oD5FsTQHcFIGCqURNA5GZR0dpBE0DracajayUTQMGH7SAZIhNA3Ky9AV/3EkDT2VsWwtoSQMdpDwvaxhJAJs0YpW2WEkC7SfGIGJASQMAUS9eCZRJApLmG+25FEkDISlhp8C0SQIwpHG7F+hFAq09IUJnyEUAcYU0xOcgRQHSZseAbsBFAD8jNkGimEUAotPNNhYoRQFwJR1NyZRFA6m9HiXJcEUArSu66dScRQEV53MXIGhFAyskRkQ3zEEAt6XE4H9AQQLxvgcySuhBAFVkHq3WFEEBkU/8D63kQQP7InB3MOhBAT2frm0cxEEDMcWQgReAPQICtqrGKyg9AnFGPBfJKD0DWecxF4zkPQGabvDqWxw5AbjG66p61DkDlAwfd51gOQD4R5c9LIA5ABKF+5mHEDUAN8Q+1+IoNQKNflTIXNA1A4NA6mqX1DECUi5Kt28YMQLCwZX9SYAxA6unOCclVDECAkJBk/8oLQHNjVLg7uQtAUnC7Saw1C0CUBKUZMf0KQCJQ5i5ZoApArhv55WFHCkDyLxEUBgsKQEI8zAy7kwlAxA88+bJ1CUCU72beX+AIQJzmBrz0mwhAZc+RwwxLCEA2r7youbUHQPrJGNpMTgdABY/njWYgB0Da/zKy1JwGQNVuEnMTiwZAViOlOJEHBkCoTj1YwPUFQHguaD1tYAVArrS2C0o8BUBIDpMiGssEQBruvQfHNQRAaXcTCjvUA0Dqzejsc6ADQLqtE9IgCwNAbJZDpJTBAkCMjT63zXUCQFxtaZx64AFAOqEUFp+3AUAsTZSBJ0sBQP4sv2bUtQBAuNb3yKFUAEDODOpLgSAAQDzZKWJcFv8/K5Wk3ncU/j/gmH8stuv9P4BY1fYPwfw/IBgrwWmW+z/E14CLw2v6P2hWZl2fYfo/ZJfWVR1B+T8EVywgdxb4P7FaIpKJ5fc/qBaC6tDr9j9I1te0KsH1P+qVLX+ElvQ/ilWDSd5r8z+/5wPxIULyPywV2RM4QfI/ztQu3pEW8T/cKAlR19fvPyCotOWKgu0/YCdgej4t6z+kpgsP8tfoP4ZYyCrOBec/6CW3o6WC5j8opWI4WS3kP+Q7MqRIWuM/bCQOzQzY4T9gR3PDgAXfP+BFyuznWto/foWGv+PH2T9oRCEWT7DVP/BCeD+2BdE/4IKe0Tq2yD/g/5hIEsK+Px0QuIgBrbg/APTp210vqD8AMLyy0Uqav70lK3qbHbe/4BFTxxc9ub/gi/uQvfPFv+COTT7vSM+/6MjPdRBP1L9uAaw8k57Vv/yg4xW8gdi/YMp4TKn52L8SeQqFvqPcv+DLISNCpN2/rGblfG0n4b/CEAFfJP/hv2jnOei5fOO/t7R3U75P5b8maI5TBtLlv7xkGBvRgua/7QHzLeiT57/k6OK+Uifov97c/O+CCOm/6UKR2swO6r+iaTcqn3zqvzbRVyAQtOq/Dsf648Ce679g6ouV69HsvxMOUbZR7O2/THOvMAVR7r/we9OS7cnuvxxr4AA4J++/FCa701TH778A9OnbXS+oPynYILrf/K8/TjZPAVzvtT8RpSxoEyC7P+D/mEgSwr4/PfDradjRvz/b1hDTX+HDP+CCntE6tsg/PlVyL3n+yz/wQng/tgXRPwYwWDlDhtI/aUQhFk+w1T+IzzUJRzTXP+BFyuznWto/YEdzw4AF3z+uuG6JXt7gP2wkDs0M2OE/KKViOFkt5D8Txx2QoMnlP+glt6OlguY/pKYLD/LX6D9gJ2B6Pi3rPyCotOWKgu0/3CgJUdfX7z/O1C7ekRbxP1ppwXbQGvE/LBXZEzhB8j+KVYNJ3mvzP+qVLX+ElvQ/SNbXtCrB9T9NXY/UeQr2P6gWgurQ6/Y/BFcsIHcW+D9kl9ZVHUH5P8TXgIvDa/o/ok4MnJvK+j8hGCvBaZb7P4BY1fYPwfw/4Jh/LLbr/T882SliXBb/P9aZGydBSP8/zgzqS4EgAED+LL9m1LUAQJxBmYEn0gBALE2UgSdLAUBcbWmceuABQDJH3zk+9wFAjI0+t811AkC6rRPSIAsDQOTM9OMJHANA6s3o7HOgA0DASlWuIhQEQBruvQfHNQRASA6TIhrLBEDQFZUl3PQEQHguaD1tYAVA+GnwmB29BUCoTj1YwPUFQLrG+2tEgAZA1m4ScxOLBkAGj+eNZiAHQIYsiwzkNAdANq+8qLm1B0A0jORSZ+UHQGTPkcMMSwhASLb5yVySCECU72beX+AIQLRV4chMMglAxA88+bJ1CUDMOaNZKccJQPIvERQGCwpAqmsErDhPCkAiUOYuWaAKQDz6FYmd0wpAUnC7Saw1C0DjcHUgRFwLQICQkGT/ygtAYzubAHbYC0AbTCf4PEIMQLCwZX9SYAxAohNnb5WjDEDg0DqapfUMQBXP5F4w/gxAoY9Hq4RaDUAO8Q+1+IoNQO8pWmXArQ1A/nFWJIT/DUA9EeXPSyAOQCdYwAHUUQ5AwPiZcPGeDkBuMbrqnrUOQN9IDn0y5g5A8KVda/MlD0CcUY8F8koPQOJrafpwYg9AXmirBlKZD0CXmR1lfMUPQMxxZCBF4A9A8ZjT/8ftD0DISYVYVwwQQMf+VFlPHRBAx6Qx0fgjEEBchva39CMQQJKCRFDDJBBAAZzu9OQlEEDvHr83KycQQAHaHirdKBBAoJMzilkqEEB1oAiLCiYQQMZ0tMeKDRBAzHFkIEXgD0AyfETUdsUPQIjn/jeefg9AnFGPBfJKD0Bitl8DSh0PQG4xuuqetQ5A2hyTC26RDkA9EeXPSyAOQDp3iEYuGw5ADvEPtfiKDUBtUGcvWIMNQODQOpql9QxAaB3G77eGDECwsGV/UmAMQICQkGT/ygtAvm5MC0d3C0BScLtJrDULQCJQ5i5ZoApA8i8RFAYLCkDEDzz5snUJQM8oHEP0XwlAlO9m3l/gCEBkz5HDDEsIQDavvKi5tQdABo/njWYgB0DWbhJzE4sGQKhOPVjA9QVAsGNOOh6aBUB4Lmg9bWAFQEgOkyIaywRAGu69B8c1BEDqzejsc6ADQDW+qbTzKQNAuq0T0iALA0CMjT63zXUCQFxtaZx64AFALE2UgSdLAUD+LL9m1LUAQM4M6kuBIABA5OdREkbV/z882SliXBb/P+CYfyy26/0/vDPZDJIZ/T+AWNX2D8H8PyAYK8Fplvs/JMEhpccf+z/E14CLw2v6P2SX1lUdQfk/Bv7/2is7+T8EVywgdxb4P3DB0hgJYvc/qBaC6tDr9j9I1te0KsH1P3Iqh7JJvfU/6pUtf4SW9D/a/YE3kyP0P4pVg0nea/M/TIpkPg2w8j8sFdkTOEHyP93weMZ0SvE/ztQu3pEW8T/gltW7QurvP90oCVHX1+8/IKi05YqC7T/E6PyPEX7tP2AnYHo+Les/KYTLlUcX6z+kpgsP8tfoP3516Lu5u+g/tIVcyn2w5j/oJbejpYLmPxPLbub/8uQ/KKViOFkt5D9oebn+lErjP2wkDs0M2OE/l5RxinOR4T9y5mt0LdjfP2BHc8OABd8/EMZfqGao3D/gRcrs51raP5VLph4Wgdk/6ZRz/59k1j9oRCEWT7DVP1CiL4CzgNM/8EJ4P7YF0T8wixWbZ/XQP/hS5S2sfM0/gpmEfPrcyT/ggp7ROrbIP0F+NSBzdMY/7S0burYTwz/OeVYCx3+/P+D/mEgSwr4/Dl6GlOGuuD8lqlrxkEG0Pwi1F4iSCbI/rL8jIb6prz9yWjgronOpPwD06dtdL6g/+YDC5B2woj8UpPWz8wOgP1McQZCrgqE/h/H85+jGoj+alV2WWOGiP3v/101dhaY/APTp210vqD8=","dtype":"float64","order":"little","shape":[544]},"y":{"__ndarray__":"8EDVkwLT4T+AljdV5AXkPwzsmRbGOOY/mEH816dr6D/ZX0CrOmjpPyiXXpmJnuo/tOzAWmvR7D90A5RKx6DtP0BCIxxNBO8/6MvCbpeb8D+u9nNPCLXxPxwpP1qvbvI/dCElMHnO8j88TNYQ6ufzPwJ3h/FaAfU/yKE40ssa9j9lMbaiu872P5DM6bI8NPc/Vveak61N+D8cIkx0Hmf5P+RM/VSPgPo/HItCBWsS+z+qd641AJr7P3CiXxZxs/w/5og8H5wt/T84zRD34cz9P/v3wddS5v4/dGao5fNm/z/EInO4w///P8YmkkyajABAKLzqvFIZAUDs/pN8IGYBQIxRQy0LpgFAfd7TNQEbAkDw5pudwzICQFF89A18vwJA/DwNJLLVAkC2EU1+NEwDQGirBH5V0gNAGqel7uzYA0B8PP5epWUEQPKKuKWVqwRA4NFWz13yBED2+VRhxUwFQERnrz8WfwVApvwHsM4LBkCuWIsgESMGQAqSYCCHmAZAk/7pEO0AB0BuJ7mQPyUHQGLcsoN9gAdA0LwRAfixB0AAKgyJDxkIQDRSanGwPghAmOfC4WjLCEAIuVmD5PAIQPp8G1IhWAlAwii3pKGyCUBeEnTC2eQJQKDqkBX4QgpAwKfMMpJxCkBaEILlJ70KQCQ9JaNK/gpAHKxwng89C0CI0n0TA4sLQLWOaItbvAtA6mfWg7sXDEAh4m9lRSYMQEk9Zsr7lQxATv0u9HOkDECZCZLVmQ0NQLKSh2QsMQ1AFsuwaaaBDUAUKODU5L0NQBY6Sz6X7w1Aeb04RZ1KDkCIMqi5alYOQHr0weOkxg5A3FKRtVXXDkCnutLJSy0PQD7o6SUOZA9A8cOhNGSID0BOsZBWGOwPQKJ9QpbG8A9AT+RhRIQvEECDiU2Dvz4QQGy7E/7IXxBAVuBX/GOBEEA01Hm7G4UQQEP0jqKQoBBAOkNElEG+EEDmHqbzd8sQQMYfWZoP4hBAqj/8QEUMEUCYadIr1BERQC/3c/iKOxFASbT+YzBYEUCr9ci2PloRQBiHUuAFcxFAUJ8mldyFEUBPyHuyKZwRQPv+KpyMnhFAxEliPgHEEUCtSVfU6OQRQPl2HoRU6hFA6mg1hqEOEkBbjM8ucycSQF6UgwxFKxJAcHZAhUA9EkAP3qiUuVASQCDg5MFtZhJAEN+vRKFxEkDw8TmZPYMSQDZi/oqMnBJAXIMTov6rEkDCKdx8/bcSQAhmG6OcuRJAyEpFM3bFEkCNooCQq8wSQORKhXgM0xJA44PHYDzaEkC45/S0fN4SQLS0PnbD2RJAaBX/g/TKEkAUF2Xw9cESQDY8y3/kwxJAyVckqAjEEkDafU31I74SQE+w5ppyuhJAwincfP23EkDKLfDqprYSQKbQoju7tBJAa5GiL7apEkAqPZ2EwJYSQO3gRmMBhRJAEN+vRKFxEkDawJyL3TgSQF6UgwxFKxJAxPoWD4H3EUCtSVfU6OQRQH6/7bZ32xFAXBKmViXIEUD7/iqcjJ4RQHpnKFVaiBFASbT+YzBYEUDyo/nh3y8RQJhp0ivUERFAnWSWDWP9EEDmHqbzd8sQQAYxa649tBBANNR5uxuFEEAHriALRlUQQIOJTYO/PhBAcpNyfN0SEECjfUKWxvAPQD7o6SUOZA9A3FKRtVXXDkAA6AAoFbgOQHi9OEWdSg5AFCjg1OS9DUD2Npmg4GsNQLKSh2QsMQ1ATv0u9HOkDEDqZ9aDuxcMQIjSfRMDiwtAJD0lo0r+CkDAp8wyknEKQF4SdMLZ5AlA+nwbUiFYCUCY58LhaMsIQDRSanGwPghA0LwRAfixB0BuJ7mQPyUHQAqSYCCHmAZApvwHsM4LBkBEZ68/Fn8FQKb/MQsKUgVA4NFWz13yBEB8PP5epWUEQEVv1lT0FgRAGqel7uzYA0C2EU1+NEwDQInPm8Eq1QJAUnz0DXy/AkDw5pudwzICQIxRQy0LpgFAKLzqvFIZAUBNNJM9bZwAQMYmkkyajABAxCJzuMP//z92MPZsqVn/P/z3wddS5v4/OM0Q9+HM/T+8xIwNb6v9P3CiXxZxs/w/uDArjc8Z/D+qd641AJr7P11uhLEFrfo/5Ez9VI+A+j8cIkx0Hmf5PxXv7osyrfg/Vveak61N+D+QzOmyPDT3P6QGpfjxWvY/yKE40ssa9j8Cd4fxWgH1P4SQkP1yxvQ/PEzWEOrn8z9kmUkqRTrzP3QhJTB5zvI/iWRhxazi8T+u9nNPCLXxP1aYndQ/v/A/6MvCbpeb8D+sc6GUYVXvP0BCIxxNBO8/4mk33kQZ7T+07MBaa9HsPyiXXpmJnuo/wiG2SRM16j+YQfzXp2voP+YuTxfahOc/DOyZFsY45j8WiB2l93HlP4CWN1XkBeQ/Qn/AZO3d4j/wQNWTAtPhP5ELIDdnr98/yNblpEFA3z+Gd9o/4lTbP7ArISJ+2to/0kOafrK/1z+YgFyfunTWP7jIcJD6G9Q/eNWXHPcO0j+Njj6bTnDQP8BUpjNnUss/e99SmhTKyT9igP9wzhjEP5D+HC7ghsI/9UBRk3y/wD9tpSLdEku6P6BQJ1GydrM/JiHEBTDprj8AREphRPp9PzyQwb4i8V2/QBD8idNur79z7dToa46xvw5Lci04376/UFoI6DunwL/43KlkEHbEvzf5he8mrse/gLCR7cJyyb/+f2Y5KKvKvyhCT2uCis+/WION+SQf0b+v/fJn+aDSv/Me0Xk9CtW/dC5SfOiE1b9noc9L7N/Wv2ySNWV4lti/kNkW/6vq2b9/LkZn6LPav5y0nKK329y/qITbgW9Q3r/B25+kM5Levw6GadE2JuC/UUdYiF7C4L/KXHJ++lPhv+IXUIIZW+G/YHwL6fFq4r95g3lVLHLjv3BtskP7jeO/0Og2aX405L8x77uxWX/kv265mJpXu+S/VQMyLJ8o5b/9whQF3cDlv1pkdgNXweW/VJj5BFts5r+1LiZu+OXmv9W81ZwWDee/bDLoNpnO5r+qjtmRLC7mv/zCFAXdwOW/zeO0ypKs5b+ervgrWqnlv/zCFAXdwOW/4+Vi/4cA5r86plq93Ujmv6V4Qr4v2OW//MIUBd3A5b+l8jgFoEDlv5CnlLP6uuS/Hmz7CIsZ5L+3KyFVQ7Xjv3BtskP7jeO/IR17u4Q2479ibX7p4T7iv+IXUIIZW+G/lNZ/YyRH4b8VfsT4yurgv/BE8IlwwuC/uRjoMnzP37+phNuBb1Dev5DZFv+r6tm/MrnVMH5R2b90LlJ86ITVvzCJkAOAstS/QgMybBsT0r9Yg435JB/Rv89auX4/n86/gLCR7cJyyb9kWga4V97Gv1BaCOg7p8C/QBD8idNur7+E6B89g7yhvwBESmFE+n0/oFAnUbJ2sz/x0qDEble/P5D+HC7ghsI/wFSmM2dSyz941Zcc9w7SP5iAXJ+6dNY/sCshIn7a2j/I1uWkQUDfP+gBPWclfeA/8EDVkwLT4T/lab/eOaTuP7TswFpr0ew/KJdemYme6j+YQfzXp2voP7AqPf3LtOY/DOyZFsY45j+AljdV5AXkP5X2gCgyf+I/8EDVkwLT4T/rdZTjYm/gP8jW5aRBQN8/ezQbwPb82z+wKyEiftraPwANQpAvEtk/jlt/11d11z+YgFyfunTWP7Rmp6Sms9U/tCwmurdq0z941Zcc9w7SP22RxTZnZdE/h+PQW7JG0D+AVqoYbxPPP9DU5++n2s0/17IYR+zCzD/CqitvWlbLP8BUpjNnUss/f+2QUX9Cyj9QWT+nPurJPy/G5htiEso/G0LoO8niyj/AVKYzZ1LLP8xC7Bo7fsw/PHBaIrjXzj/NXd3tH63QPxyG92ayxNE/eNWXHPcO0j8mxlQEApbSPy6WvSoWadM/YPZov9OE1D8wjrj9ExzWP5iAXJ+6dNY/GWLzVD4Q2D/E4jJa8mfaP7ArISJ+2to/96qS9i6z3D8esIjjtOfeP8jW5aRBQN8/PShyAXh04D+Be2Hkp6rhP/BA1ZMC0+E/kBvx4or24j+AljdV5AXkP5SDHpA5UeQ/0niUq8vB5T8M7JkWxjjmP62YmTh/Xuc/mEH816dr6D+Q5qOnggjpPyiXXpmJnuo/exN7kZ6+6j/MSc7WLpDsP7TswFpr0ew/jbAAAkBq7j9AQiMcTQTvP2i0hlU7IfA/6MvCbpeb8D+W0WGk/R7xP672c08ItfE/LkXm5KMw8j90ISUwec7yP8iBsb7dWfM/PEzWEOrn8z/3Hzc1xJj0PwJ3h/FaAfU/x3/tSIDN9T/IoTjSyxr2P5wTh558Fvc/kMzpsjw09z9W95qTrU34PzP9i77Pqfg/HCJMdB5n+T8eDkf2Pmb6P+RM/VSPgPo/qneuNQCa+z+7psAbNj/8P3CiXxZxs/w/N80Q9+HM/T9qTVvTYUH+P/z3wddS5v4/xCJzuMP//z8rJzSWLjAAQMYmkkyajABAKLzqvFIZAUC1BV9itHABQIxRQy0LpgFA8OabncMyAkBSfPQNfL8CQBupyxccHgNAthFNfjRMA0Aap6Xu7NgDQHw8/l6lZQRA4NFWz13yBEBEZ68/Fn8FQKb8B7DOCwZACpJgIIeYBkBuJ7mQPyUHQNC8EQH4sQdANFJqcbA+CECY58LhaMsIQPp8G1IhWAlAmgL2APm3CUBeEnTC2eQJQMCnzDKScQpA9gniuuzFCkAkPSWjSv4KQJyjBwl5YwtAiNJ9EwOLC0DcF5R01xEMQOpn1oO7FwxAzisf3vueDEBO/S70c6QMQBtioPhi8gxAspKHZCwxDUDGIlVIzEgNQIp4INNDnw1AFCjg1OS9DUBAh+q/ZNINQPTAKjrB7g1Ax3JxNd8XDkD9/h074UYOQHi9OEWdSg5AF9unredfDkDweeTVS1kOQOdLi7SRUQ5AiLqt0RtiDkCQa+VVo3EOQL8UwUuwYg5AeL04RZ1KDkCpHIl3fj0OQPxsjisrGA5AYIkd3Cv5DUBwTrvch9sNQBMo4NTkvQ1AlZSsFT+3DUBuxkP8BZENQJXydn9fZQ1AspKHZCwxDUAL8xhw2/gMQCFrddueuQxATv0u9HOkDEC9vg/2EIMMQGDZV9m8SgxA6mfWg7sXDECU8DVWDQMMQDIxmO3+rgtAiNJ9EwOLC0CArYGkXVgLQL4VfEUUAAtAJD0lo0r+CkD8AoXadawKQMCnzDKScQpAFmUrCz9MCkALfFuFKOYJQF4SdMLZ5AlAlG01M42ACUD6fBtSIVgJQAu1qAwyFQlAmOfC4WjLCECdYy+2yaEIQDRSanGwPghAW95IGUErCEDQvBEB+LEHQP2LkZMqrgdABJyzYUsmB0BuJ7mQPyUHQNMzUtJ5nQZACpJgIIeYBkA4sg4uZhIGQKb8B7DOCwZARWevPxZ/BUAsokGL+G8FQODRVs9d8gRA+Go6tnOuBEB8PP5epWUEQMB+nENV7wNAGqel7uzYA0C2EU1+NEwDQFGPpt3rJgNAUnz0DXy/AkANoMDz5VYCQPDmm53DMgJAjFFDLQumAUBYSdIZDYMBQCi86rxSGQFATNHJzB6QAEDGJpJMmowAQMQic7jD//8//PfB11Lm/j96onqHyIP+PzjNEPfhzP0/b6JfFnGz/D+pd641AJr7PzcRMHT+dPs/5Ez9VI+A+j8cIkx0Hmf5P1b3mpOtTfg/kMzpsjw09z/IoTjSyxr2PzyMwCYU3/U/AneH8VoB9T88TNYQ6ufzP3QhJTB5zvI/rvZzTwi18T/oy8Jul5vwP0BCIxxNBO8/5Wm/3jmk7j8=","dtype":"float64","order":"little","shape":[544]}},"selected":{"id":"21135"},"selection_policy":{"id":"21136"}},"id":"21108","type":"ColumnDataSource"},{"attributes":{},"id":"21095","type":"SaveTool"},{"attributes":{"fill_color":"#94c4df","line_alpha":0.25,"line_color":"#94c4df","x":{"field":"x"},"y":{"field":"y"}},"id":"21109","type":"Patch"},{"attributes":{"below":[{"id":"21081"}],"center":[{"id":"21084"},{"id":"21088"}],"height":500,"left":[{"id":"21085"}],"output_backend":"webgl","renderers":[{"id":"21111"},{"id":"21116"},{"id":"21121"}],"title":{"id":"21126"},"toolbar":{"id":"21099"},"toolbar_location":null,"width":500,"x_range":{"id":"21123"},"x_scale":{"id":"21077"},"y_range":{"id":"21124"},"y_scale":{"id":"21079"}},"id":"21072","subtype":"Figure","type":"Plot"},{"attributes":{"fill_color":"#4a98c9","line_alpha":0.25,"line_color":"#4a98c9","x":{"field":"x"},"y":{"field":"y"}},"id":"21114","type":"Patch"},{"attributes":{},"id":"21135","type":"Selection"},{"attributes":{"children":[[{"id":"21072"},0,0]]},"id":"21142","type":"GridBox"},{"attributes":{},"id":"21130","type":"AllLabels"},{"attributes":{"overlay":{"id":"21098"}},"id":"21093","type":"LassoSelectTool"},{"attributes":{},"id":"21086","type":"BasicTicker"},{"attributes":{"fill_color":"#1764ab","line_alpha":0.25,"line_color":"#1764ab","x":{"field":"x"},"y":{"field":"y"}},"id":"21119","type":"Patch"},{"attributes":{"bottom_units":"screen","fill_alpha":0.5,"fill_color":"lightgrey","left_units":"screen","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"right_units":"screen","syncable":false,"top_units":"screen"},"id":"21097","type":"BoxAnnotation"},{"attributes":{"callback":null},"id":"21096","type":"HoverTool"},{"attributes":{"data":{"x":{"__ndarray__":"pS1K2oTi8D/kfqrZtpjwP2ZbmjdUcfA/kwHg6Uhd8D8aDISFaG/wPwRCLUxSsPA/ztQu3pEW8T/Ow1Y9to/xP2Gi6wOkEvI/LBXZEzhB8j+o5hveGKnyP8MiHW+QUPM/ilWDSd5r8z/yLQ8dohD0P+qVLX+ElvQ/TpQKOFbV9D9iS0tB6az1P0jW17QqwfU/hPllAxbM9j+oFoLq0Ov2PwRXLCB3Fvg/0ZQafXhJ+D9kl9ZVHUH5P9hRBofm1Pk/xNeAi8Nr+j/UsY1AAEb7PyAYK8Fplvs/gFjV9g/B/D99ceepzMH8P+CYfyy26/0/kHCVdISV/j882SliXBb/P84M6kuBIABAHnaExYSEAED+LL9m1LUAQCxNlIEnSwFAXG1pnHrgAUCMjT63zXUCQLqtE9IgCwNA6s3o7HOgA0Aa7r0HxzUEQEgOkyIaywRAeC5oPW1gBUCpTj1YwPUFQLySwk/6GwZA1m4ScxOLBkAGj+eNZiAHQAdKAZhfSAdANq+8qLm1B0ATVicM0cIHQFBaKyJN6gdA45Yo+QMGCEDwRqEg4SQIQNEYLNSsPAhAichdWCVHCECyX4a/GEIIQPRfiuQ0LQhAxkQEQtQICEB5Ok91b9IHQDavvKi5tQdA1Kc+zB+IB0DUbF+GqDEHQAeP541mIAdAhL7Ry7LXBkDWbhJzE4sGQPVMWldxegZAOWbV3hULBkCoTj1YwPUFQELdQtCZhQVAeC5oPW1gBUB6bFhDp+0EQEgOkyIaywRAiMC0H/VLBEAa7r0HxzUEQKr49k3YpQNA6s3o7HOgA0C6rRPSIAsDQHQkjJ0J9wJAjI0+t811AkCbfwI6pjMCQFxtaZx64AFALE2UgSdLAUDM4PCHNkMBQP4sv2bUtQBAzgzqS4EgAEAwvgLAzZ7/PzzZKWJcFv8/4Jh/LLbr/T+AWNX2D8H8PyAYK8Fplvs/xNeAi8Nr+j/0b+/1lmb5P2SX1lUdQfk/BFcsIHcW+D+k6hS2NG33P6gWgurQ6/Y/SNbXtCrB9T/qlS1/hJb0PxSDOX2eFvQ/ilWDSd5r8z+IVY/qbrbyPywV2RM4QfI/uGmJd5rF8T/XRYvzukrxP87ULt6RFvE/pS1K2oTi8D8=","dtype":"float64","order":"little","shape":[106]},"y":{"__ndarray__":"kMzpsjw09z9W95qTrU34PxwiTHQeZ/k/5Ez9VI+A+j+qd641AJr7P3GiXxZxs/w/OM0Q9+HM/T/898HXUub+P8Qic7jD//8/SHxLxZ8tAEDGJpJMmowAQCi86rxSGQFA0V+0MnAvAUCMUUMtC6YBQICBzqTfBgJA8OabncMyAkBSfPQNfL8CQKHZnEBwygJAthFNfjRMA0A09P0UDFkDQAujY9kUxgNAGqel7uzYA0AM5+KEoy4EQHw8/l6lZQRA+mzJLfadBEDg0VbPXfIEQCroREmAEgVA+o41att+BUBEZ68/Fn8FQNAultbT2gVApvwHsM4LBkDPkgGELy4GQGZzfOfDcwZACpJgIIeYBkBkDOZ6kKkGQFZ/A9aqzwZAijK++1HsBkBFCrmTVgIHQNUhB06uEQdAdvN1L1IZB0BFpd2LLxgHQFB1XrDYBwdAgdzPj7rfBkDl/VAiXqYGQAqSYCCHmAZAAYEoqXdrBkCllpJ/5SUGQKb8B7DOCwZAiKvR4ZyVBUBDZ68/Fn8FQODRVs9d8gRAfDz+XqVlBEAap6Xu7NgDQLYRTX40TANAUnz0DXy/AkDw5pudwzICQIxRQy0LpgFAKLzqvFIZAUDGJpJMmowAQBTOR0PLVQBAxCJzuMP//z/898HXUub+PzWY20OQsP4/OM0Q9+HM/T/IUoSs1eH8P3CiXxZxs/w/qneuNQCa+z91Aw2OW2j7P+RM/VSPgPo/RnRFqPY1+j8cIkx0Hmf5P2dVob37Kfk/Vveak61N+D9IWk2kvSn4P5DM6bI8NPc/ho4TBvor9z/RCacu3Dr2P8ihONLLGvY/kZ1Fy+lb9T8Cd4fxWgH1P3jiKmQRlvQ/QQ2J4yXv8z88TNYQ6ufzPxGemUVFZfM/G1pI1xT58j90ISUwec7yP0cJmAvIp/I/qXJXaV1z8j+qk3pB3UfyP0+7HU+iFfI/3BqBJ+Tc8T+u9nNPCLXxP7pGR8r+rvE/ZSKIPu2j8T+u9nNPCLXxP9hhuT3bw/E///HsJdwM8j/sWKIX6H3yP3QhJTB5zvI/YnGobYRE8z88TNYQ6ufzP6i+2QEpZfQ/AneH8VoB9T/IoTjSyxr2PzQuIC0tpvY/kMzpsjw09z8=","dtype":"float64","order":"little","shape":[106]}},"selected":{"id":"21139"},"selection_policy":{"id":"21140"}},"id":"21118","type":"ColumnDataSource"},{"attributes":{},"id":"21079","type":"LinearScale"},{"attributes":{"fill_alpha":0.1,"fill_color":"#94c4df","line_alpha":0.1,"line_color":"#94c4df","x":{"field":"x"},"y":{"field":"y"}},"id":"21110","type":"Patch"},{"attributes":{"active_multi":null,"tools":[{"id":"21089"},{"id":"21090"},{"id":"21091"},{"id":"21092"},{"id":"21093"},{"id":"21094"},{"id":"21095"},{"id":"21096"}]},"id":"21099","type":"Toolbar"}],"root_ids":["21145"]},"title":"Bokeh Application","version":"2.3.2"}}';
                  var render_items = [{"docid":"3295e71b-d5a5-434d-b40c-1fb39f4fcc24","root_ids":["21145"],"roots":{"21145":"ca047bf9-cce2-41f5-b996-df8dd832143a"}}];
                  root.Bokeh.embed.embed_items(docs_json, render_items);
                
                  }
                  if (root.Bokeh !== undefined) {
                    embed_document(root);
                  } else {
                    var attempts = 0;
                    var timer = setInterval(function(root) {
                      if (root.Bokeh !== undefined) {
                        clearInterval(timer);
                        embed_document(root);
                      } else {
                        attempts++;
                        if (attempts > 100) {
                          clearInterval(timer);
                          console.log("Bokeh: ERROR: Unable to run BokehJS code because BokehJS library is missing");
                        }
                      }
                    }, 10, root)
                  }
                })(window);
              });
            };
            if (document.readyState != "loading") fn();
            else document.addEventListener("DOMContentLoaded", fn);
          })();
        },
        function(Bokeh) {
        
        
        }
      ];
    
      function run_inline_js() {
        
        for (var i = 0; i < inline_js.length; i++) {
          inline_js[i].call(root, root.Bokeh);
        }
        
      }
    
      if (root._bokeh_is_loading === 0) {
        console.debug("Bokeh: BokehJS loaded, going straight to plotting");
        run_inline_js();
      } else {
        load_libs(css_urls, js_urls, function() {
          console.debug("Bokeh: BokehJS plotting callback run at", now());
          run_inline_js();
        });
      }
    }(window));
  };
  if (document.readyState != "loading") fn();
  else document.addEventListener("DOMContentLoaded", fn);
})();