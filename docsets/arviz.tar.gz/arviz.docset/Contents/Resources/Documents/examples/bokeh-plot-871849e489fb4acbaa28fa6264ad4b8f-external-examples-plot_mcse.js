(function() {
  var fn = function() {
    
    (function(root) {
      function now() {
        return new Date();
      }
    
      var force = false;
    
      if (typeof root._bokeh_onload_callbacks === "undefined" || force === true) {
        root._bokeh_onload_callbacks = [];
        root._bokeh_is_loading = undefined;
      }
    
      
      
    
      var element = document.getElementById("fa53cc15-0b52-44d3-acaf-24c2abee9702");
        if (element == null) {
          console.warn("Bokeh: autoload.js configured with elementid 'fa53cc15-0b52-44d3-acaf-24c2abee9702' but no matching script tag was found.")
        }
      
    
      function run_callbacks() {
        try {
          root._bokeh_onload_callbacks.forEach(function(callback) {
            if (callback != null)
              callback();
          });
        } finally {
          delete root._bokeh_onload_callbacks
        }
        console.debug("Bokeh: all callbacks have finished");
      }
    
      function load_libs(css_urls, js_urls, callback) {
        if (css_urls == null) css_urls = [];
        if (js_urls == null) js_urls = [];
    
        root._bokeh_onload_callbacks.push(callback);
        if (root._bokeh_is_loading > 0) {
          console.debug("Bokeh: BokehJS is being loaded, scheduling callback at", now());
          return null;
        }
        if (js_urls == null || js_urls.length === 0) {
          run_callbacks();
          return null;
        }
        console.debug("Bokeh: BokehJS not loaded, scheduling load and callback at", now());
        root._bokeh_is_loading = css_urls.length + js_urls.length;
    
        function on_load() {
          root._bokeh_is_loading--;
          if (root._bokeh_is_loading === 0) {
            console.debug("Bokeh: all BokehJS libraries/stylesheets loaded");
            run_callbacks()
          }
        }
    
        function on_error(url) {
          console.error("failed to load " + url);
        }
    
        for (let i = 0; i < css_urls.length; i++) {
          const url = css_urls[i];
          const element = document.createElement("link");
          element.onload = on_load;
          element.onerror = on_error.bind(null, url);
          element.rel = "stylesheet";
          element.type = "text/css";
          element.href = url;
          console.debug("Bokeh: injecting link tag for BokehJS stylesheet: ", url);
          document.body.appendChild(element);
        }
    
        const hashes = {"https://cdn.bokeh.org/bokeh/release/bokeh-2.3.2.min.js": "XypntL49z55iwGVUW4qsEu83zKL3XEcz0MjuGOQ9SlaaQ68X/g+k1FcioZi7oQAc", "https://cdn.bokeh.org/bokeh/release/bokeh-tables-2.3.2.min.js": "bEsM86IHGDTLCS0Zod8a8WM6Y4+lafAL/eSiyQcuPzinmWNgNO2/olUF0Z2Dkn5i", "https://cdn.bokeh.org/bokeh/release/bokeh-widgets-2.3.2.min.js": "TX0gSQTdXTTeScqxj6PVQxTiRW8DOoGVwinyi1D3kxv7wuxQ02XkOxv0xwiypcAH"};
    
        for (let i = 0; i < js_urls.length; i++) {
          const url = js_urls[i];
          const element = document.createElement('script');
          element.onload = on_load;
          element.onerror = on_error.bind(null, url);
          element.async = false;
          element.src = url;
          if (url in hashes) {
            element.crossOrigin = "anonymous";
            element.integrity = "sha384-" + hashes[url];
          }
          console.debug("Bokeh: injecting script tag for BokehJS library: ", url);
          document.head.appendChild(element);
        }
      };
    
      function inject_raw_css(css) {
        const element = document.createElement("style");
        element.appendChild(document.createTextNode(css));
        document.body.appendChild(element);
      }
    
      
      var js_urls = ["https://cdn.bokeh.org/bokeh/release/bokeh-2.3.2.min.js", "https://cdn.bokeh.org/bokeh/release/bokeh-widgets-2.3.2.min.js", "https://cdn.bokeh.org/bokeh/release/bokeh-tables-2.3.2.min.js"];
      var css_urls = [];
      
    
      var inline_js = [
        function(Bokeh) {
          Bokeh.set_log_level("info");
        },
        
        function(Bokeh) {
          (function() {
            var fn = function() {
              Bokeh.safely(function() {
                (function(root) {
                  function embed_document(root) {
                    
                  var docs_json = '{"e73f2c1a-5932-485f-b784-4cb130820898":{"defs":[],"roots":{"references":[{"attributes":{"axis_label":"MCSE for quantiles","formatter":{"id":"37179"},"major_label_policy":{"id":"37180"},"ticker":{"id":"37092"}},"id":"37091","type":"LinearAxis"},{"attributes":{"fill_alpha":{"value":0.1},"fill_color":{"value":"#1f77b4"},"line_alpha":{"value":0.1},"line_color":{"value":"#1f77b4"},"x":{"field":"x"},"y":{"field":"y"}},"id":"37152","type":"Circle"},{"attributes":{"axis_label":"Quantile","formatter":{"id":"37196"},"major_label_policy":{"id":"37197"},"ticker":{"id":"37124"}},"id":"37123","type":"LinearAxis"},{"attributes":{"end":1,"start":-0.05},"id":"37117","type":"DataRange1d"},{"attributes":{},"id":"37179","type":"BasicTickFormatter"},{"attributes":{"axis_label":"MCSE for quantiles","formatter":{"id":"37193"},"major_label_policy":{"id":"37194"},"ticker":{"id":"37128"}},"id":"37127","type":"LinearAxis"},{"attributes":{},"id":"37180","type":"AllLabels"},{"attributes":{},"id":"37119","type":"LinearScale"},{"attributes":{"callback":null},"id":"37102","type":"HoverTool"},{"attributes":{},"id":"37121","type":"LinearScale"},{"attributes":{},"id":"37189","type":"UnionRenderers"},{"attributes":{"callback":null},"id":"37138","type":"HoverTool"},{"attributes":{},"id":"37190","type":"Selection"},{"attributes":{},"id":"37124","type":"BasicTicker"},{"attributes":{"axis":{"id":"37123"},"ticker":null},"id":"37126","type":"Grid"},{"attributes":{},"id":"37182","type":"BasicTickFormatter"},{"attributes":{},"id":"37183","type":"AllLabels"},{"attributes":{"axis":{"id":"37127"},"dimension":1,"ticker":null},"id":"37130","type":"Grid"},{"attributes":{"line_alpha":0.7,"line_width":1.5,"location":0},"id":"37157","type":"Span"},{"attributes":{},"id":"37128","type":"BasicTicker"},{"attributes":{"fill_alpha":{"value":0.1},"fill_color":{"value":"#1f77b4"},"line_alpha":{"value":0.1},"line_color":{"value":"#1f77b4"},"x":{"field":"x"},"y":{"field":"y"}},"id":"37166","type":"Circle"},{"attributes":{"overlay":{"id":"37104"}},"id":"37099","type":"LassoSelectTool"},{"attributes":{"overlay":{"id":"37139"}},"id":"37133","type":"BoxZoomTool"},{"attributes":{},"id":"37132","type":"PanTool"},{"attributes":{},"id":"37131","type":"ResetTool"},{"attributes":{},"id":"37137","type":"SaveTool"},{"attributes":{},"id":"37134","type":"WheelZoomTool"},{"attributes":{"data":{"x":{"__ndarray__":"mpmZmZmZqT/SjhUII+24P2wor6G8hsI/bolTv+eWyD9w6vfcEqfOP7klTv2eW9I/O1YgjLRj1T+8hvIaymvYPz23xKnfc9s/vueWOPV73j8gjLRjBcLgP2GkHSsQRuI/oryG8hrK4z/i1O+5JU7lPyPtWIEw0uY/YwXCSDtW6D+kHSsQRtrpP+U1lNdQXus/JU79nlvi7D9mZmZmZmbuPw==","dtype":"float64","order":"little","shape":[20]},"y":{"__ndarray__":"TOY7mm62yD/upazjteTNP/DqXfy8Lcs/HHCIRHVOzT9orzckCyTOP6y8CkfbP8w/iNx/9NF5yz+IfM+LFJ/NPygi8KloJ8w/oK0q3zNVzD/YcLH58jHPP6hWLqhoMNQ/IGaMl5nu0j8AebTCVJLRP+D0hUiIM80/uNpKBpu90z/A00Fq0J3TP2iCFjW8ldY/kLBgWUSo1j8QCPgZgPnXPw==","dtype":"float64","order":"little","shape":[20]}},"selected":{"id":"37188"},"selection_policy":{"id":"37187"}},"id":"37150","type":"ColumnDataSource"},{"attributes":{"overlay":{"id":"37140"}},"id":"37135","type":"LassoSelectTool"},{"attributes":{"axis":{"id":"37087"},"ticker":null},"id":"37090","type":"Grid"},{"attributes":{},"id":"37136","type":"UndoTool"},{"attributes":{},"id":"37100","type":"UndoTool"},{"attributes":{"line_alpha":0.7,"line_width":1.5,"location":0},"id":"37171","type":"Span"},{"attributes":{"toolbar":{"id":"37207"},"toolbar_location":"above"},"id":"37208","type":"ToolbarBox"},{"attributes":{"text":"tau"},"id":"37162","type":"Title"},{"attributes":{"line_alpha":0.5,"line_width":1.5,"location":0.2515582690238702},"id":"37155","type":"Span"},{"attributes":{"text":"mu"},"id":"37176","type":"Title"},{"attributes":{"below":[{"id":"37123"}],"center":[{"id":"37126"},{"id":"37130"}],"height":500,"left":[{"id":"37127"}],"output_backend":"webgl","renderers":[{"id":"37167"},{"id":"37169"},{"id":"37170"},{"id":"37171"},{"id":"37174"}],"title":{"id":"37176"},"toolbar":{"id":"37141"},"toolbar_location":null,"width":500,"x_range":{"id":"37115"},"x_scale":{"id":"37119"},"y_range":{"id":"37117"},"y_scale":{"id":"37121"}},"id":"37114","subtype":"Figure","type":"Plot"},{"attributes":{"axis":{"id":"37091"},"dimension":1,"ticker":null},"id":"37094","type":"Grid"},{"attributes":{"data":{"rug_x":{"__ndarray__":"fV36E1z/6j89DycBWWfXP73VlTJ7YsE/w8E5M5BGxz/DwTkzkEbHP8PBOTOQRsc/w8E5M5BGxz/DwTkzkEbHP8PBOTOQRsc/w8E5M5BGxz/DwTkzkEbHP8PBOTOQRsc/w8E5M5BGxz/DwTkzkEbHP8PBOTOQRsc/w8E5M5BGxz9P6PYIJnnCP0/o9ggmecI/T+j2CCZ5wj9P6PYIJnnCP0/o9ggmecI/T+j2CCZ5wj9P6PYIJnnCP0/o9ggmecI/txiR/XzQvD+3GJH9fNC8P7cYkf180Lw/txiR/XzQvD+3GJH9fNC8P7cYkf180Lw/Oqay45Jr6D86SHRMZcflP7HThSU1z+I/VdSaCTtd6D9Hvab2ZmSwP8UA5kQ6d4M/0GULqag1oz+aI/Yi4T7rP55DEK8H/NA/qgGd6qjX1D+VqnS/h2ThP/UnuP7VN+Q/TGXHJdeQ2z8=","dtype":"float64","order":"little","shape":[43]},"rug_y":{"__ndarray__":"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=","dtype":"float64","order":"little","shape":[43]}},"selected":{"id":"37204"},"selection_policy":{"id":"37203"}},"id":"37173","type":"ColumnDataSource"},{"attributes":{},"id":"37115","type":"DataRange1d"},{"attributes":{"overlay":{"id":"37103"}},"id":"37097","type":"BoxZoomTool"},{"attributes":{"toolbars":[{"id":"37105"},{"id":"37141"}],"tools":[{"id":"37095"},{"id":"37096"},{"id":"37097"},{"id":"37098"},{"id":"37099"},{"id":"37100"},{"id":"37101"},{"id":"37102"},{"id":"37131"},{"id":"37132"},{"id":"37133"},{"id":"37134"},{"id":"37135"},{"id":"37136"},{"id":"37137"},{"id":"37138"}]},"id":"37207","type":"ProxyToolbar"},{"attributes":{},"id":"37096","type":"PanTool"},{"attributes":{"angle":{"value":1.5707963267948966},"line_alpha":{"value":0.35},"marker":{"value":"dash"},"size":{"value":8},"x":{"field":"rug_x"},"y":{"field":"rug_y"}},"id":"37172","type":"Scatter"},{"attributes":{},"id":"37202","type":"Selection"},{"attributes":{},"id":"37095","type":"ResetTool"},{"attributes":{"end":1,"start":-0.05},"id":"37081","type":"DataRange1d"},{"attributes":{},"id":"37101","type":"SaveTool"},{"attributes":{},"id":"37083","type":"LinearScale"},{"attributes":{"source":{"id":"37173"}},"id":"37175","type":"CDSView"},{"attributes":{},"id":"37098","type":"WheelZoomTool"},{"attributes":{"source":{"id":"37164"}},"id":"37168","type":"CDSView"},{"attributes":{},"id":"37201","type":"UnionRenderers"},{"attributes":{},"id":"37092","type":"BasicTicker"},{"attributes":{},"id":"37079","type":"DataRange1d"},{"attributes":{"line_alpha":0.5,"line_width":0.75,"location":0.15209716424958658},"id":"37170","type":"Span"},{"attributes":{"fill_color":{"value":"#1f77b4"},"line_color":{"value":"#1f77b4"},"x":{"field":"x"},"y":{"field":"y"}},"id":"37151","type":"Circle"},{"attributes":{"data_source":{"id":"37164"},"glyph":{"id":"37165"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"37166"},"view":{"id":"37168"}},"id":"37167","type":"GlyphRenderer"},{"attributes":{"line_alpha":0.5,"line_width":0.75,"location":0.1782444431478369},"id":"37156","type":"Span"},{"attributes":{"bottom_units":"screen","fill_alpha":0.5,"fill_color":"lightgrey","left_units":"screen","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"right_units":"screen","syncable":false,"top_units":"screen"},"id":"37139","type":"BoxAnnotation"},{"attributes":{"fill_color":{"value":"#1f77b4"},"line_color":{"value":"#1f77b4"},"x":{"field":"x"},"y":{"field":"y"}},"id":"37165","type":"Circle"},{"attributes":{"children":[[{"id":"37078"},0,0],[{"id":"37114"},0,1]]},"id":"37206","type":"GridBox"},{"attributes":{"angle":{"value":1.5707963267948966},"line_alpha":{"value":0.35},"marker":{"value":"dash"},"size":{"value":8},"x":{"field":"rug_x"},"y":{"field":"rug_y"}},"id":"37158","type":"Scatter"},{"attributes":{},"id":"37088","type":"BasicTicker"},{"attributes":{"data":{"x":{"__ndarray__":"mpmZmZmZqT/SjhUII+24P2wor6G8hsI/bolTv+eWyD9w6vfcEqfOP7klTv2eW9I/O1YgjLRj1T+8hvIaymvYPz23xKnfc9s/vueWOPV73j8gjLRjBcLgP2GkHSsQRuI/oryG8hrK4z/i1O+5JU7lPyPtWIEw0uY/YwXCSDtW6D+kHSsQRtrpP+U1lNdQXus/JU79nlvi7D9mZmZmZmbuPw==","dtype":"float64","order":"little","shape":[20]},"y":{"__ndarray__":"bcJe+Pxh3D88Eu5SUq3NPyL+eQAns8s/mzeOVbYJ1z+YvNPsmzTWP87j+UyletE/sIr1s8Bnzz8YN/msnr7PP8gPs0h4ec8/RNGUEkZ90z8g12riYrDUP+AlTxYjYc4/UBTOvdhAzD+AFwpyJ0DOPxDSzcUXbc4/kDNyJsikyj9AY0p3Si3PP8AWdsF70MQ/4I8dAXxLyD+grhW5nZrSPw==","dtype":"float64","order":"little","shape":[20]}},"selected":{"id":"37202"},"selection_policy":{"id":"37201"}},"id":"37164","type":"ColumnDataSource"},{"attributes":{"source":{"id":"37159"}},"id":"37161","type":"CDSView"},{"attributes":{"line_alpha":0.5,"line_width":1.5,"location":0.2148430013731262},"id":"37169","type":"Span"},{"attributes":{"data":{"rug_x":{"__ndarray__":"jQwCEA1Gsz9bBMLb9PjIP1Qd9Zram7E/yuyJRU9bmT/K7IlFT1uZP8rsiUVPW5k/yuyJRU9bmT/K7IlFT1uZP8rsiUVPW5k/yuyJRU9bmT/K7IlFT1uZP8rsiUVPW5k/yuyJRU9bmT/K7IlFT1uZP8rsiUVPW5k/yuyJRU9bmT/zis1V/mKlP/OKzVX+YqU/84rNVf5ipT/zis1V/mKlP/OKzVX+YqU/84rNVf5ipT/zis1V/mKlP/OKzVX+YqU/aF85wG2piz9oXznAbamLP2hfOcBtqYs/aF85wG2piz9oXznAbamLP2hfOcBtqYs/pI3yRkqEyT9c/+ob+nG6P4OiBeyjALU/mx4fY+a33D9wF2c1cbTRPy51Aws2htg/P07TEgOYwz9FOncTGHy5P/BQ+ANPucc/uRO6PYJJzj9CRCWTDYpmP+UvVnGFsrI/8JR71fNwcj8=","dtype":"float64","order":"little","shape":[43]},"rug_y":{"__ndarray__":"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=","dtype":"float64","order":"little","shape":[43]}},"selected":{"id":"37190"},"selection_policy":{"id":"37189"}},"id":"37159","type":"ColumnDataSource"},{"attributes":{},"id":"37193","type":"BasicTickFormatter"},{"attributes":{"fill_alpha":0.5,"fill_color":"lightgrey","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"syncable":false,"xs_units":"screen","ys_units":"screen"},"id":"37140","type":"PolyAnnotation"},{"attributes":{},"id":"37194","type":"AllLabels"},{"attributes":{"data_source":{"id":"37159"},"glyph":{"id":"37158"},"hover_glyph":null,"muted_glyph":null,"view":{"id":"37161"}},"id":"37160","type":"GlyphRenderer"},{"attributes":{},"id":"37203","type":"UnionRenderers"},{"attributes":{"bottom_units":"screen","fill_alpha":0.5,"fill_color":"lightgrey","left_units":"screen","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"right_units":"screen","syncable":false,"top_units":"screen"},"id":"37103","type":"BoxAnnotation"},{"attributes":{},"id":"37204","type":"Selection"},{"attributes":{},"id":"37196","type":"BasicTickFormatter"},{"attributes":{},"id":"37197","type":"AllLabels"},{"attributes":{"fill_alpha":0.5,"fill_color":"lightgrey","level":"overlay","line_alpha":1.0,"line_color":"black","line_dash":[4,4],"line_width":2,"syncable":false,"xs_units":"screen","ys_units":"screen"},"id":"37104","type":"PolyAnnotation"},{"attributes":{"axis_label":"Quantile","formatter":{"id":"37182"},"major_label_policy":{"id":"37183"},"ticker":{"id":"37088"}},"id":"37087","type":"LinearAxis"},{"attributes":{},"id":"37085","type":"LinearScale"},{"attributes":{"active_multi":null,"tools":[{"id":"37095"},{"id":"37096"},{"id":"37097"},{"id":"37098"},{"id":"37099"},{"id":"37100"},{"id":"37101"},{"id":"37102"}]},"id":"37105","type":"Toolbar"},{"attributes":{"active_multi":null,"tools":[{"id":"37131"},{"id":"37132"},{"id":"37133"},{"id":"37134"},{"id":"37135"},{"id":"37136"},{"id":"37137"},{"id":"37138"}]},"id":"37141","type":"Toolbar"},{"attributes":{},"id":"37188","type":"Selection"},{"attributes":{"below":[{"id":"37087"}],"center":[{"id":"37090"},{"id":"37094"}],"height":500,"left":[{"id":"37091"}],"output_backend":"webgl","renderers":[{"id":"37153"},{"id":"37155"},{"id":"37156"},{"id":"37157"},{"id":"37160"}],"title":{"id":"37162"},"toolbar":{"id":"37105"},"toolbar_location":null,"width":500,"x_range":{"id":"37079"},"x_scale":{"id":"37083"},"y_range":{"id":"37081"},"y_scale":{"id":"37085"}},"id":"37078","subtype":"Figure","type":"Plot"},{"attributes":{"data_source":{"id":"37173"},"glyph":{"id":"37172"},"hover_glyph":null,"muted_glyph":null,"view":{"id":"37175"}},"id":"37174","type":"GlyphRenderer"},{"attributes":{},"id":"37187","type":"UnionRenderers"},{"attributes":{"source":{"id":"37150"}},"id":"37154","type":"CDSView"},{"attributes":{"data_source":{"id":"37150"},"glyph":{"id":"37151"},"hover_glyph":null,"muted_glyph":null,"nonselection_glyph":{"id":"37152"},"view":{"id":"37154"}},"id":"37153","type":"GlyphRenderer"},{"attributes":{"children":[{"id":"37208"},{"id":"37206"}]},"id":"37209","type":"Column"}],"root_ids":["37209"]},"title":"Bokeh Application","version":"2.3.2"}}';
                  var render_items = [{"docid":"e73f2c1a-5932-485f-b784-4cb130820898","root_ids":["37209"],"roots":{"37209":"fa53cc15-0b52-44d3-acaf-24c2abee9702"}}];
                  root.Bokeh.embed.embed_items(docs_json, render_items);
                
                  }
                  if (root.Bokeh !== undefined) {
                    embed_document(root);
                  } else {
                    var attempts = 0;
                    var timer = setInterval(function(root) {
                      if (root.Bokeh !== undefined) {
                        clearInterval(timer);
                        embed_document(root);
                      } else {
                        attempts++;
                        if (attempts > 100) {
                          clearInterval(timer);
                          console.log("Bokeh: ERROR: Unable to run BokehJS code because BokehJS library is missing");
                        }
                      }
                    }, 10, root)
                  }
                })(window);
              });
            };
            if (document.readyState != "loading") fn();
            else document.addEventListener("DOMContentLoaded", fn);
          })();
        },
        function(Bokeh) {
        
        
        }
      ];
    
      function run_inline_js() {
        
        for (var i = 0; i < inline_js.length; i++) {
          inline_js[i].call(root, root.Bokeh);
        }
        
      }
    
      if (root._bokeh_is_loading === 0) {
        console.debug("Bokeh: BokehJS loaded, going straight to plotting");
        run_inline_js();
      } else {
        load_libs(css_urls, js_urls, function() {
          console.debug("Bokeh: BokehJS plotting callback run at", now());
          run_inline_js();
        });
      }
    }(window));
  };
  if (document.readyState != "loading") fn();
  else document.addEventListener("DOMContentLoaded", fn);
})();